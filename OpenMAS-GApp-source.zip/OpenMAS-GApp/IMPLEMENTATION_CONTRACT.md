# Internal implementation contract

Python >=3.11, standard library runtime. Package `openmas` at repository root.
Modules exchange JSON-compatible dictionaries; validation errors raise ValueError.

Problem: `{id, setting, domain, application_type, input: {question, ...}, reference, metadata: {group?, ...}}`.
Reference is used exclusively by evaluation, never passed to builders/providers/runtime.
Field: `{name, type, description, required: true}`. Types string, number, integer, boolean, object, array, any.
Component: `{id, kind: agent|tool, operation, capability, inputs: [Field], outputs: [Field], domains: [], endpoint?, config?: {}, cost: 1}`.
Task graph: `{requirements: [{id, mandatory}], tasks: [{id, goal, covers: [requirement_id], capabilities: [{text, weight}], inputs: [Field], outputs: [Field], bindings: {input_name: source}, selected: true}], dependencies: [{source, target, kinds: [prerequisite|data]}]}`.
Source: `{external: field}` or `{node: node_id, field: field}` or `{task: task_id, field: field}` or `{value: JSON}`. Runtime must distinguish absent values from JSON null.
Selected paths per task: list `{id, components: [component_id], bindings: [{input_name: source}], output_bindings: {task_output: source}, coverage, compatibility, edge_scores: [], cost, utility}`. Path binding node IDs are `p0`, `p1`, etc.
Harness: `{id, problem_id, nodes: [{id, kind: Exec|Choice, component?, associations: [ids], operation?, tasks: [task_ids], bindings: {name: source}, config?: {}}], edges: [{id, source, target, type: Seq|Alt|Par|Fb, condition?: {source: Source, op: eq|ne|lt|le|gt|ge|truthy|falsy, value?: JSON}, priority?: number, max_traversals?: int, bindings?: {name: source}}], entry: [node_ids], outputs: {answer: Source}, task_graph?, profiles?, metadata?: {}}`.
Exec nodes call exactly one component operation per activation. No Python eval for conditions. Choice nodes carry no tasks. Non-feedback edges form a DAG. Seq/Par joins wait for all active predecessors; Alt chooses highest priority eligible edge with ID ties. Feedback is bounded, invalidates downstream completions, consumes per-edge AND global counts. Edges can update target bindings on feedback.

Registry API `Registry(components, handlers=None)`, `.components` dict, `.get(id)`, `.invoke(component_id, inputs, context)` -> dict; `.validate_inputs`, `.validate_outputs`. Context includes provider, budget, seed, phase, task_goal. Generic agent uses provider.complete; local tools explicitly allowlisted. Core root owns registry.py, providers.py, construction.py, budgets.py, validation.py.
Provider API `.complete(messages, *, phase='execution', temperature=0.2, max_tokens=2048, seed=None) -> {text, usage: {prompt_tokens, completion_tokens}, model}`; `.embed(texts) -> list[list[float]]`. Providers raise errors rather than fallback to fabricated responses. Offline fixture provider is labeled fixture and uses no reference labels.
Budget API `Budget(limits)` and `.consume(model_calls=0, tool_calls=0, model_tokens=0)`, `.check()`, `.snapshot()`; seconds limit uses monotonic clock, thread-safe. Provider wrapper handles model usage accounting; registry handles tool count. Runtime takes separate execution budget.
Construction API `GraphHarnessBuilder(registry, provider, config).build(problem_without_reference, seed=11) -> harness` and `.last_record`. `DirectBuilder` same API. Configuration merges paper JSON defaults with user runtime options.
Runtime API `HarnessRuntime(registry, *, provider=None, limits=None).execute(harness, inputs, seed=11) -> {output: {answer: ...}, status: success|failed, events: [], usage: {}, error?: str}`. Validate before calling. All events from actual execution.
Evaluation module API decided by owner; tell root when ready. Metrics normalized [0,1], complete prediction cohort enforced, macro F1 across entire run, sample SD ddof=1, explicit cross-setting set, separate full-suite and ablation protocols.

Ownership: root core modules + integration; runtime agent runtime.py + tests; data agent datasets.py, metrics.py, protocol.py + tests; CLI agent cli.py, experiments.py, perturbations.py, configs/examples/docs + tests. Do not edit another owner's files. Discuss contract changes by message.
