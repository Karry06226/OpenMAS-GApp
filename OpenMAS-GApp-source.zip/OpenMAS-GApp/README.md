# OpenMAS-GApp

本项目根据论文 **OpenMAS-GApp: A Comprehensive Benchmark for Domain-Adaptive Multi-Agent Application Construction** 实现。论文主入口为 `CVPR/main_benchmark.tex`。代码与论文文件并列，运行结果写入新目录。

项目包含任务结构提取、组件检索与路径选择、Graph Harness 构建、类型检查、Seq/Alt/Par/Fb 执行、数据适配、评分、独立重复实验、成对条件实验以及命令行工具。基准目录覆盖 **19 个基准数据集、20 个评测设置**。每道 individual problem、每个外层随机种子都独立构造应用。

这是依据论文和协议编写的新参考实现。论文已有结果、历史运行 ID、未归档日志与上游方法的实际运行版本没有通过代码反推。离线示例使用明确标注的 fixture，真实实验使用用户配置的模型服务、数据与评分器。

## 安装与本地检查

Python 3.11 或更高版本。运行时仅使用标准库，不要求 GPU。

```powershell
python -m pip install -e .
python -m openmas --help
python -m unittest discover -s tests -v
python -m openmas demo --output-dir outputs/demo
```

`demo` 实际执行两道本地算术题，运行五次，保存 Harness、事件和评分。它不调用模型，不代表论文数据集成绩。输出目录必须是新目录或空目录，已有运行不会被覆盖。

完整的离线单智能体流程可直接运行。

```powershell
python -m openmas run --data examples/arithmetic.jsonl --config configs/offline_direct.json --methods direct --output-dir outputs/direct-demo
python -m openmas report --directory outputs/direct-demo --format csv
```

## 配置真实模型

将 `configs/runtime.example.json` 复制为自己的配置。`provider.model` 填写实际部署的 API 模型 ID，也可以通过 `OPENMAS_MODEL` 设置。论文中的模型名称保留在正式配置中，代码不将名称猜测为可用的 API 别名。

```powershell
$env:DEEPSEEK_API_KEY = "your-key"
$env:OPENAI_API_KEY = "your-embedding-key"
$env:OPENMAS_MODEL = "your-deployed-model-id"
```

密钥只通过环境变量读取。聊天接口采用 Chat Completions 兼容协议。嵌入服务单独配置，默认读取 `text-embedding-3-large` 和 3072 维设置。服务错误、缺失 token 用量和非法 JSON 会返回错误，不会切换为离线答案。

`CVPR/PROVISIONAL_CDE_CONFIG.json` 的兼容文件名对应作者确认的正式配置。默认构造预算为 120 秒、12 次模型调用和 16000 tokens。执行预算为 300 秒、32 次模型调用、64 次工具调用和 32000 tokens。最终以实际加载的配置为准。安装包包含配置与来源版本的只读快照，来源及 SHA256 记录在 `openmas/resources/provenance.json`。

## 准备数据与冻结队列

先将获得授权的数据保存在本地，再指定来源版本与实际分区。数据集名称不会自动证明文件属于官方测试集。

```powershell
python -m openmas catalogue
python -m openmas prepare --input data/gsm8k_test.jsonl --setting GSM8K --source-revision actual-release-or-commit --split test --output data/gsm8k.normalized.jsonl
python -m openmas validate --data data/gsm8k.normalized.jsonl --manifest data/gsm8k.normalized.manifest.json
```

统一记录结构如下。`reference` 与任意评测元数据均保留在评分层，构造器和执行器只接收允许的输入。

```json
{
  "id": "stable-source-id",
  "setting": "GSM8K",
  "domain": "general",
  "application_type": "mathematical_reasoning",
  "input": {"question": "The original individual problem"},
  "reference": "The evaluator reference",
  "metadata": {"source_revision": "actual revision"}
}
```

数据适配支持 JSON、JSONL、gzip 和部分 CSV 发布格式。SciBench 目录读取 main 分支的十个文本评测文件并排除解答文件。ARC 目录项固定为 Challenge，官方测试集规模为 1172。SciBench main 文本评测源规模为 580。源规模与一次实际评测的题目数量分别记录。

BBH-Boolean 与 BBH-Mixed 属于同一 BIG-Bench Hard 基准。`datasets.build_bbh_candidate_pool` 分别构造 100 和 240 个候选。BBH-Mixed 必须提供固定的 27 配置顺序。使用 `select_cohort` 显式选择实际评测成员，再冻结清单。代码不会通过候选池大小推定评测题数，也不会补出缺失的混合配置顺序。

## 构造、执行与实验

```powershell
python -m openmas build --problem examples/problem.json --config configs/runtime.example.json --method graph --seed 11 --output outputs/example.harness.json
python -m openmas validate --harness outputs/example.harness.json --config configs/runtime.example.json
python -m openmas run --data data/gsm8k.normalized.jsonl --manifest data/gsm8k.normalized.manifest.json --config configs/runtime.example.json --methods graph direct --output-dir outputs/gsm8k-real
```

默认外层种子为 11、22、33、44、55。`--seeds 11` 可以进行单轮连通性检查，此时样本标准差保存为空。BBH 的独立 ablation 协议采用三个种子，可使用 `--comparison bbh-ablation`、`ablation` 或当前正文的 `Q3`。当前正文 `Q2` 保持主协议的五次重复，历史旧编号通过明确别名 `legacy-q2-ablation` 指定，具体范围见 [复现说明](docs/REPRODUCTION.md)。

模型辅助构造采用 `synthesis=model`。`synthesis=compiled` 根据经过验证的任务和路径执行确定性装配，作为单独记录的实现变体。组件选择固定保留两条可行路径，排序前冻结候选族和成本归一化极值，未达到可行路径数量时返回构造失败。

组件注册表提供通用智能体、医学、金融、科学、法律智能体，以及计算、读取、搜索、表格、单位转换和 Python worker 接口。`read/search` 需要固定的本地资源根目录和文档清单。Python 组件需要用户提供隔离 worker，默认不执行生成代码。登记为可调用资源与实际允许访问的资源分别通过运行配置控制。

执行已有的本地计算 Harness 不需要 API 密钥。

```powershell
python -m openmas execute --harness examples/calculator_harness.json --input examples/calculator_input.json --output outputs/calculator.execution.json
```

## 成对条件实验

`suite` 对同一冻结队列和种子序列运行多个显式条件，并报告每轮分数差值。所有条件重新构造和执行，Direct 也不会复用 clean 答案。

```powershell
python -m openmas suite --data data/gsm8k.normalized.jsonl --config configs/runtime.example.json --specification configs/scalability.example.json --output-dir outputs/scalability
python -m openmas suite --data data/gsm8k.normalized.jsonl --config configs/runtime.example.json --specification configs/robustness.example.json --output-dir outputs/robustness
```

`scalability.example.json` 给出部分 pool size 与 brief/detailed interface descriptions 条件，可以按正式目录补全。两种描述保持字段、类型、必选标记、操作与调用端点一致。`robustness.example.json` 给出独立 P2 低、高扰动。P1 需要逐条提供两位审核者确认的原短语、替换短语和审核记录。P3 需要提供可调用且已审核与当前题无关的组件。P4 需要提供相关资源与替代可行性判断，按冻结顺序选择屏蔽项。低、高强度使用同一顺序的嵌套前缀。

## 评分与上游方法

```powershell
python -m openmas evaluate --data data/gsm8k.normalized.jsonl --predictions outputs/gsm8k-real/predictions/actual-file.json --setting GSM8K --config configs/runtime.example.json
```

每轮先对完整预测队列计算归一化数据集指标，再转为百分比求均值与样本标准差。CaseHOLD 在完整队列上计算固定五类 macro-F1。缺失答案保留原题位置并计为失败。跨评测设置以显式指定集合等权，重复队列不一致时不合并。

MATH-500、DROP、FinQA、FinanceBench、HumanEval 和 MBPP 的正式评分依赖来源评分器或人工/模型审核协议。项目提供独立评分命令接口，尚未接入时保存完整预测并将结果标为 `evaluation_required`。接口示例及数据隔离方式见 [复现说明](docs/REPRODUCTION.md)。通用数值或文本匹配不会冒充这些评分器。

AFlow、ADAS、GPTSwarm 和 AgentSquare 通过外部构造命令接入。配置需声明实际 `implementation_id`、命令、版本与设置。代码不将通用实现重命名为上游官方方法。

内置可运行的本地消融方法为 `ablation_no_task_structure`、`ablation_generated_components`、`ablation_sequential`、`ablation_no_semantic_io`，顺序组织表示可使用 `representation_sequence`。每个方法记录具体实现变体。I/O 消融移除构造时的语义判断，继续验证运行时类型与必选输入。它们是本次实现的实验变体，历史 prompt 和运行配置仍由实际归档材料指定。

```powershell
python -m openmas run --data examples/arithmetic.jsonl --config configs/external.example.json --methods external:example --output-dir outputs/external-demo
```

该示例只是 JSON stdin/stdout 接口演示。接入真实方法时替换 `examples/external_builder.py` 的构造调用，并保留共享组件、资源和预算。详细论文对应关系见 [实现映射](docs/METHOD_MAPPING.md)。

## 文件组织

| 路径 | 内容 |
| --- | --- |
| `openmas/construction.py` | 任务提取、候选路径评估、三类 profile 和 Harness 装配 |
| `openmas/runtime.py` | 类型校验、分支、并行汇合和有界反馈 |
| `openmas/registry.py` | 注册表、智能体操作与本地工具 |
| `openmas/providers.py`, `budgets.py` | HTTP/fixture 服务、调用与 token 预算 |
| `openmas/datasets.py`, `protocol.py`, `metrics.py` | 来源适配、冻结清单与完整队列评分 |
| `openmas/experiments.py`, `perturbations.py` | 独立重复、成对条件与 P1–P4 |
| `configs/`, `examples/`, `tests/` | 配置、可运行示例和行为测试 |
| `outputs/<experiment>/` | 新执行产生的清单、预测、事件、评分及报告 |

生成 wheel 可使用 `python -m pip wheel . --no-deps --no-build-isolation -w dist`。源码 ZIP 应包含 `openmas/`、配置、示例、测试、说明和 `pyproject.toml`，API 密钥与真实私有数据不应放入发布包。
