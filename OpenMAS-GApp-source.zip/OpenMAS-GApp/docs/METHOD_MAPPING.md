# 论文方法与实现

| 论文位置 | 代码 | 行为 |
| --- | --- | --- |
| Problem Statement | `datasets.public_problem`, `experiments.run_experiment` | 每题每轮独立构造、执行和收集原始输出 |
| Appendix B.1 Task Structure Derivation | `construction.GraphHarnessBuilder` | 提取 mandatory requirements、任务、coverage、前序与 producer bindings，验证覆盖和 DAG |
| Component Selection | `construction.GraphHarnessBuilder` | 语义 support、embedding 匹配、接口判断、有限候选生成、硬可行族冻结与固定两路径选择 |
| Graph Harness Construction | `construction`, `runtime.validate_harness` | 保留源标识的三类 profile、Exec/Choice、类型化边与完整图校验 |
| Typed execution | `runtime.HarnessRuntime` | Seq/Alt/Par/Fb、标识符打破平局、当前调用汇合、有界反馈和失效传播 |
| Dataset evaluation | `metrics`, `protocol` | 每轮完整队列评分、macro-F1、BBH 分组、百分比均值及 ddof=1 |

## 实验入口

| 当前正文 | 执行入口 | 当前实现范围 |
| --- | --- | --- |
| Q1 Performance | `run --methods graph external:<name>` | Graph Harness 及显式上游命令接口。AFlow、ADAS、GPTSwarm、AgentSquare 需要真实安装与方法包装器 |
| Q2 Construction Paradigms | `run`、外部适配器 | 内置 direct 单智能体参照。Prompt-only、plan、workflow 等分别接入声明的方法实现 |
| Q3 Construction Ablation | 内置 `ablation_*`、显式方法适配器 | 本次实现的整体单任务、生成组件配置、串行执行和移除语义 I/O 判断变体，分别有 implementation ID |
| Q4 Graph Organization | `representation_sequence`、显式表示适配器 | 内置保留任务与选中操作的串行表示。其他表示转换器应接收相同 task graph 和 selected components |
| Q5 Component Scalability | `suite` 和 `configs/scalability.example.json` | 真实组件子集与 brief/detailed 描述条件，固定运行 schema |
| Q6 Efficiency | `run`、`report` | 构造 token 单独统计，执行与 embedding 用量分别保留。Direct answering 与单轮配置生成是不同方法 |
| Q7 Robustness | `suite`、`perturb` 和 `configs/robustness.example.json` | P1–P4 独立干预、低高嵌套、实际修改日志与配对结果 |
| 医疗与法律案例 | 本地问题、域资源和构造配置 | 可以通过相同入口执行。案例来源编号、真实资源和记录由实际输入指定 |

内置组件是共享接口的参考实现。其 prompt、工具实现与文献原方法的完整工程均通过 implementation ID 区分。`synthesis=compiled` 是确定性装配变体，模型辅助任务提取与组件判断仍保留。

本地消融分别由 `NoTaskStructureBuilder`、`GeneratedConfigurationBuilder`、`SequentialBuilder`、`SemanticIOAblationBuilder` 实现。整体单任务变体将全部允许输入序列化成一个求解义务。生成组件配置变体由模型提出注册操作路径，按提议顺序保留两个硬可行路径，不产生未计算的 utility 分数。串行变体在保留任务与组件选择后按拓扑顺序施加全序。语义 I/O 消融保留类型和必选绑定检查。完整历史变体可通过单独外部适配器接入。

## 执行与配置边界

构造器对模型返回 JSON 做覆盖、类型、绑定、完整路径、控制依赖和注册表成员校验。模型输出的语义判定记录与可执行性检查分别保存。阈值通过后再选择最高 utility 的固定两路径，成本极值不会因阈值过滤重算。

运行时每次 Exec activation 只调用一个已登记 operation。条件通过有限比较操作解释，不运行 Python `eval`。Choice 的 eligible successors 和标识符平局顺序固定。反馈同时消耗单边预算和整次应用预算，更新输入使相关下游 completion 失效。

时间预算检查与同步 HTTP 请求的超时共同限制运行。外部命令和独立 worker 各自有超时；部署用户仍需给 worker 提供实际进程隔离及资源限制。未归档的历史模板版本、配置顺序、运行成员和上游实验版本均由真实实验配置补充。
