# 实验与来源记录

## 运行状态

本项目实现的是论文方法的可执行参考流程。新实验使用新的运行 ID 和实际产生的事件。已有论文分数和作者确认记录保持原状。程序不从历史均值、标准差或候选池规模生成逐题输出。

每个输出目录包含以下材料。

| 文件 | 用途 |
| --- | --- |
| `experiment.json` | 实验 ID、方法、设置、种子和是否 fixture |
| `manifest.json` | 冻结问题成员、原输入与参考记录的摘要 |
| `configuration.json`, `registry.json` | 本次有效配置与实际接口 |
| `runs/<new-id>/harness.json` | 当前题、当前外层轮次实际返回的应用 |
| `runs/<new-id>/execution.json` | 真实执行事件、输出、错误与用量 |
| `runs/<new-id>/record.json` | 构造与执行状态、成本、时间和配置摘要 |
| `runs/<new-id>/provider_calls.json` | 服务端调用结果和返回用量，不含密钥 |
| `runs/<new-id>/intervention.json` | 成对扰动记录，仅扰动条件存在 |
| `predictions/*.json` | 完整预测队列，失败仍有原题位置 |
| `repeat_summaries.json`, `report.json` | 每轮指标、百分比均值、样本标准差 |

所有冻结题目都进入分母。尚未产生可评分输出的构造或执行失败按原位置保存。来源评分器不可用时，预测和错误仍保存，不输出替代分数。当前版本在收到返回值时核对预算与实际用量，已在服务端产生的 token 不会由于客户端预算超额而撤回。

## 正文编号与 BBH 的单独协议

当前活动文件 `CVPR/sec/4_experiments.tex` 的编号依次为 Q1 性能、Q2 构造范式、Q3 构造消融、Q4 组织表示、Q5 组件规模、Q6 构造效率和 Q7 鲁棒性。

`confirmed_bbh_ablation_protocol` 的历史字段保留 Q2 编号。代码对明确指定的 `bbh-ablation`、`ablation`、`construction_ablation`、`Q3` 和历史明确别名 `legacy-q2-ablation` 启用 BBH 的三个种子和对应评分。当前正文的 Q2 使用主协议五次重复，避免将构造范式实验与旧消融编号混淆。

BBH-Boolean 和 BBH-Mixed 候选池分别是 100 和 240。作者确认的单独消融评测数量分别是 10 和 30，但具体源文件、混合配置顺序和模板版本没有全部归档。用户应将实际成员清单传给 `select_cohort` 并冻结。主比较的 BBH 概念组宏平均，与单独消融使用的逐题 exact match 分别处理。

## 外部构造器协议

配置示例。

```json
{
  "external_adapters": {
    "my_method": {
      "implementation_id": "upstream-repo@actual-commit/adapter-v1",
      "command": ["python", "adapters/my_method.py"],
      "timeout_seconds": 120,
      "settings": {"development_manifest": "actual-development-manifest.json"}
    }
  }
}
```

每个命令调用通过 stdin 接收一个 JSON 对象，包含 `protocol`、`problem`、`seed`、共享 `registry` 与适配器 `settings`。`problem` 只含问题标识、领域、任务类别和允许的输入。参考答案、hidden tests 与评分输出不会传入。

stdout 必须仅输出一个 JSON 对象。

```json
{
  "harness": {"id": "actual-id", "problem_id": "source-id", "nodes": [], "edges": [], "entry": [], "outputs": {}},
  "construction_usage": {"model_calls": 2, "model_tokens": 1234}
}
```

上面的空 Harness 仅用于展示字段，实际响应必须包含完整且可校验的图。`construction_usage` 缺失时成本记为未知，不能填零。外部命令需要自行执行来源方法的搜索步骤并记录离线开发、搜索和在线构造成本。已配置命令的超时在父进程生效，外部服务预算由适配器明确实施。官方源码检查记录中的 commit 与实际实验 commit 分开保存。

## 来源评分器协议

在运行配置中为对应设置指定评分命令。

```json
{
  "scorers": {
    "FinQA": {
      "scorer": "execution_accuracy",
      "command": ["python", "evaluators/finqa_worker.py"],
      "timeout_seconds": 300,
      "revision": "actual-source-commit-and-wrapper-digest"
    }
  }
}
```

评分命令通过 stdin 接收 `problems` 和完整的 `predictions`。这是独立的评测层，可以访问 reference 和评测测试。stdout 返回一个 JSON 对象，至少包含 `[0,1]` 范围内的 `score`，并建议包含 `metric`、`count`、`per_problem`、来源版本与审核记录。执行前后保存评分包装器与源版本摘要。代码执行类评分应运行在用户提供的隔离 worker 中。

Python 接口也可以将 `official_evaluator(prediction, reference, problem)` 传给 `metrics.score_predictions`。FinQA 的执行结果、DROP 的 span/数值匹配、数学等价、代码测试与 FinanceBench 的正确响应判定分别使用相应来源实现。

## 成对扰动请求

运行配置中的 `intervention` 指定 `family`、`intensity` 和按 problem ID 索引的 `requests`。同一问题不同 seed 的审核和相关性记录可以使用 `problem_id:seed` 键。P1 每条 edit 包含 `original`、`replacement` 和两条不同 reviewer ID 的 `target_unchanged=true` 记录。代码仅验证已提供审核记录，不生成审核意见。

P2 在相同领域的组件对之间交换 capability 描述，保留真实运行 schema。P3 的每个组件需声明 `distractor_for` 等于当前 problem ID，并提供 `irrelevance_reviewed=true` 及可调用接口。P4 的 request 包含 `relevant_resource_ids` 和 `feasible_alternative_exists`，实际屏蔽由 problem ID、seed、family 的冻结顺序决定。每个 family 独立施加。每种条件都重新运行 Direct。

`suite` 以同一原始 manifest 和种子序列组织条件。每个条件的配置与实际修改分别落盘，报告计算配对外层分数差值。它不自动声明显著性，也不将低、高扰动混合成一个评测设置。
