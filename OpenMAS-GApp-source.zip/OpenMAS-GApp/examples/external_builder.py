"""JSON adapter example. Replace the body with a call into an upstream method.

Usage in configuration command: ["python", "examples/external_builder.py"].
This example is a local direct agent adapter, not an official baseline.
"""
import hashlib
import json
import sys


request = json.load(sys.stdin)
problem = request["problem"]
identifier = "external-direct-" + hashlib.sha256(problem["id"].encode()).hexdigest()[:12]
harness = {
    "id": identifier, "problem_id": problem["id"],
    "nodes": [{"id": "answer", "kind": "Exec", "component": "g.reason",
               "associations": ["g.reason"], "operation": "reason", "tasks": [],
               "bindings": {"question": {"value": json.dumps(problem["input"])}}}],
    "edges": [], "entry": ["answer"],
    "outputs": {"answer": {"node": "answer", "field": "answer"}}
}
json.dump({"harness": harness, "construction_usage": {"model_tokens": 0, "model_calls": 0}}, sys.stdout)
