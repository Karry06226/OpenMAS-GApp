"""OpenMAS-GApp executable benchmark and Graph Harness reference implementation."""

__version__ = "0.1.0"
