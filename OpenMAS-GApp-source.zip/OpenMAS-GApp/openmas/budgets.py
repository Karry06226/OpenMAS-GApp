"""Thread-safe, phase-local limits and measured usage."""
from __future__ import annotations

import math
import threading
import time


class BudgetExceeded(RuntimeError):
    pass


class Budget:
    def __init__(self, limits=None):
        self.limits = dict(limits or {})
        for key, value in self.limits.items():
            if key in {"seconds", "model_calls", "tool_calls", "model_tokens"}:
                if isinstance(value, bool) or not isinstance(value, (int, float)) or not math.isfinite(value) or value < 0:
                    raise ValueError(f"Invalid budget {key}")
        self.started = time.monotonic()
        self.counts = {"model_calls": 0, "tool_calls": 0, "model_tokens": 0}
        self.lock = threading.RLock()

    def _check_time(self):
        if time.monotonic() - self.started > self.limits.get("seconds", float("inf")):
            raise BudgetExceeded("Wall time budget exceeded")

    def check(self):
        with self.lock:
            self._check_time()
            for key, count in self.counts.items():
                if count > self.limits.get(key, float("inf")):
                    raise BudgetExceeded(f"{key} budget exceeded")

    def consume(self, model_calls=0, tool_calls=0, model_tokens=0):
        changes = dict(model_calls=model_calls, tool_calls=tool_calls, model_tokens=model_tokens)
        with self.lock:
            for key, value in changes.items():
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise ValueError(f"Invalid usage {key}")
            # Tokens describe an already returned response, including late responses.
            # Call reservations describe future work and must respect the deadline.
            if model_calls or tool_calls or not model_tokens:
                self._check_time()
            # Calls are reserved before execution; returned token usage is incurred even on overrun.
            for key in ("model_calls", "tool_calls"):
                if self.counts[key] + changes[key] > self.limits.get(key, float("inf")):
                    raise BudgetExceeded(f"{key} budget exceeded")
            for key, value in changes.items():
                self.counts[key] += value
            self.check()

    def snapshot(self):
        with self.lock:
            return {**self.counts, "seconds": time.monotonic() - self.started, "limits": dict(self.limits)}
