"""Command line entry points. Run `python -m openmas --help`."""
from __future__ import annotations

import argparse
import csv
import io
import json
from pathlib import Path
import sys

from .experiments import (load_config, make_registry, read_json, write_json,
                          run_experiment, evaluate_saved, digest, ExternalBuilder,
                          freeze_cohorts, validate_cohorts, run_suite)


def _print(value):
    print(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False))


def load_data(path, setting=None, adapter="auto"):
    from .datasets import load_problems
    if setting:
        return load_problems(path, setting, adapter=adapter)
    text = Path(path).read_text(encoding="utf-8-sig")
    if Path(path).suffix.lower() == ".jsonl":
        rows = [json.loads(line) for line in text.splitlines() if line.strip()]
    else:
        data = json.loads(text)
        rows = data.get("problems", data.get("data", [])) if isinstance(data, dict) else data
    if not isinstance(rows, list) or not rows or not all(isinstance(p, dict) and all(
            k in p for k in ("id", "setting", "input", "reference")) for p in rows):
        raise ValueError("Without --setting, --data must contain normalized problem records")
    # Use dataset adapter validation rather than accepting arbitrary records.
    normalized = []
    for name in sorted({p["setting"] for p in rows}):
        try:
            items = load_problems(path, name, adapter="normalized")
        except ValueError as exc:
            if len({p["setting"] for p in rows}) == 1:
                raise
            # Adapter may require all rows to share the supplied setting.
            from .datasets import freeze_manifest
            items = [p for p in rows if p["setting"] == name]
            freeze_manifest(items)
        normalized.extend(items)
    return normalized


def prepare(args):
    from .datasets import load_problems, freeze_manifest
    problems = load_problems(args.input, args.setting, adapter=args.adapter)
    output = Path(args.output)
    if output.exists():
        raise ValueError("Prepared output already exists")
    manifest = freeze_manifest(problems, source_revision=args.source_revision,
                               split=args.split, scorer_id=args.scorer or "", configuration_id=args.comparison)
    manifest_path = args.manifest or str(output.with_suffix(".manifest.json"))
    if Path(manifest_path).exists():
        raise ValueError("Manifest output already exists")
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text("".join(json.dumps(p, ensure_ascii=False, allow_nan=False) + "\n" for p in problems), encoding="utf-8")
    write_json(manifest_path, manifest)
    _print({"prepared": str(output), "manifest": str(manifest_path), "problems": len(problems)})


def validate(args):
    config = load_config(args.config)
    if args.harness:
        from .runtime import validate_harness
        registry = make_registry(config)
        validate_harness(read_json(args.harness), registry)
        _print({"valid": True, "harness": args.harness})
    elif args.data:
        problems = load_data(args.data, args.setting)
        if args.manifest:
            validate_cohorts(read_json(args.manifest), problems)
        else:
            freeze_cohorts(problems)
        _print({"valid": True, "problems": len(problems)})
    else:
        raise ValueError("Provide --harness or --data")


def build(args):
    from .construction import GraphHarnessBuilder, DirectBuilder
    from .datasets import public_problem
    from .providers import make_provider
    config = load_config(args.config)
    registry, provider = make_registry(config), make_provider(config["provider"])
    if args.method == "graph":
        builder = GraphHarnessBuilder(registry, provider, config)
    elif args.method == "direct":
        builder = DirectBuilder(registry, provider, config)
    elif args.method.startswith("external:"):
        name = args.method.partition(":")[2]
        builder = ExternalBuilder(registry, config.get("external_adapters", {})[name])
    else:
        from .variants import VARIANT_BUILDERS
        if args.method not in VARIANT_BUILDERS:
            raise ValueError("Unknown method. Use graph, direct, a named built-in variant, or external:<configured-name>")
        builder = VARIANT_BUILDERS[args.method](registry, provider, config)
    if Path(args.output).exists():
        raise ValueError("Harness output already exists")
    harness = builder.build(public_problem(read_json(args.problem)), seed=args.seed)
    write_json(args.output, harness)
    write_json(str(Path(args.output).with_suffix(".construction.json")), builder.last_record)
    _print({"harness": args.output, "problem_id": harness.get("problem_id")})


def run(args):
    problems = load_data(args.data, args.setting)
    if args.manifest:
        validate_cohorts(read_json(args.manifest), problems)
    config = load_config(args.config)
    report = run_experiment(problems, config, args.output_dir, methods=args.methods,
                            comparison_id=args.comparison, seeds=args.seeds)
    _print(report)


def execute(args):
    from .providers import make_provider
    from .runtime import HarnessRuntime
    config = load_config(args.config)
    if args.output and Path(args.output).exists():
        raise ValueError("Execution output already exists")
    registry = make_registry(config)
    harness = read_json(args.harness)
    # Pure local-tool harnesses do not require model credentials.
    has_agents = any(registry.get(n.get("component", "")).get("kind") == "agent"
                     for n in harness.get("nodes", []) if n.get("component"))
    provider = make_provider(config["provider"]) if has_agents else None
    runtime = HarnessRuntime(registry, provider=provider, limits=config.get("budgets", {}))
    result = runtime.execute(harness, read_json(args.input), seed=args.seed)
    if args.output:
        write_json(args.output, result)
    _print(result)


def evaluate(args):
    result = evaluate_saved(load_data(args.data, args.setting), read_json(args.predictions),
                             setting=args.setting, comparison_id=args.comparison, config=load_config(args.config))
    if args.output:
        write_json(args.output, result)
    _print(result)


def report(args):
    result = read_json(Path(args.directory) / "report.json")
    if args.format == "json":
        _print(result)
        return
    stream = io.StringIO()
    writer = csv.writer(stream)
    writer.writerow(["setting", "method", "mean_percent", "sample_sd_percentage_points", "status"])
    for setting, methods in result.get("settings", {}).items():
        for method, summary in methods.items():
            writer.writerow([setting, method, summary.get("mean"), summary.get("sample_sd"), summary.get("status", "evaluated")])
    print(stream.getvalue(), end="")


def demo(args):
    """Exercise actual local execution, traces, cohort scoring and repeat SD."""
    from .registry import default_registry
    from .runtime import HarnessRuntime
    from .datasets import freeze_manifest
    from .metrics import score_predictions, summarize_runs
    output = Path(args.output_dir)
    if output.exists() and any(output.iterdir()):
        raise ValueError("Demo output directory must be new or empty")
    output.mkdir(parents=True, exist_ok=True)
    problems = [
        {"id": "demo.addition", "setting": "DEMO", "domain": "general", "application_type": "arithmetic",
         "input": {"question": "Compute 2 + 3.", "expression": "2 + 3"}, "reference": 5, "metadata": {}},
        {"id": "demo.multiplication", "setting": "DEMO", "domain": "general", "application_type": "arithmetic",
         "input": {"question": "Compute 6 * 7.", "expression": "6 * 7"}, "reference": 42, "metadata": {}}
    ]
    write_json(output / "problems.json", problems)
    write_json(output / "manifest.json", freeze_manifest(problems, source_revision="local-demo-v1", split="demo"))
    registry = default_registry()
    scores = []
    for repeat, seed in enumerate([11, 22, 33, 44, 55], 1):
        predictions = {}
        for problem in problems:
            harness = {"id": f"{problem['id']}.{seed}", "problem_id": problem["id"],
                       "nodes": [{"id": "calculate", "kind": "Exec", "component": "t.calculate",
                                  "associations": ["t.calculate"], "operation": "calculate", "tasks": [],
                                  "bindings": {"expression": {"external": "expression"}}}],
                       "edges": [], "entry": ["calculate"],
                       "outputs": {"answer": {"node": "calculate", "field": "result"}},
                       "metadata": {"implementation": "local-calculator-demo", "is_fixture": True}}
            runtime = HarnessRuntime(registry, limits={"execution": {"seconds": 5, "tool_calls": 4}})
            result = runtime.execute(harness, problem["input"], seed=seed)
            predictions[problem["id"]] = result
            write_json(output / "runs" / f"{repeat}.{problem['id']}.harness.json", harness)
            write_json(output / "runs" / f"{repeat}.{problem['id']}.execution.json", result)
        metric = score_predictions(problems, predictions, scorer="numeric_answer_accuracy")
        scores.append(metric["score"])
        write_json(output / f"predictions.{repeat}.json", predictions)
    result = {"is_fixture": True, "new_execution": True, "paper_results_reproduced": False,
              "description": "Two local calculator problems; five deterministic execution repeats; no model calls.",
              "root_count": 10, "settings": {"DEMO": {"local_calculator": summarize_runs(scores)}}}
    write_json(output / "report.json", result)
    _print(result)


def perturb(args):
    from .perturbations import apply_perturbation
    request = read_json(args.request)
    problem, components, edit = apply_perturbation(**request)
    if Path(args.output).exists():
        raise ValueError("Perturbation output already exists")
    write_json(args.output, {"problem": problem, "components": components, "edit_record": edit})
    _print({"output": args.output, "edit_id": edit["edit_id"]})


def suite(args):
    problems = load_data(args.data, args.setting)
    if args.manifest:
        validate_cohorts(read_json(args.manifest), problems)
    _print(run_suite(problems, read_json(args.specification), args.output_dir,
                      base_config=load_config(args.config)))


def parser():
    p = argparse.ArgumentParser(prog="openmas", description="OpenMAS-GApp executable benchmark reference implementation")
    sub = p.add_subparsers(dest="command", required=True)
    catalogue = sub.add_parser("catalogue", help="List 19 benchmarks under 20 evaluation settings")
    catalogue.set_defaults(action=lambda _: _catalogue())
    item = sub.add_parser("prepare", help="Normalize a local dataset and freeze its manifest")
    item.add_argument("--input", required=True)
    item.add_argument("--setting", required=True)
    item.add_argument("--adapter", default="auto")
    item.add_argument("--output", required=True)
    item.add_argument("--manifest")
    item.add_argument("--source-revision", required=True)
    item.add_argument("--split", required=True)
    item.add_argument("--scorer")
    item.add_argument("--comparison", default="main")
    item.set_defaults(action=prepare)
    item = sub.add_parser("validate", help="Validate a harness or a frozen normalized cohort")
    item.add_argument("--harness")
    item.add_argument("--data")
    item.add_argument("--manifest")
    item.add_argument("--setting")
    item.add_argument("--config")
    item.set_defaults(action=validate)
    item = sub.add_parser("build", help="Construct one independent application")
    item.add_argument("--problem", required=True)
    item.add_argument("--method", default="graph")
    item.add_argument("--config")
    item.add_argument("--seed", type=int, default=11)
    item.add_argument("--output", required=True)
    item.set_defaults(action=build)
    item = sub.add_parser("run", help="Build, execute and evaluate every frozen problem per outer repeat")
    item.add_argument("--data", required=True)
    item.add_argument("--manifest")
    item.add_argument("--setting")
    item.add_argument("--config")
    item.add_argument("--methods", nargs="+", default=["graph"])
    item.add_argument("--comparison", default="main")
    item.add_argument("--seeds", nargs="+", type=int)
    item.add_argument("--output-dir", required=True)
    item.set_defaults(action=run)
    item = sub.add_parser("execute", help="Execute an existing harness on one input")
    item.add_argument("--harness", required=True)
    item.add_argument("--input", required=True)
    item.add_argument("--config")
    item.add_argument("--seed", type=int, default=11)
    item.add_argument("--output")
    item.set_defaults(action=execute)
    item = sub.add_parser("evaluate", help="Score one complete saved prediction cohort")
    item.add_argument("--data", required=True)
    item.add_argument("--predictions", required=True)
    item.add_argument("--setting")
    item.add_argument("--comparison", default="main")
    item.add_argument("--config")
    item.add_argument("--output")
    item.set_defaults(action=evaluate)
    item = sub.add_parser("report", help="Read generated results as JSON or CSV")
    item.add_argument("--directory", required=True)
    item.add_argument("--format", choices=["json", "csv"], default="json")
    item.set_defaults(action=report)
    item = sub.add_parser("demo", help="Run a local calculator integration demo without API keys")
    item.add_argument("--output-dir", default="outputs/demo")
    item.set_defaults(action=demo)
    item = sub.add_parser("perturb", help="Apply one supplied P1--P4 intervention request")
    item.add_argument("--request", required=True)
    item.add_argument("--output", required=True)
    item.set_defaults(action=perturb)
    item = sub.add_parser("suite", help="Run paired scalability or robustness conditions")
    item.add_argument("--data", required=True)
    item.add_argument("--setting")
    item.add_argument("--manifest")
    item.add_argument("--specification", required=True)
    item.add_argument("--config")
    item.add_argument("--output-dir", required=True)
    item.set_defaults(action=suite)
    return p


def _catalogue():
    from .protocol import suite_catalogue
    _print({"benchmark_count": 19, "evaluation_setting_count": 20, "settings": suite_catalogue()})


def main(argv=None):
    args = parser().parse_args(argv)
    try:
        args.action(args)
    except (ValueError, RuntimeError, KeyError, FileNotFoundError, OSError, json.JSONDecodeError) as exc:
        print(f"openmas: {exc}", file=sys.stderr)
        return 2
    return 0
