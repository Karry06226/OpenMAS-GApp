"""Local dataset adapters, input isolation, and immutable cohort manifests.

Downloads and split choices are explicit caller responsibilities. A local file is
never relabeled as an official split simply because its setting name matches.
"""
from __future__ import annotations

from collections import Counter
from copy import deepcopy
import csv
import gzip
import hashlib
import json
from pathlib import Path
import re
from typing import Iterable, Sequence

from .protocol import setting_info


SCIBENCH_FILES = ("atkins", "calculus", "chemmc", "class", "diff", "fund", "matter", "quan", "stat", "thermo")
_EVALUATOR_FIELDS = {"reference", "gold", "gold_answer", "answer", "solution", "target", "canonical_solution", "test", "test_list", "hidden_tests"}


def canonical_json(value) -> str:
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False)


def digest(value) -> str:
    return hashlib.sha256(canonical_json(value).encode("utf-8")).hexdigest()


def _first(record, *names, default=None):
    for name in names:
        if name in record and record[name] is not None:
            return record[name]
    return default


def _records(path: Path) -> list[dict]:
    """Read JSON(L), gzipped JSON(L), or CSV without fetching remote assets."""
    opener = gzip.open if path.suffix == ".gz" else open
    suffix = path.with_suffix("").suffix if path.suffix == ".gz" else path.suffix
    with opener(path, "rt", encoding="utf-8-sig", newline="") as handle:
        if suffix == ".csv":
            return list(csv.DictReader(handle))
        if suffix in {".jsonl", ".ndjson"}:
            return [json.loads(line) for line in handle if line.strip()]
        value = json.load(handle)
    if isinstance(value, list):
        return value
    if isinstance(value, dict):
        for key in ("examples", "data", "problems", "records"):
            if isinstance(value.get(key), list):
                return value[key]
        # PubMedQA: PMID keyed records; DROP: passage keyed records.
        if all(isinstance(row, dict) for row in value.values()):
            return [dict(row, _source_key=key) for key, row in value.items()]
    raise ValueError(f"Unsupported dataset container in {path}; expected records, examples, or an ID-keyed mapping")


def _choice_map(value) -> dict:
    if isinstance(value, dict):
        if "text" in value and "label" in value:
            return dict(zip(map(str, value["label"]), value["text"]))
        return {str(key): text for key, text in value.items()}
    if isinstance(value, list):
        if value and isinstance(value[0], dict):
            return {str(item.get("label", chr(65 + index))): item.get("text", item.get("content", "")) for index, item in enumerate(value)}
        return {chr(65 + index): text for index, text in enumerate(value)}
    return {}


def _bbh_group(task: str) -> str:
    # The two multi-file conceptual tasks are defined in BBH's published grouping.
    for prefix in ("logical_deduction", "tracking_shuffled_objects"):
        if task.startswith(prefix + "_"):
            return prefix
    return task


def _drop_answers(answer: dict) -> list[str]:
    if answer.get("number") not in (None, ""):
        return [str(answer["number"])]
    if answer.get("spans"):
        return list(answer["spans"])
    date = answer.get("date", {})
    return [" ".join(str(date[key]) for key in ("day", "month", "year") if date.get(key))]


def _adapt(record: dict, setting: str, source_name: str, index: int, *, adapter="auto") -> dict:
    if not isinstance(record, dict):
        raise ValueError(f"Expected object record at {source_name}:{index}")
    info = setting_info(setting)
    canonical = adapter == "normalized" or (adapter == "auto" and isinstance(record.get("input"), dict) and "reference" in record)
    if canonical:
        result = deepcopy(record)
        if result.get("setting", setting) != setting:
            raise ValueError("A normalized record cannot be silently assigned to a different setting")
        result.setdefault("setting", setting)
        result.setdefault("domain", info["domain"])
        result.setdefault("application_type", info["application_type"])
        if not str(result.get("id", "")):
            raise ValueError("Normalized problems require a nonempty ID")
        result["id"] = str(result["id"])
        return result
    if adapter not in {"auto", "source"}:
        raise ValueError(f"Unknown adapter {adapter!r}")
    original_id = _first(record, "id", "_id", "question_id", "task_id", "uid", "problem_id", "problemid", "example_id", "_source_key")
    identifier = str(original_id) if original_id is not None else f"{setting}/{source_name}/{index}"
    metadata = {"source_file": source_name, "source_index": index, "original_id": original_id}
    inputs = {}
    reference = None
    if setting in {"MMLU", "MMLU-Pro", "ARC", "MedQA"}:
        inputs["question"] = _first(record, "question", "input", "stem")
        if isinstance(inputs["question"], dict):
            question = inputs["question"]
            inputs["question"] = question.get("stem")
            choices = question.get("choices", [])
        else:
            choices = _first(record, "choices", "options", default=[])
        inputs["choices"] = _choice_map(choices)
        reference = _first(record, "answer_idx", "answerKey", "answer_index", "answer")
        # MMLU's integer labels index choices from zero; ARC numeric labels stay as released.
        if isinstance(reference, int) and setting in {"MMLU", "MMLU-Pro"}:
            reference = chr(65 + reference)
        if reference not in inputs["choices"]:
            found = [label for label, text in inputs["choices"].items() if text == reference]
            if len(found) == 1:
                reference = found[0]
        if record.get("subject"):
            metadata["subject"] = record["subject"]
    elif setting == "SciQ":
        inputs.update(question=record.get("question"), context=record.get("support", ""))
        # Source answer text is converted to an option label before it reaches a constructor.
        options = [record.get("correct_answer")] + [record.get(f"distractor{n}") for n in (1, 2, 3)]
        if any(option is None for option in options):
            raise ValueError("SciQ requires one correct answer and three distractors")
        # Stable hash ordering prevents position A from disclosing the correct label.
        options = sorted(enumerate(options), key=lambda pair: digest([identifier, pair[1], pair[0]]))
        inputs["choices"] = {chr(65 + i): value for i, (_, value) in enumerate(options)}
        reference = next(chr(65 + i) for i, (original, _) in enumerate(options) if original == 0)
    elif setting == "StrategyQA":
        inputs["question"] = record.get("question")
        reference = record.get("answer")
        if record.get("facts"):
            # Annotated reasoning facts are evaluator material, not permitted source input.
            metadata["has_annotated_facts"] = True
    elif setting == "PubMedQA":
        inputs["question"] = _first(record, "QUESTION", "question")
        inputs["context"] = _first(record, "CONTEXTS", "context", default=[])
        reference = _first(record, "final_decision", "answer")
    elif setting in {"GSM8K", "MATH-500"}:
        inputs["question"] = _first(record, "question", "problem")
        reference = _first(record, "answer", "final_answer")
        if setting == "MATH-500" and record.get("solution"):
            reference = {"answer": reference, "solution": record["solution"]}
        metadata.update({key: record[key] for key in ("subject", "level") if key in record})
    elif setting in {"HotpotQA", "MuSiQue"}:
        inputs["question"] = record.get("question")
        if setting == "HotpotQA":
            inputs["context"] = record.get("context", [])
            reference = {"answers": [record.get("answer", "")], "supporting_facts": record.get("supporting_facts", [])}
        else:
            inputs["context"] = [{"title": p.get("title", ""), "text": p.get("paragraph_text", p.get("text", "")),
                                   "idx": p.get("idx", i)} for i, p in enumerate(record.get("paragraphs", []))]
            reference = {"answers": [record.get("answer", "")] + record.get("answer_aliases", []),
                         "supporting_paragraphs": [p.get("idx", i) for i, p in enumerate(record.get("paragraphs", [])) if p.get("is_supporting")]}
    elif setting == "DROP":
        inputs.update(question=record.get("question"), context=record.get("passage", ""))
        answer = record.get("answer", {})
        reference = {"answers": _drop_answers(answer), "drop_answer": answer,
                     "validated_answers": record.get("validated_answers", [])}
    elif setting == "HumanEval":
        inputs.update(question=record.get("prompt"), entry_point=record.get("entry_point", ""))
        reference = {"test": record.get("test"), "entry_point": record.get("entry_point"),
                     "canonical_solution": record.get("canonical_solution")}
    elif setting == "MBPP":
        inputs["question"] = _first(record, "text", "prompt")
        if "example_tests" in record:
            inputs["example_tests"] = record["example_tests"]
        inputs["test_setup_code"] = record.get("test_setup_code", "")
        reference = {"test_list": record.get("test_list", []), "challenge_test_list": record.get("challenge_test_list", []), "code": record.get("code")}
        # test_list stays private; any allowed example tests must be explicitly supplied.
    elif setting == "FinQA":
        qa = record.get("qa", record)
        inputs.update(question=qa.get("question"), table=record.get("table", []),
                      pre_text=record.get("pre_text", []), post_text=record.get("post_text", []))
        reference = {"answer": qa.get("answer"), "program": qa.get("program"), "exe_ans": qa.get("exe_ans")}
    elif setting == "FinanceBench":
        inputs["question"] = record.get("question")
        # Reference excerpts are grading assets. Only explicit supplied report material is public.
        inputs["documents"] = record.get("documents", [])
        for key in ("doc_name", "doc_link", "doc_period", "question_type"):
            if key in record:
                inputs[key] = record[key]
        reference = {"answer": record.get("answer"), "evidence": record.get("evidence", [])}
    elif setting == "SciBench":
        inputs["question"] = record.get("problem_text")
        # The released prompt supplies the answer unit, after removing a scale
        # factor carried in the source unit. Preserve that public requirement.
        if record.get("unit") is not None:
            parts = re.split(r"\$?\s*10\^\{?\s*-?\d+\s*\}?\s*\$?", str(record["unit"]))
            inputs["answer_unit"] = parts[-1].strip() if len(parts) > 1 else str(record["unit"])
        reference = {"answer": _first(record, "answer_number", "answer_latex"),
                     "answer_latex": record.get("answer_latex"), "unit": record.get("unit")}
        # Some source IDs repeat. Row identity is always retained.
        identifier = f"SciBench/{source_name}/{index}"
    elif setting == "CaseHOLD":
        inputs["question"] = _first(record, "citing_prompt", "context", "question")
        endings = _first(record, "endings", "holdings")
        if endings is None:
            endings = [record.get(f"holding_{n}") for n in range(5)]
        inputs["choices"] = {str(i): value for i, value in enumerate(endings)}
        reference = str(_first(record, "label", "answer")) if _first(record, "label", "answer") is not None else None
    elif setting.startswith("BBH-"):
        task = record.get("task_name") or source_name.removesuffix(".json")
        if task in {"records", "problems", "data"}:
            raise ValueError("BBH source records require task_name")
        inputs["question"] = record.get("input")
        reference = record.get("target")
        within = record.get("within_task_index", index)
        identifier = f"{task}/{within}"
        metadata.update(task_name=task, group=_bbh_group(task), within_task_index=within)
    else:
        raise ValueError(f"No source adapter for {setting}")
    if inputs.get("question") is None:
        raise ValueError(f"Missing question for {setting} at {source_name}:{index}")
    if reference is None:
        raise ValueError(f"Missing evaluator reference for {setting} at {source_name}:{index}; official hidden-label evaluation needs a supplied evaluator export")
    return dict(id=identifier, setting=setting, domain=info["domain"], application_type=info["application_type"],
                input=inputs, reference=reference, metadata=metadata)


def _expand_drop(records: Iterable[dict]) -> list[dict]:
    expanded = []
    for record in records:
        if "qa_pairs" in record:
            for qa in record["qa_pairs"]:
                expanded.append(dict(qa, passage=record.get("passage", ""), id=qa.get("query_id"), passage_id=record.get("_source_key")))
        else:
            expanded.append(record)
    return expanded


def _validate_problems(problems: Sequence[dict]) -> None:
    if not problems:
        raise ValueError("Dataset contains no problems")
    ids = []
    for problem in problems:
        identifier = problem.get("id")
        if not isinstance(identifier, str) or not identifier:
            raise ValueError("Each problem requires a nonempty string ID")
        if "reference" not in problem:
            raise ValueError(f"Missing reference for {identifier}")
        if not isinstance(problem.get("input"), dict):
            raise ValueError(f"Expected input object for {identifier}")
        def private_fields(value):
            if isinstance(value, dict):
                found = _EVALUATOR_FIELDS.intersection(value)
                for child in value.values():
                    found |= private_fields(child)
                return found
            if isinstance(value, list):
                return set().union(*(private_fields(child) for child in value)) if value else set()
            return set()
        forbidden = private_fields(problem["input"])
        if forbidden:
            raise ValueError(f"Evaluator-only fields in public input for {identifier}: {sorted(forbidden)}")
        ids.append(identifier)
    if len(set(ids)) != len(ids):
        duplicates = sorted(identifier for identifier, count in Counter(ids).items() if count > 1)
        raise ValueError(f"Duplicate problem IDs: {duplicates}; preserve source task/row identity")


def load_problems(path: str | Path, setting: str, *, adapter="auto") -> list[dict]:
    """Normalize a local source file or canonical JSONL file.

    SciBench directories include exactly ten main evaluation files; `_sol` files
    are excluded. Build BBH pools through ``build_bbh_candidate_pool`` so its
    absent mixed configuration order cannot be guessed from directory ordering.
    """
    setting_info(setting)
    source = Path(path)
    if source.is_dir():
        if setting != "SciBench":
            raise ValueError("Directory input is supported for SciBench only; pass an explicit source file or BBH pool")
        files = [source / f"{name}.json" for name in SCIBENCH_FILES]
        if any(not file.is_file() for file in files):
            raise ValueError("SciBench directory must contain all ten main text evaluation files")
    else:
        files = [source]
    problems = []
    for file in files:
        if setting == "MMLU" and file.suffix == ".csv" and adapter != "normalized":
            # The original MMLU release uses headerless subject_test.csv files.
            with file.open(encoding="utf-8-sig", newline="") as handle:
                rows = list(csv.reader(handle))
            records = []
            for row in rows:
                if len(row) != 6:
                    raise ValueError("Original MMLU CSV records require question, four options, and answer")
                records.append(dict(question=row[0], choices=row[1:5], answer=row[5], subject=file.stem.removesuffix("_test")))
        else:
            records = _records(file)
        if setting == "DROP":
            records = _expand_drop(records)
        source_digest = hashlib.sha256(file.read_bytes()).hexdigest()
        for index, record in enumerate(records):
            problem = _adapt(record, setting, file.name, index, adapter=adapter)
            problem.setdefault("metadata", {}).setdefault("source_sha256", source_digest)
            problems.append(problem)
    _validate_problems(problems)
    return problems


def public_problem(problem: dict) -> dict:
    """Expose identity and permitted fields only, never references or metadata."""
    _validate_problems([problem])
    return {key: deepcopy(problem[key]) for key in ("id", "setting", "domain", "application_type", "input") if key in problem}


def freeze_manifest(problems: Sequence[dict], *, source_revision="", split="", scorer_id="", configuration_id="") -> dict:
    """Freeze ordered membership, input digests, evaluator digests and provenance."""
    _validate_problems(problems)
    settings = {problem.get("setting") for problem in problems}
    if len(settings) != 1:
        raise ValueError("Freeze one distinct evaluation setting per manifest")
    entries = []
    for problem in problems:
        meta = problem.get("metadata", {})
        entries.append(dict(problem_id=problem["id"], input_digest=digest(public_problem(problem)),
                            reference_digest=digest(problem["reference"]),
                            input_fields=sorted(problem["input"]),
                            task_name=meta.get("task_name"), group=meta.get("group"),
                            source_file=meta.get("source_file"), source_index=meta.get("source_index"),
                            source_digest=meta.get("source_sha256")))
    manifest = dict(schema_version="openmas.manifest.v1", setting=next(iter(settings)),
                    source_revision=source_revision, split=split, scorer_id=scorer_id,
                    configuration_id=configuration_id, count=len(entries), entries=entries)
    manifest["digest"] = digest(manifest)
    return manifest


def validate_manifest(manifest: dict, problems: Sequence[dict]) -> None:
    expected = deepcopy(manifest)
    claimed = expected.pop("digest", None)
    if claimed != digest(expected):
        raise ValueError("Manifest digest mismatch")
    rebuilt = freeze_manifest(problems, source_revision=manifest.get("source_revision", ""),
                              split=manifest.get("split", ""), scorer_id=manifest.get("scorer_id", ""),
                              configuration_id=manifest.get("configuration_id", ""))
    if rebuilt != manifest:
        raise ValueError("Frozen manifest does not match problem membership, order, content, or provenance")


def build_bbh_candidate_pool(directory: str | Path, setting: str, *, configuration_order: Sequence[str] | None = None) -> list[dict]:
    """Build a *candidate* pool, never automatically call it an evaluated cohort."""
    if setting not in {"BBH-Boolean", "BBH-Mixed"}:
        raise ValueError("BBH pool requires BBH-Boolean or BBH-Mixed")
    source = Path(directory)
    if setting == "BBH-Boolean":
        files = ["boolean_expressions"]
        count = 100
    else:
        if not configuration_order or len(configuration_order) != 27 or len(set(configuration_order)) != 27:
            raise ValueError("BBH-Mixed requires the explicitly supplied fixed order of 27 configurations; it is not present in the manuscript records")
        files = list(configuration_order)
        count = 240
    if any(not name or Path(name).name != name or name.endswith(".json") for name in files):
        raise ValueError("Configuration names must be plain task names without extensions")
    by_task = {name: load_problems(source / f"{name}.json", setting) for name in files}
    pool = []
    row = 0
    while len(pool) < count:
        progressed = False
        for name in files:
            if row < len(by_task[name]):
                pool.append(by_task[name][row])
                progressed = True
                if len(pool) == count:
                    break
        if not progressed:
            raise ValueError("Insufficient source examples for the declared BBH candidate pool")
        row += 1
    for problem in pool:
        problem["metadata"]["cohort_role"] = "candidate_pool"
    return pool


def select_cohort(problems: Sequence[dict], problem_ids: Sequence[str]) -> list[dict]:
    """Choose an explicit ordered evaluation membership from a prepared pool."""
    _validate_problems(problems)
    if not problem_ids or len(set(problem_ids)) != len(problem_ids):
        raise ValueError("Evaluation membership must contain distinct, explicit problem IDs")
    lookup = {problem["id"]: problem for problem in problems}
    missing = set(problem_ids) - set(lookup)
    if missing:
        raise ValueError(f"Unknown cohort IDs: {sorted(missing)}")
    selected = [deepcopy(lookup[identifier]) for identifier in problem_ids]
    for problem in selected:
        problem.setdefault("metadata", {})["cohort_role"] = "evaluation"
    return selected
