"""Per-problem experiments, durable records and explicit baseline adapters."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
from pathlib import Path
import statistics
import subprocess
import time
from datetime import datetime, timezone
import uuid


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(",", ":"), allow_nan=False).encode()).hexdigest()


def read_json(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def write_json(path, value):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_suffix(path.suffix + ".tmp")
    temporary.write_text(json.dumps(value, ensure_ascii=False, indent=2, allow_nan=False) + "\n", encoding="utf-8")
    temporary.replace(path)


def merge_config(base, updates):
    result = copy.deepcopy(base)
    for key, value in updates.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = merge_config(result[key], value)
        else:
            result[key] = copy.deepcopy(value)
    return result


def load_config(path=None):
    """Load formal settings without assuming a model display name is an API ID."""
    from .protocol import load_paper_config
    paper = load_paper_config()
    config = {key: copy.deepcopy(paper[key]) for key in
              ("models", "decoding", "selection", "budgets", "perturbations", "prompt_templates")
              if key in paper}
    config["provider"] = {"kind": "http", "base_url": "https://api.deepseek.com",
                          "model": None, "api_key_env": "DEEPSEEK_API_KEY",
                          "embedding": {"model": "text-embedding-3-large", "dimensions": 3072,
                                        "base_url": "https://api.openai.com/v1", "api_key_env": "OPENAI_API_KEY"}}
    if path:
        config = merge_config(config, read_json(path))
    return config


def make_registry(config):
    from .registry import Registry, default_registry
    if "registry_components" in config:
        return Registry(config["registry_components"])
    return default_registry(config.get("runtime_registry", {}))


class ExternalBuilder:
    """An explicitly configured external command, one JSON request per problem.

    No shell is used. The adapter receives no reference or evaluator tests.
    Existing upstream methods must supply their own installed command wrapper.
    """
    def __init__(self, registry, adapter):
        self.registry = registry
        self.adapter = copy.deepcopy(adapter)
        self.last_record = {}
        command = adapter.get("command")
        if not isinstance(command, list) or not command or not all(isinstance(x, str) for x in command):
            raise ValueError("External adapter command must be a nonempty list of arguments")
        if not adapter.get("implementation_id"):
            raise ValueError("External adapter requires an implementation_id")

    def build(self, problem, seed=11):
        from .validation import public_problem
        request = {"protocol": "openmas.external-builder.v1", "problem": public_problem(problem),
                   "seed": seed, "registry": list(self.registry.components.values()),
                   "settings": self.adapter.get("settings", {})}
        started = time.monotonic()
        try:
            process = subprocess.run(self.adapter["command"], input=json.dumps(request), text=True,
                                     encoding="utf-8", capture_output=True, shell=False,
                                     cwd=self.adapter.get("cwd"),
                                     timeout=float(self.adapter.get("timeout_seconds", 120)), check=False)
        except subprocess.TimeoutExpired:
            self.last_record = {"status": "failed", "reason": "external_timeout",
                                "seconds": time.monotonic() - started}
            raise ValueError("External construction command timed out") from None
        self.last_record = {"status": "returned", "returncode": process.returncode,
                            "seconds": time.monotonic() - started,
                            "implementation_id": self.adapter["implementation_id"]}
        if process.returncode:
            raise ValueError(f"External construction command failed with code {process.returncode}")
        if len(process.stdout.encode("utf-8")) > int(self.adapter.get("max_response_bytes", 2_000_000)):
            raise ValueError("External construction response exceeds size limit")
        try:
            response = json.loads(process.stdout)
        except json.JSONDecodeError:
            raise ValueError("External command must return exactly one JSON object") from None
        if not isinstance(response, dict) or not isinstance(response.get("harness"), dict):
            raise ValueError("External command must return {harness: ...}")
        usage = response.get("construction_usage")
        if usage is not None and not isinstance(usage, dict):
            raise ValueError("External construction_usage must be an object or null")
        self.last_record["usage"] = usage
        self.last_record["usage_available"] = usage is not None
        response["harness"].setdefault("metadata", {}).update({
            "method_implementation_id": self.adapter["implementation_id"],
            "external_builder": True})
        return response["harness"]


def _utc():
    return datetime.now(timezone.utc).isoformat()


def freeze_cohorts(problems, **kwargs):
    from .datasets import freeze_manifest
    settings = sorted({p["setting"] for p in problems})
    if len(settings) == 1:
        return freeze_manifest(problems, **kwargs)
    manifests = {setting: freeze_manifest([p for p in problems if p["setting"] == setting], **kwargs)
                 for setting in settings}
    value = {"schema_version": "openmas.manifest-suite.v1", "settings": manifests}
    value["digest"] = digest(value)
    return value


def validate_cohorts(manifest, problems):
    from .datasets import validate_manifest
    if manifest.get("schema_version") != "openmas.manifest-suite.v1":
        validate_manifest(manifest, problems)
        return
    value = copy.deepcopy(manifest)
    claimed = value.pop("digest", None)
    if claimed != digest(value):
        raise ValueError("Suite manifest digest mismatch")
    if set(manifest["settings"]) != {p["setting"] for p in problems}:
        raise ValueError("Suite manifest setting membership differs")
    for setting, cohort_manifest in manifest["settings"].items():
        validate_manifest(cohort_manifest, [p for p in problems if p["setting"] == setting])


def _summarize(scores):
    from .metrics import summarize_runs
    if len(scores) == 1:
        return {"mean": 100 * scores[0], "sample_sd": None, "scores": [100 * scores[0]],
                "normalized_scores": list(scores), "repeat_count": 1, "scale": "percentage",
                "ddof": 1, "status": "single_run_no_sample_sd"}
    return summarize_runs(scores)


def _score_config(setting, comparison_id, config):
    from .protocol import scoring_for
    overrides = config.get("scorers", {})
    specification = copy.deepcopy(overrides[setting]) if setting in overrides else scoring_for(setting, comparison=comparison_id)
    if isinstance(specification, str):
        specification = {"scorer": specification}
    return specification


def _score(problems, predictions, specification):
    from .metrics import score_predictions
    specification = copy.deepcopy(specification)
    identifiers = [p["id"] for p in problems]
    if len(identifiers) != len(set(identifiers)) or set(predictions) != set(identifiers):
        raise ValueError("Evaluation requires exactly one prediction slot per frozen problem")
    command = specification.pop("command", None)
    if command is not None:
        if not isinstance(command, list) or not command:
            raise ValueError("Scorer command must be an argument list")
        # Evaluation is a separate process and may access references and tests.
        response = subprocess.run(command, input=json.dumps({"problems": problems, "predictions": predictions}),
                                  capture_output=True, text=True, encoding="utf-8", shell=False,
                                  timeout=float(specification.pop("timeout_seconds", 300)), check=False)
        if response.returncode:
            raise ValueError(f"Scorer command failed with code {response.returncode}")
        result = json.loads(response.stdout)
        if not isinstance(result.get("score"), (int, float)) or not math.isfinite(result["score"]) or not 0 <= result["score"] <= 1:
            raise ValueError("External scorer must return score in [0,1]")
        return result
    return score_predictions(problems, predictions, **specification)


def run_experiment(problems, config, output_dir, *, methods=("graph",), comparison_id="main", seeds=None):
    """Run every frozen problem including failures, with independent construction.

    Directory must be new or empty. Completed root records are written before
    evaluation so an unavailable official evaluator never erases predictions.
    """
    from .construction import GraphHarnessBuilder, DirectBuilder
    from .datasets import freeze_manifest, public_problem
    from .metrics import summarize_runs, aggregate_settings
    from .providers import make_provider
    from .runtime import HarnessRuntime
    if not problems:
        raise ValueError("Cannot evaluate an empty cohort")
    if not methods or len(set(methods)) != len(methods):
        raise ValueError("Choose at least one distinct method")
    settings = sorted({p["setting"] for p in problems})
    scoring_contracts = {setting: _score_config(setting, comparison_id, config) for setting in settings}
    output = Path(output_dir)
    if output.exists() and any(output.iterdir()):
        raise ValueError("Output directory must be new or empty to preserve run records")
    output.mkdir(parents=True, exist_ok=True)
    manifest = freeze_cohorts(problems, source_revision=config.get("source_revision", "local-unversioned"),
                               split=config.get("split", "user-supplied"),
                               configuration_id=comparison_id,
                               scorer_id="contract-sha256:" + digest(scoring_contracts))
    write_json(output / "manifest.json", manifest)
    # API secrets belong to the environment. Do not persist embedded credentials.
    if any(key in str(config).lower() for key in ("'api_key':", '"api_key":', "'authorization':")):
        raise ValueError("Store API secrets in environment variables, not configuration")
    write_json(output / "configuration.json", config)
    registry = make_registry(config)
    write_json(output / "registry.json", list(registry.components.values()))
    common_id = digest({"manifest": manifest, "provider": config.get("provider"),
                        "registry": registry.components, "budgets": config.get("budgets"),
                        "decoding": config.get("decoding"), "resources": config.get("resources"),
                        "scoring_contracts": scoring_contracts})
    default_seeds = config.get("decoding", {}).get("root_seeds", [11, 22, 33, 44, 55])
    seed_map = {}
    for setting in settings:
        selected = list(seeds) if seeds is not None else list(default_seeds)
        if seeds is None and comparison_id.lower() in {"q3", "ablation", "construction_ablation", "bbh-ablation", "legacy-q2-ablation"} and setting in {"BBH-Boolean", "BBH-Mixed"}:
            selected = [11, 22, 33]
        if not selected or len(set(selected)) != len(selected) or not all(isinstance(s, int) and not isinstance(s, bool) for s in selected):
            raise ValueError("Seeds must be a nonempty list of distinct integers")
        seed_map[setting] = selected
    all_summaries, roots = [], []
    experiment_id = uuid.uuid4().hex
    write_json(output / "experiment.json", {"experiment_id": experiment_id, "created_utc": _utc(),
               "comparison_id": comparison_id, "settings": settings, "methods": list(methods),
               "seeds": seed_map, "shared_configuration_id": common_id,
               "is_fixture": config.get("provider", {}).get("kind") == "fixture",
               "new_execution": True, "paper_reported_results_imported": False})
    for method in methods:
        for setting in settings:
            cohort = [p for p in problems if p["setting"] == setting]
            for repeat, seed in enumerate(seed_map[setting], 1):
                predictions = {}
                records = []
                for problem in cohort:
                    active_problem, active_registry = problem, registry
                    intervention_record = None
                    intervention = config.get("intervention")
                    if intervention:
                        from .perturbations import apply_perturbation
                        from .registry import Registry
                        specifications = intervention.get("requests", {})
                        request = specifications.get(f"{problem['id']}:{seed}", specifications.get(problem["id"], {}))
                        active_problem, component_records, intervention_record = apply_perturbation(
                            problem, list(registry.components.values()), family=intervention["family"],
                            intensity=intervention["intensity"], seed=seed, repeat_id=repeat, **request)
                        active_registry = Registry(component_records)
                    run_id = uuid.uuid4().hex
                    folder = output / "runs" / run_id
                    folder.mkdir(parents=True)
                    provider = make_provider(config.get("provider"))
                    if method == "graph":
                        builder = GraphHarnessBuilder(active_registry, provider, config)
                    elif method == "direct":
                        builder = DirectBuilder(active_registry, provider, config)
                    elif method.startswith("external:"):
                        name = method.partition(":")[2]
                        if name not in config.get("external_adapters", {}):
                            raise ValueError(f"No external adapter configured for {name}")
                        builder = ExternalBuilder(active_registry, config["external_adapters"][name])
                    else:
                        from .variants import VARIANT_BUILDERS
                        if method not in VARIANT_BUILDERS:
                            raise ValueError(f"Unknown method {method}")
                        builder = VARIANT_BUILDERS[method](active_registry, provider, config)
                    record = {"run_id": run_id, "root_run_id": run_id, "experiment_id": experiment_id,
                              "problem_id": problem["id"], "setting": setting, "method_id": method,
                              "repeat_id": repeat, "root_seed": seed, "seed": seed,
                              "comparison_id": comparison_id, "root_start": _utc(), "submitted": True,
                              "shared_configuration_id": common_id,
                              "method_configuration_id": digest({"method": method, "selection": config.get("selection"),
                                                                  "prompts": config.get("prompt_templates"),
                                                                  "external": config.get("external_adapters", {}).get(method.partition(":")[2])}),
                              "input_digest": digest(public_problem(active_problem)),
                              "clean_input_digest": digest(public_problem(problem)),
                              "registry_digest": digest(active_registry.components),
                              "construction_returned": False, "execution_completed": False,
                              "scorable_output": False, "status": "failed", "output": {"answer": None}}
                    started = time.monotonic()
                    try:
                        if intervention_record:
                            write_json(folder / "intervention.json", intervention_record)
                            record["edit_id"] = intervention_record["edit_id"]
                            record["mask_id"] = intervention_record["mask_id"]
                        construction_start = time.monotonic()
                        record["construction_start"] = _utc()
                        harness = builder.build(public_problem(active_problem), seed=seed)
                        record.update(construction_returned=True, construction_end=_utc(),
                                      construction_seconds=time.monotonic() - construction_start)
                        write_json(folder / "harness.json", harness)
                        record["harness_path"] = str((folder / "harness.json").relative_to(output))
                        runtime = HarnessRuntime(active_registry, provider=provider, limits=config.get("budgets", {}))
                        execution_start = time.monotonic()
                        record["execution_start"] = _utc()
                        result = runtime.execute(harness, public_problem(active_problem)["input"], seed=seed)
                        write_json(folder / "execution.json", result)
                        record.update(output=result.get("output", {"answer": None}), status=result.get("status", "failed"),
                                      execution_completed=result.get("status") == "success", execution_end=_utc(),
                                      execution_seconds=time.monotonic() - execution_start,
                                      execution_usage=result.get("usage"), error=result.get("error"))
                        record["scorable_output"] = record["status"] == "success" and record["output"].get("answer") is not None
                    except Exception as exc:
                        record.update(error=f"{type(exc).__name__}: {exc}",
                                      failure_stage="execution" if record["construction_returned"] else "construction")
                    record.update(root_end=_utc(), root_wall_seconds=time.monotonic() - started,
                                  construction_record=copy.deepcopy(getattr(builder, "last_record", {})))
                    write_json(folder / "provider_calls.json", getattr(provider, "events", []))
                    write_json(folder / "record.json", record)
                    predictions[problem["id"]] = {"output": record["output"], "status": record["status"]}
                    roots.append(record)
                    records.append(record)
                key = digest({"method": method, "setting": setting, "repeat": repeat})[:20]
                write_json(output / "predictions" / f"{key}.json", predictions)
                specification = scoring_contracts[setting]
                try:
                    metric = _score(cohort, predictions, specification)
                    metric_error = None
                except Exception as exc:
                    metric, metric_error = None, f"{type(exc).__name__}: {exc}"
                summary = {"setting": setting, "method_id": method, "repeat_id": repeat, "root_seed": seed,
                           "submitted_problems": len(cohort), "scorable_outputs": sum(r["scorable_output"] for r in records),
                           "prediction_file": f"predictions/{key}.json", "metric": metric,
                           "metric_error": metric_error, "scorer": specification,
                           "scorer_digest": digest(specification),
                           "shared_configuration_id": common_id}
                all_summaries.append(summary)
                write_json(output / "repeat_summaries.json", all_summaries)
    report = {"experiment_id": experiment_id, "comparison_id": comparison_id, "new_execution": True,
              "is_fixture": config.get("provider", {}).get("kind") == "fixture",
              "settings": {}, "cross_setting": {}, "root_count": len(roots),
              "failure_count": sum(r["status"] != "success" for r in roots),
              "mean_construction_tokens": {}}
    for method in methods:
        method_metrics = {}
        for setting in settings:
            rows = [s for s in all_summaries if s["method_id"] == method and s["setting"] == setting]
            if all(s["metric"] is not None for s in rows):
                values = [s["metric"]["score"] for s in rows]
                method_metrics[setting] = values
                report["settings"].setdefault(setting, {})[method] = _summarize(values)
            else:
                report["settings"].setdefault(setting, {})[method] = {"status": "evaluation_required",
                    "errors": [s["metric_error"] for s in rows if s["metric_error"]]}
        if len(method_metrics) == len(settings) and len({len(v) for v in method_metrics.values()}) == 1:
            if len(next(iter(method_metrics.values()))) == 1:
                report["cross_setting"][method] = {**_summarize([statistics.mean(v[0] for v in method_metrics.values())]),
                                                     "settings": settings, "aggregation": "equal_weight_within_paired_run"}
            else:
                report["cross_setting"][method] = aggregate_settings(method_metrics, settings=settings)
        else:
            report["cross_setting"][method] = {"status": "unavailable", "reason": "missing_metrics_or_different_repeat_cohorts"}
        token_values = []
        missing_usage = 0
        for root in (r for r in roots if r["method_id"] == method):
            usage = root["construction_record"].get("usage")
            if isinstance(usage, dict) and isinstance(usage.get("model_tokens"), (int, float)):
                token_values.append(usage["model_tokens"])
            else:
                missing_usage += 1
        report["mean_construction_tokens"][method] = {"mean": statistics.mean(token_values) if token_values and not missing_usage else None,
                                                        "known_roots": len(token_values), "missing_roots": missing_usage}
    write_json(output / "report.json", report)
    return report


def evaluate_saved(problems, predictions, *, setting=None, comparison_id="main", config=None):
    if setting:
        problems = [p for p in problems if p["setting"] == setting]
    settings = {p["setting"] for p in problems}
    if len(settings) != 1:
        raise ValueError("Evaluate one setting at a time using --setting")
    return _score(problems, predictions, _score_config(next(iter(settings)), comparison_id, config or {}))


def run_suite(problems, specification, output_dir, *, base_config=None):
    """Run explicit paired conditions over one immutable cohort and seed list.

    Q5 varies runtime_registry size/description_detail. Q7 supplies one
    intervention family/intensity per condition with frozen review records.
    Method variants for Q2/Q3/Q4 remain named external adapters.
    """
    conditions = specification.get("conditions", [])
    if not conditions or len({c.get("id") for c in conditions}) != len(conditions):
        raise ValueError("Suite conditions require distinct nonempty IDs")
    if any(not isinstance(c.get("id"), str) or not c["id"] for c in conditions):
        raise ValueError("Suite condition IDs must be nonempty strings")
    base = merge_config(base_config or load_config(), specification.get("base_overrides", {}))
    methods = specification.get("methods", ["graph"])
    comparison = specification.get("comparison_id", "main")
    seeds = specification.get("seeds")
    settings = sorted({p["setting"] for p in problems})
    scoring_contracts = {setting: _score_config(setting, comparison, base) for setting in settings}
    configurations = []
    for condition in conditions:
        config = merge_config(base, condition.get("overrides", {}))
        if config.get("decoding", {}).get("root_seeds") != base.get("decoding", {}).get("root_seeds"):
            raise ValueError("Condition must not change outer seeds; use suite-level seeds")
        if any(config.get(field) != base.get(field) for field in ("source_revision", "split")):
            raise ValueError("Paired conditions must preserve source revision and split")
        if {setting: _score_config(setting, comparison, config) for setting in settings} != scoring_contracts:
            raise ValueError("Paired conditions must use the same scoring contracts")
        configurations.append(config)
    output = Path(output_dir)
    if output.exists() and any(output.iterdir()):
        raise ValueError("Suite output directory must be new or empty")
    output.mkdir(parents=True, exist_ok=True)
    manifest = freeze_cohorts(problems, source_revision=base.get("source_revision", "local-unversioned"),
                               split=base.get("split", "user-supplied"), configuration_id=comparison,
                               scorer_id="contract-sha256:" + digest(scoring_contracts))
    write_json(output / "base_manifest.json", manifest)
    write_json(output / "suite.json", specification)
    results, directories = {}, {}
    for index, condition in enumerate(conditions):
        config = configurations[index]
        folder = f"condition-{index + 1:02d}-{digest(condition['id'])[:10]}"
        results[condition["id"]] = run_experiment(problems, config, output / folder,
                                                   methods=methods, comparison_id=comparison, seeds=seeds)
        directories[condition["id"]] = folder
        write_json(output / "condition_reports.json", results)
    reference = specification.get("reference_condition", conditions[0]["id"])
    if reference not in results:
        raise ValueError("reference_condition must name one declared condition")
    deltas = {}
    for condition_id, condition_report in results.items():
        if condition_id == reference:
            continue
        deltas[condition_id] = {}
        for setting, method_results in condition_report.get("settings", {}).items():
            for method, summary in method_results.items():
                baseline = results[reference].get("settings", {}).get(setting, {}).get(method, {})
                if "scores" in summary and "scores" in baseline and len(summary["scores"]) == len(baseline["scores"]):
                    differences = [a - b for a, b in zip(summary["scores"], baseline["scores"])]
                    deltas[condition_id].setdefault(setting, {})[method] = {
                        "mean_delta_percentage_points": statistics.mean(differences),
                        "sample_sd_delta_percentage_points": statistics.stdev(differences) if len(differences) > 1 else None,
                        "paired_run_deltas": differences}
    report = {"comparison_id": comparison, "base_manifest_digest": manifest["digest"],
              "reference_condition": reference, "conditions": directories,
              "paired_fields": ["problem_id", "repeat_id", "root_seed"],
              "pairing_scope": "same frozen cohort and seed sequence; independent executions in every condition",
              "deltas": deltas, "new_execution": True, "paper_results_imported": False}
    write_json(output / "report.json", report)
    return report
