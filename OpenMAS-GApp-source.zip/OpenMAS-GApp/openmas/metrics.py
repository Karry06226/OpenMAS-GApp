"""Complete-cohort metrics and run aggregation, on the normalized [0, 1] scale."""
from __future__ import annotations

from collections import Counter, defaultdict
import math
import re
import statistics
import string
import unicodedata
from typing import Callable, Mapping, Sequence


_ABSENT = object()
_OFFICIAL_METRICS = {
    "mathematical_equivalence_accuracy", "drop_f1", "execution_accuracy",
    "correct_response_fraction", "pass_at_1",
}


def normalize_answer(value) -> str:
    """English QA normalization shared by answer EM and token-overlap F1."""
    text = unicodedata.normalize("NFKC", str(value)).lower()
    text = "".join(char for char in text if char not in string.punctuation)
    text = re.sub(r"\b(a|an|the)\b", " ", text)
    return " ".join(text.split())


def answer_f1(prediction, reference, *, special_answers=False) -> float:
    predicted, gold = normalize_answer(prediction), normalize_answer(reference)
    if special_answers and (predicted in {"yes", "no", "noanswer"} or gold in {"yes", "no", "noanswer"}):
        return float(predicted == gold)
    p_tokens, g_tokens = predicted.split(), gold.split()
    if not p_tokens or not g_tokens:
        return float(p_tokens == g_tokens)
    common = sum((Counter(p_tokens) & Counter(g_tokens)).values())
    return 2.0 * common / (len(p_tokens) + len(g_tokens))


def bbh_normalize(value) -> str:
    """Explicit final-answer extraction; retains order and numeric punctuation."""
    text = str(value).strip()
    match = re.search(r"(?:the\s+answer\s+is|final\s+answer\s*:)\s*(.+)", text, re.I | re.S)
    if match:
        text = match.group(1).strip()
    option = re.fullmatch(r"\(?([A-Za-z])\)?[.!]?", text)
    if option:
        return option.group(1).upper()
    return " ".join(text.rstrip(".").casefold().split())


def numeric_value(value) -> float | None:
    """Parse a final scalar, including GSM8K #### and simple LaTeX notation.

    Arbitrary formulas are not evaluated and a narrative without a declared
    final-answer delimiter is rejected rather than taking its last number.
    """
    if isinstance(value, bool) or value is None:
        return None
    if isinstance(value, (int, float)):
        return float(value) if math.isfinite(float(value)) else None
    text = str(value).strip()
    if "####" in text:
        text = text.rsplit("####", 1)[1].strip()
    final = re.search(r"(?:final\s+answer|answer)\s*(?:is|:|=)\s*(.+)$", text, re.I | re.S)
    if final:
        text = final.group(1).strip()
    box = re.fullmatch(r"\\boxed\{([^{}]+)\}", text)
    if box:
        text = box.group(1)
    text = text.replace(",", "").replace("−", "-").strip("$ ")
    text = re.sub(r"\\(?:times|cdot)\s*10\^\{?([+-]?\d+)\}?", r"e\1", text)
    text = re.sub(r"\s+", "", text)
    fraction = re.fullmatch(r"\\frac\{([+-]?[\d.]+)\}\{([+-]?[\d.]+)\}", text)
    if fraction:
        try:
            result = float(fraction.group(1)) / float(fraction.group(2))
            return result if math.isfinite(result) else None
        except (ValueError, ZeroDivisionError):
            return None
    if not re.fullmatch(r"[+-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[eE][+-]?\d+)?", text):
        return None
    try:
        result = float(text)
        return result if math.isfinite(result) else None
    except ValueError:
        return None


def _scibench_value(value) -> float | None:
    """Accept a declared scalar or the last boxed value, with trailing units.

    This is a local port of the archived release's boxed-answer, first-token,
    and scientific-notation rules. It never evaluates model-produced code.
    """
    if not isinstance(value, str):
        return numeric_value(value)
    text = value.strip()
    position = text.rfind("oxed{")
    if position >= 0:
        start = position + len("oxed{")
        level, end = 1, start
        while end < len(text) and level:
            level += (text[end] == "{") - (text[end] == "}")
            end += 1
        if level:
            return None
        text = text[start:end - 1]
        if "=" in text:
            text = text.rsplit("=", 1)[1].lstrip()
    number = numeric_value(text)
    if number is not None:
        return number
    # equiv in the release accepts a numeric first token followed by unit text.
    first = text.replace(",", "").split()
    return numeric_value(first[0]) if first else None


def scibench_numeric_match(prediction, reference, *, relative_tolerance=0.05, absolute_tolerance=0.0) -> float:
    """Apply the published symmetric tolerance and source-unit scale factors.

    Source: SciBench main e14e0ca3, eval/eval_zero.py and eval/post_process.py.
    A scalar application answer is already a declared final answer; a narrative
    answer must supply a boxed value. Missing and nonfinite values fail.
    """
    predicted = _scibench_value(prediction)
    if isinstance(reference, dict):
        gold = numeric_value(reference.get("answer"))
        unit = str(reference.get("unit", ""))
        scale = re.search(r"10\^\{?\s*(-?\d+)\s*\}?", unit)
        if gold is not None and scale:
            try:
                gold *= 10.0 ** int(scale.group(1))
            except OverflowError:
                gold = None
    else:
        gold = numeric_value(reference)
    return float(predicted is not None and gold is not None and math.isfinite(gold) and
                 math.isclose(predicted, gold, rel_tol=relative_tolerance, abs_tol=absolute_tolerance))


def _prediction(value):
    if isinstance(value, dict):
        if value.get("status", "success") != "success":
            return None
        if "output" in value:
            output = value["output"]
            return output.get("answer") if isinstance(output, dict) else output
        if "answer" in value:
            return value["answer"]
    return value


def _label(value, parser):
    if value is None:
        return None
    if isinstance(value, bool):
        return "yes" if value else "no"
    text = str(value).strip()
    if parser == "choice":
        match = re.fullmatch(r"\(?([A-Za-z0-9])\)?[.]?", text)
        if match:
            return match.group(1).upper()
        match = re.fullmatch(r"(?:the\s+)?(?:final\s+)?answer\s*(?:is|:)\s*\(?([A-Za-z0-9])\)?[.]?", text, re.I)
        return match.group(1).upper() if match else None
    if parser == "label":
        return text.lower().strip().rstrip(".")
    return text


def _references(reference):
    if isinstance(reference, dict):
        if "answers" in reference:
            return list(reference["answers"])
        if "answer" in reference:
            return [reference["answer"]]
    return list(reference) if isinstance(reference, list) else [reference]


def _validate_score(value) -> float:
    if isinstance(value, bool):
        return float(value)
    if not isinstance(value, (int, float)) or not math.isfinite(value) or not 0 <= value <= 1:
        raise ValueError("Evaluator must return a finite normalized score in [0, 1]")
    return float(value)


def score_predictions(problems: Sequence[dict], predictions: Mapping[str, object], *,
                      scorer="exact_match", labels=None, official_evaluator: Callable | None = None,
                      answer_parser=None, relative_tolerance=0.05, absolute_tolerance=0.0,
                      special_answers=False, **kwargs) -> dict:
    """Score every ID exactly once, including explicit failed/abstained slots.

    Source-specific metrics require an injected evaluator callable with signature
    ``evaluator(prediction, reference, problem) -> float``. It runs only in the
    evaluation layer; code evaluation should use a separately isolated worker.
    """
    if not problems:
        raise ValueError("Cannot score an empty cohort")
    ids = [str(p["id"]) for p in problems]
    if len(set(ids)) != len(ids):
        raise ValueError("Problem IDs must be unique within an evaluation setting")
    if set(predictions) != set(ids):
        missing, extra = sorted(set(ids) - set(predictions)), sorted(set(predictions) - set(ids))
        raise ValueError(f"Incomplete prediction cohort: missing={missing}, extra={extra}")
    supported = {"accuracy", "exact_match", "answer_em", "answer_f1", "macro_f1", "bbh_exact_match",
                 "group_macro_match", "numeric_answer_accuracy", "numeric_equivalence_accuracy"} | _OFFICIAL_METRICS
    if scorer not in supported:
        raise ValueError(f"Unknown metric {scorer!r}")
    if scorer in _OFFICIAL_METRICS and official_evaluator is None:
        raise ValueError(f"{scorer} requires a source-specific official_evaluator; no substitute is applied")
    if relative_tolerance < 0 or absolute_tolerance < 0:
        raise ValueError("Numerical tolerances must be nonnegative")
    answers = [_prediction(predictions[identifier]) for identifier in ids]
    references = [p["reference"] for p in problems]
    per_problem = {}
    if scorer == "macro_f1":
        if not labels or len(set(map(str, labels))) != len(labels):
            raise ValueError("macro_f1 requires a fixed, distinct, nonempty label set")
        scored_labels = list(map(str, labels))
        predicted = [_label(value, answer_parser or "label") for value in answers]
        gold = [_label(_references(ref)[0], answer_parser or "label") for ref in references]
        if any(value not in scored_labels for value in gold):
            raise ValueError("Reference label outside fixed label set")
        class_scores = {}
        for label in scored_labels:
            tp = sum(p == label and g == label for p, g in zip(predicted, gold))
            fp = sum(p == label and g != label for p, g in zip(predicted, gold))
            fn = sum(p != label and g == label for p, g in zip(predicted, gold))
            denominator = 2 * tp + fp + fn
            class_scores[label] = 2 * tp / denominator if denominator else 0.0
        return dict(score=statistics.mean(class_scores.values()), metric=scorer, count=len(ids),
                    per_problem={identifier: None for identifier in ids}, class_scores=class_scores)
    for problem, identifier, answer, reference in zip(problems, ids, answers, references):
        refs = _references(reference)
        if answer is None:
            score = 0.0
        elif scorer in _OFFICIAL_METRICS:
            score = _validate_score(official_evaluator(answer, reference, problem))
        elif scorer == "answer_f1":
            score = max(answer_f1(answer, ref, special_answers=special_answers) for ref in refs)
        elif scorer == "answer_em":
            score = float(any(normalize_answer(answer) == normalize_answer(ref) for ref in refs))
        elif scorer in {"bbh_exact_match", "group_macro_match"}:
            score = float(any(bbh_normalize(answer) == bbh_normalize(ref) for ref in refs))
        elif scorer == "numeric_equivalence_accuracy":
            score = scibench_numeric_match(answer, reference, relative_tolerance=relative_tolerance, absolute_tolerance=absolute_tolerance)
        elif scorer == "numeric_answer_accuracy":
            predicted = numeric_value(answer)
            values = [numeric_value(ref) for ref in refs]
            score = float(predicted is not None and any(value is not None and predicted == value for value in values))
        elif scorer == "accuracy":
            predicted = _label(answer, answer_parser)
            score = float(predicted is not None and any(predicted == _label(ref, answer_parser) for ref in refs))
        else:
            score = float(any(str(answer).strip() == str(ref).strip() for ref in refs))
        per_problem[identifier] = score
    if scorer == "group_macro_match":
        grouped = defaultdict(lambda: defaultdict(list))
        for problem in problems:
            meta = problem.get("metadata", {})
            group, task = meta.get("group"), meta.get("task_name")
            if not group or not task:
                raise ValueError("BBH group macro requires explicit metadata.group and metadata.task_name")
            grouped[group][task].append(per_problem[str(problem["id"])])
        file_scores = {group: {task: statistics.mean(values) for task, values in tasks.items()} for group, tasks in grouped.items()}
        group_scores = {group: statistics.mean(tasks.values()) for group, tasks in file_scores.items()}
        return dict(score=statistics.mean(group_scores.values()), metric=scorer, count=len(ids),
                    per_problem=per_problem, group_scores=group_scores, file_scores=file_scores)
    return dict(score=statistics.mean(per_problem.values()), metric=scorer, count=len(ids), per_problem=per_problem)


def summarize_runs(run_scores: Sequence[float | dict]) -> dict:
    """Convert normalized run metrics to percentage mean and sample SD once."""
    scores = [_validate_score(value["score"] if isinstance(value, dict) else value) for value in run_scores]
    if len(scores) < 2:
        raise ValueError("At least two complete outer runs are required for sample standard deviation")
    percent = [100.0 * score for score in scores]
    return dict(mean=statistics.mean(percent), sample_sd=statistics.stdev(percent), scores=percent,
                normalized_scores=scores, repeat_count=len(scores), scale="percentage", ddof=1)


def aggregate_settings(setting_run_scores: Mapping[str, Sequence[float | dict]], *, settings: Sequence[str]) -> dict:
    """Equal-weight an explicitly named set within each paired outer run."""
    if not settings or len(set(settings)) != len(settings):
        raise ValueError("Aggregate settings must be explicit, distinct, and nonempty")
    if any(setting not in setting_run_scores for setting in settings):
        raise ValueError("Aggregate references an unavailable setting")
    lengths = {len(setting_run_scores[setting]) for setting in settings}
    if len(lengths) != 1:
        raise ValueError("Settings must have the same paired outer-run count")
    normalized = {setting: [_validate_score(x["score"] if isinstance(x, dict) else x) for x in setting_run_scores[setting]] for setting in settings}
    count = next(iter(lengths))
    scores = [statistics.mean(normalized[setting][index] for setting in settings) for index in range(count)]
    result = summarize_runs(scores)
    result.update(settings=list(settings), aggregation="equal_weight_within_paired_run")
    return result
