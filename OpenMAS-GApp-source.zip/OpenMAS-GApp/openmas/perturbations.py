"""Frozen, paired P1--P4 interventions from the confirmed paper protocol.

Only supplied, reviewed ambiguity edits are accepted. The generator never
invents human review decisions or assumes a masked component is relevant.
"""
from __future__ import annotations

import copy
import hashlib
import json
import random


FAMILIES = {"P1": "ambiguity", "P2": "metadata", "P3": "distractors", "P4": "failure"}
COUNTS = {"P1": (1, 2), "P2": (2, 6), "P3": (5, 20), "P4": (2, 6)}


def _digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":")).encode()).hexdigest()


def _order(items, problem_id, seed, family):
    items = sorted(items, key=lambda item: str(item["id"]))
    rng = random.Random(int(_digest([problem_id, seed, family]), 16))
    rng.shuffle(items)
    return items


def apply_perturbation(problem, components, *, family, intensity, seed=11, repeat_id=1,
                       edits=None, distractors=None, relevant_resource_ids=None,
                       feasible_alternative_exists=None):
    """Return (modified_problem, modified_components, edit_record).

    Low/high select nested prefixes of the same frozen ordering. Families are
    applied independently by requiring pristine inputs for every invocation.
    """
    if family not in FAMILIES or intensity not in {"low", "high"}:
        raise ValueError("Use family P1/P2/P3/P4 and intensity low/high")
    if problem.get("metadata", {}).get("perturbation"):
        raise ValueError("Apply each perturbation family independently to a clean problem")
    if len(components) != 20:
        raise ValueError("The paper perturbation protocol requires a clean 20-component base pool")
    if len({c["id"] for c in components}) != len(components):
        raise ValueError("Duplicate component identifiers")
    changed_problem, changed_components = copy.deepcopy(problem), copy.deepcopy(components)
    count = COUNTS[family][intensity == "high"]
    record = {"family": family, "family_name": FAMILIES[family], "intensity": intensity,
              "problem_id": problem["id"], "repeat_id": repeat_id, "root_seed": seed,
              "original_input_digest": _digest(problem["input"]), "changed_component_ids": [],
              "reviewer_decisions": [], "original_text": [], "replacement_text": [], "mask_id": None}
    ordered = _order(changed_components, problem["id"], seed, family)
    if family == "P1":
        supplied = list(edits or [])
        if len(supplied) < count:
            raise ValueError(f"P1 {intensity} requires {count} supplied phrase edits")
        # Authoring order itself is frozen. It is shared across intensities.
        question = changed_problem["input"].get("question")
        if not isinstance(question, str):
            raise ValueError("P1 requires an input.question string")
        for edit in supplied[:count]:
            decisions = edit.get("reviewer_decisions", [])
            if len(decisions) != 2 or len({d.get("reviewer_id") for d in decisions}) != 2 or not all(
                    d.get("reviewer_id") and d.get("target_unchanged") is True for d in decisions):
                raise ValueError("Each ambiguity edit requires two distinct recorded reviewer approvals")
            original, replacement = edit.get("original"), edit.get("replacement")
            if not isinstance(original, str) or not original or not isinstance(replacement, str):
                raise ValueError("Ambiguity edit requires original and replacement strings")
            if question.count(original) != 1:
                raise ValueError("Ambiguity phrase must occur exactly once in the current question")
            question = question.replace(original, replacement, 1)
            record["original_text"].append(original)
            record["replacement_text"].append(replacement)
            record["reviewer_decisions"].append(copy.deepcopy(decisions))
        changed_problem["input"]["question"] = question
    elif family == "P2":
        # Swap only same-domain capability descriptions. Endpoints, IDs,
        # callable operations and true runtime input/output schemas stay fixed.
        pairs, pool = [], {}
        for component in ordered:
            key = tuple(sorted(component.get("domains", [])))
            pool.setdefault(key, []).append(component)
        for group in pool.values():
            pairs.extend([group[i:i + 2] for i in range(0, len(group) - 1, 2)])
        selected_pairs = pairs[:count // 2]
        selected = [c for pair in selected_pairs for c in pair]
        if len(selected) != count:
            raise ValueError("Not enough same-domain component pairs for metadata swaps")
        for group in selected_pairs:
            descriptions = [c.get("capability", "") for c in group]
            rotated = descriptions[1:] + descriptions[:1]
            if any(a == b for a, b in zip(descriptions, rotated)):
                raise ValueError("Metadata intervention needs distinct same-domain descriptions")
            for component, description in zip(group, rotated):
                record["original_text"].append(component.get("capability", ""))
                record["replacement_text"].append(description)
                component["capability"] = description
        record["changed_component_ids"] = [c["id"] for c in selected]
    elif family == "P3":
        candidates = _order(list(distractors or []), problem["id"], seed, family)
        if len(candidates) < count:
            raise ValueError(f"P3 {intensity} requires {count} supplied callable distractors")
        selected = copy.deepcopy(candidates[:count])
        used_ids = {c["id"] for c in changed_components}
        for component in selected:
            if component["id"] in used_ids:
                raise ValueError("Distractor IDs must be distinct from the base registry and each other")
            used_ids.add(component["id"])
            if not component.get("operation") or not component.get("inputs") or not component.get("outputs"):
                raise ValueError("Distractors need callable operation and interfaces")
            if component.get("distractor_for") != problem["id"] or component.get("irrelevance_reviewed") is not True:
                raise ValueError("Distractors require a supplied irrelevance assessment for this problem")
        changed_components.extend(selected)
        record["changed_component_ids"] = [c["id"] for c in selected]
    else:
        if relevant_resource_ids is None or not isinstance(feasible_alternative_exists, bool):
            raise ValueError("P4 requires supplied resource relevance and feasibility assessment")
        relevant = set(relevant_resource_ids)
        if not relevant.issubset({c["id"] for c in components}):
            raise ValueError("Relevant resource IDs must belong to the clean registry")
        selected = ordered[:count]
        for component in selected:
            component["available"] = False
            component.setdefault("config", {})["unavailable"] = True
        record["changed_component_ids"] = [c["id"] for c in selected]
        record["mask_id"] = _digest(record["changed_component_ids"])
        record["relevant_resource_ids"] = sorted(relevant)
        record["feasible_alternative_exists"] = feasible_alternative_exists
        touches_relevant = bool(relevant.intersection(record["changed_component_ids"]))
        record["failure_stratum"] = ("irrelevant_only_control" if not touches_relevant else
                                     "relevant_resource_with_feasible_alternative" if feasible_alternative_exists else
                                     "no_feasible_alternative")
    record["modified_input_digest"] = _digest(changed_problem["input"])
    record["original_registry_digest"] = _digest(components)
    record["modified_registry_digest"] = _digest(changed_components)
    record["edit_id"] = _digest(record)
    changed_problem.setdefault("metadata", {})["perturbation"] = {k: record[k] for k in
        ("edit_id", "family", "intensity", "repeat_id", "root_seed", "mask_id")}
    return changed_problem, changed_components, record


def description_variant(components, descriptions):
    """Replace prose only while keeping schema names/types and operations fixed."""
    result = copy.deepcopy(components)
    for component in result:
        supplied = descriptions.get(component["id"], {})
        for side in ("inputs", "outputs"):
            text = supplied.get(side, {})
            for field in component.get(side, []):
                if field["name"] in text:
                    if not isinstance(text[field["name"]], str):
                        raise ValueError("Interface descriptions must be strings")
                    field["description"] = text[field["name"]]
    return result
