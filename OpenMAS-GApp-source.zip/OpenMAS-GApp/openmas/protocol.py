"""Benchmark identities and scoring contracts read from the active manuscript.

The suite describes releases, not a claim that a particular cohort was executed.
"""
from __future__ import annotations

from copy import deepcopy
import json
from pathlib import Path


_SOURCES = [
    ("MMLU", "general", "general_reasoning", "test", "accuracy"),
    ("MMLU-Pro", "general", "general_reasoning", "test", "accuracy"),
    ("BBH-Boolean", "general", "general_reasoning", "manifest", "group_macro_match"),
    ("BBH-Mixed", "general", "general_reasoning", "manifest", "group_macro_match"),
    ("ARC", "general", "general_reasoning", "test", "accuracy"),
    ("StrategyQA", "general", "general_reasoning", "test", "accuracy"),
    ("GSM8K", "general", "mathematical_reasoning", "test", "numeric_answer_accuracy"),
    ("MATH-500", "general", "mathematical_reasoning", "test", "mathematical_equivalence_accuracy"),
    ("HotpotQA", "general", "reading_qa", "distractor_dev", "answer_f1"),
    ("MuSiQue", "general", "reading_qa", "dev", "answer_f1"),
    ("DROP", "general", "reading_qa", "dev", "drop_f1"),
    ("HumanEval", "general", "code_generation", "test", "pass_at_1"),
    ("MBPP", "general", "code_generation", "test", "pass_at_1"),
    ("MedQA", "medicine", "medical_qa", "test", "accuracy"),
    ("PubMedQA", "medicine", "biomedical_qa", "pqa_l_test", "accuracy"),
    ("FinQA", "finance", "financial_reasoning", "test", "execution_accuracy"),
    ("FinanceBench", "finance", "financial_qa", "public_annotated_150", "correct_response_fraction"),
    ("SciQ", "science", "scientific_qa", "test", "accuracy"),
    ("SciBench", "science", "scientific_reasoning", "main_text_only", "numeric_equivalence_accuracy"),
    ("CaseHOLD", "law", "holding_selection", "test", "macro_f1"),
]


def suite_catalogue() -> list[dict]:
    """Return 20 evaluation settings backed by 19 distinct benchmarks."""
    result = []
    for setting, domain, application_type, split, scorer in _SOURCES:
        item = dict(setting=setting, dataset="BIG-Bench Hard" if setting.startswith("BBH-") else setting,
                    domain=domain, application_type=application_type, split=split, scorer=scorer)
        if setting == "ARC":
            item.update(variant="ARC-Challenge", release_size=1172)
        if setting == "SciBench":
            item.update(variant="main_text_only", release_size=580)
        if setting == "MuSiQue":
            item["variant"] = "MuSiQue-Ans-v1.0"
        if setting.startswith("BBH-"):
            item["candidate_pool_size"] = 100 if setting == "BBH-Boolean" else 240
            item["requires_explicit_evaluation_manifest"] = True
        result.append(item)
    return result


def setting_info(setting: str) -> dict:
    for item in suite_catalogue():
        if item["setting"] == setting:
            return item
    raise ValueError(f"Unknown evaluation setting {setting!r}")


def scoring_for(setting: str, comparison: str = "main") -> dict:
    """Resolve the main metric or the separate, three-run BBH ablation.

    The active manuscript calls the ablation Q3. Historical protocol JSON names
    it Q2, which is available only through the explicit ``legacy-q2-ablation``
    alias. Current Q2 uses the main protocol. Prefer ``bbh-ablation`` in configs.
    """
    info = setting_info(setting)
    config = {"scorer": info["scorer"]}
    if setting in {"MMLU", "MMLU-Pro", "ARC", "MedQA", "SciQ"}:
        config["answer_parser"] = "choice"
    if setting in {"PubMedQA", "StrategyQA"}:
        config["answer_parser"] = "label"
    if setting == "CaseHOLD":
        config.update(labels=["0", "1", "2", "3", "4"], answer_parser="label")
    if setting == "SciBench":
        config.update(relative_tolerance=0.05, absolute_tolerance=0.0)
    if setting == "HotpotQA":
        config["special_answers"] = True
    if _is_ablation(comparison) and setting.startswith("BBH-"):
        config["scorer"] = "exact_match" if setting == "BBH-Boolean" else "bbh_exact_match"
    return config


def seeds_for(setting: str, comparison: str = "main") -> list[int]:
    setting_info(setting)
    return [11, 22, 33] if _is_ablation(comparison) and setting.startswith("BBH-") else [11, 22, 33, 44, 55]


def _is_ablation(comparison: str) -> bool:
    return comparison.lower() in {"ablation", "construction_ablation", "q3", "bbh-ablation", "legacy-q2-ablation"}


def load_paper_config(root: str | Path | None = None) -> dict:
    """Load the author-confirmed configuration at its compatibility filename."""
    base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    path = base / "CVPR" / "PROVISIONAL_CDE_CONFIG.json"
    if root is None and not path.is_file():
        path = Path(__file__).resolve().parent / "resources" / "paper_config.json"
    if not path.is_file():
        raise FileNotFoundError(f"Paper configuration unavailable at {path}; provide root explicitly")
    with path.open(encoding="utf-8-sig") as handle:
        return json.load(handle)


def load_source_versions(root: str | Path | None = None) -> dict:
    base = Path(root) if root is not None else Path(__file__).resolve().parents[1]
    path = base / "CVPR" / "protocol" / "official_source_versions.json"
    if root is None and not path.is_file():
        path = Path(__file__).resolve().parent / "resources" / "source_versions.json"
    with path.open(encoding="utf-8-sig") as handle:
        return json.load(handle)


def source_version(setting: str, root: str | Path | None = None) -> dict:
    """Return recorded source provenance only, leaving unrecorded values empty."""
    setting_info(setting)
    versions = load_source_versions(root)
    return deepcopy(versions.get("BBH" if setting.startswith("BBH-") else setting, {}))
