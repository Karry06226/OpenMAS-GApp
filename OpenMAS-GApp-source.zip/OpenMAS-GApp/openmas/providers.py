"""HTTP model clients and explicit offline fixtures. No automatic model substitution."""
from __future__ import annotations

import copy
import hashlib
import json
import math
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from .budgets import Budget


class ProviderError(RuntimeError):
    pass


class HTTPProvider:
    """Chat-completions compatible endpoint and separate embedding endpoint.

    Protocol references: https://api-docs.deepseek.com/api/create-chat-completion/
    https://developers.openai.com/api/reference/resources/embeddings/methods/create
    Model IDs must be deployment IDs supplied by the user. The paper's display
    name is retained in configuration; this client does not invent an API alias.
    """
    is_fixture = False

    def __init__(self, config=None, **kwargs):
        config = {**(config or {}), **kwargs}
        self.config = config
        self.base_url = config.get("base_url", "https://api.deepseek.com").rstrip("/")
        self.model = config.get("model") or os.environ.get("OPENMAS_MODEL")
        if not self.model:
            raise ValueError("Set provider.model or OPENMAS_MODEL to an actual deployed model ID")
        self.key_env = config.get("api_key_env", "DEEPSEEK_API_KEY")
        self.timeout = float(config.get("timeout", 60))
        self.retries = int(config.get("retries", 1))
        self.semaphore = threading.BoundedSemaphore(int(config.get("max_in_flight", 4)))
        self.events = []
        self.lock = threading.Lock()

    def _post(self, base_url, route, payload, key_env, timeout=None):
        parsed = urllib.parse.urlparse(base_url)
        if parsed.scheme not in {"https", "http"} or (parsed.scheme == "http" and parsed.hostname not in {"localhost", "127.0.0.1", "::1"}):
            raise ProviderError("Use HTTPS or a local HTTP endpoint")
        key = os.environ.get(key_env)
        if not key:
            raise ProviderError(f"Missing API key environment variable {key_env}")
        request = urllib.request.Request(base_url + route, json.dumps(payload).encode("utf-8"), {"Content-Type": "application/json", "Authorization": "Bearer " + key}, method="POST")
        with self.semaphore:
            try:
                with urllib.request.urlopen(request, timeout=self.timeout if timeout is None else timeout) as response:
                    return json.load(response)
            except urllib.error.HTTPError as exc:
                # Do not include headers, keys or server bodies in user-visible errors.
                raise ProviderError(f"Model endpoint returned HTTP {exc.code}") from None
            except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
                raise ProviderError(f"Model request failed ({type(exc).__name__})") from None

    def complete(self, messages, *, phase="execution", temperature=0.2, max_tokens=2048, seed=None, budget=None):
        payload = {"model": self.model, "messages": messages, "temperature": temperature, "max_tokens": max_tokens, "top_p": 1, "stream": False}
        if self.config.get("send_seed", False) and seed is not None:
            payload["seed"] = seed
        started = time.monotonic()
        last_error = None
        for attempt in range(self.retries + 1):
            if budget:
                budget.consume(model_calls=1)
            try:
                remaining = max(.001, budget.limits.get("seconds", float("inf")) - budget.snapshot()["seconds"]) if budget else self.timeout
                result = self._post(self.base_url, "/chat/completions", payload, self.key_env, timeout=min(self.timeout, remaining))
            except ProviderError as exc:
                last_error = exc
                self._event({"phase": phase, "attempt": attempt, "status": "failed", "model": self.model, "usage": None})
                if attempt < self.retries:
                    time.sleep(min(0.25 * 2 ** attempt, 2))
                    continue
                raise
            usage = result.get("usage")
            if not isinstance(usage, dict) or not all(isinstance(usage.get(key), int) and usage[key] >= 0 for key in ("prompt_tokens", "completion_tokens")):
                raise ProviderError("Model endpoint omitted measured token usage")
            record = {"phase": phase, "attempt": attempt, "status": "returned", "model": result.get("model", self.model), "usage": usage, "request_id": result.get("id"), "seconds": time.monotonic() - started}
            self._event(record)
            if budget:
                budget.consume(model_tokens=usage["prompt_tokens"] + usage["completion_tokens"])
            try:
                content = result["choices"][0]["message"]["content"]
                if not isinstance(content, str):
                    raise ValueError("Missing message content")
            except (KeyError, IndexError, TypeError, ValueError):
                raise ProviderError("Malformed chat response") from None
            return {"text": content, "usage": usage, "model": record["model"]}
        raise last_error

    def _event(self, record):
        with self.lock:
            self.events.append(record)

    def embed(self, texts, budget=None):
        if not texts:
            return []
        cfg = self.config.get("embedding", {})
        payload = {"model": cfg.get("model", "text-embedding-3-large"), "input": texts, "encoding_format": "float"}
        if cfg.get("dimensions"):
            payload["dimensions"] = cfg["dimensions"]
        remaining = max(.001, budget.limits.get("seconds", float("inf")) - budget.snapshot()["seconds"]) if budget else self.timeout
        result = self._post(cfg.get("base_url", "https://api.openai.com/v1").rstrip("/"), "/embeddings", payload, cfg.get("api_key_env", "OPENAI_API_KEY"), timeout=min(self.timeout, remaining))
        try:
            data = sorted(result["data"], key=lambda row: row["index"])
            if [row["index"] for row in data] != list(range(len(texts))):
                raise ValueError("Invalid embedding indices")
            vectors = [row["embedding"] for row in data]
            if not vectors or not vectors[0] or len({len(v) for v in vectors}) != 1:
                raise ValueError("Invalid embedding dimensions")
            if any(not isinstance(x, (int, float)) or not math.isfinite(x) for v in vectors for x in v):
                raise ValueError("Nonfinite embedding")
        except (KeyError, TypeError, ValueError):
            raise ProviderError("Malformed embedding response") from None
        self._event({"phase": "embedding", "model": payload["model"], "usage": result.get("usage"), "status": "returned"})
        return vectors


class FixtureProvider:
    """Offline integration fixture, never a substitute for an experimental model."""
    is_fixture = True
    model = "offline-fixture-v1"

    def __init__(self, responses=None, **kwargs):
        self.responses = list(responses or [])
        self.events = []
        self.lock = threading.Lock()

    def complete(self, messages, *, phase="execution", temperature=0.2, max_tokens=2048, seed=None, budget=None):
        if budget:
            budget.consume(model_calls=1)
        with self.lock:
            if self.responses:
                response = self.responses.pop(0)
                text = response if isinstance(response, str) else json.dumps(response)
            else:
                raise ProviderError("Offline fixture has no scripted response for this call")
            record = {"phase": phase, "model": self.model, "usage": {"prompt_tokens": 0, "completion_tokens": 0}, "usage_kind": "fixture_no_model_invocation", "status": "returned"}
            self.events.append(record)
        return {"text": text, "usage": record["usage"], "model": self.model}

    def embed(self, texts):
        # Stable token hashing is ONLY for offline control-flow tests.
        result = []
        for text in texts:
            vector = [0.0] * 64
            for token in re.findall(r"\w+", text.lower()):
                code = int(hashlib.sha256(token.encode()).hexdigest()[:8], 16)
                vector[code % len(vector)] += 1.0
            result.append(vector)
        return result


class BudgetedProvider:
    def __init__(self, provider, budget):
        self.provider = provider
        self.budget = budget
        self.is_fixture = getattr(provider, "is_fixture", False)

    def complete(self, messages, **kwargs):
        if isinstance(self.provider, (HTTPProvider, FixtureProvider)):
            kwargs["budget"] = self.budget
            return self.provider.complete(messages, **kwargs)
        self.budget.consume(model_calls=1)
        result = self.provider.complete(messages, **kwargs)
        usage = result.get("usage", {})
        if not all(isinstance(usage.get(k), int) and usage[k] >= 0 for k in ("prompt_tokens", "completion_tokens")):
            raise ProviderError("Provider must report measured usage")
        self.budget.consume(model_tokens=usage["prompt_tokens"] + usage["completion_tokens"])
        return result

    def embed(self, texts):
        self.budget.check()
        result = self.provider.embed(texts, budget=self.budget) if isinstance(self.provider, HTTPProvider) else self.provider.embed(texts)
        self.budget.check()
        return result


def make_provider(config=None):
    config = dict(config or {})
    kind = config.pop("kind", config.pop("type", "http"))
    if kind == "fixture":
        return FixtureProvider(**config)
    if kind in {"http", "openai_compatible"}:
        return HTTPProvider(config)
    raise ValueError(f"Unknown provider kind {kind}")
