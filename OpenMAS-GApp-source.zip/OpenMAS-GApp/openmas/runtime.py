"""Validated, versioned execution of typed Graph Harnesses.

Control state belongs to one execute call. Parallel frontiers share a thread-safe
budget, while completion records and transitions are committed in identifier
order. Feedback creates a new generation of every affected node; a join can
therefore never consume a completion left over from an earlier fork invocation.
"""
from __future__ import annotations

from concurrent.futures import ThreadPoolExecutor
from copy import deepcopy
from datetime import datetime, timezone
import hashlib
import math
import threading
import time

from .budgets import Budget
from .providers import BudgetedProvider
from .validation import (
    assignable, topological_order, validate_source, validate_values,
)


class ExecutionError(RuntimeError):
    """An application could not satisfy its declared execution contract."""


class MissingValue(ExecutionError):
    """A source has no current value; this is distinct from JSON null."""


_OPS = {"eq", "ne", "lt", "le", "gt", "ge", "truthy", "falsy"}
_FORWARD = {"Seq", "Alt", "Par"}


def _mapping(value, description):
    if not isinstance(value, dict):
        raise ValueError(f"{description} must be an object")
    return value


def _identifier(value, description):
    if not isinstance(value, str) or not value:
        raise ValueError(f"{description} must be a nonempty string")
    return value


def _unique(records, description):
    if not isinstance(records, list):
        raise ValueError(f"{description} must be a list")
    result = {}
    for record in records:
        _mapping(record, description)
        identifier = _identifier(record.get("id"), f"{description} identifier")
        if identifier in result:
            raise ValueError(f"Duplicate {description} identifier {identifier}")
        result[identifier] = record
    return result


def _registry_component(registry, identifier):
    try:
        component = registry.get(identifier)
    except (KeyError, TypeError):
        raise ValueError(f"Unregistered component {identifier}") from None
    if not isinstance(component, dict):
        raise ValueError(f"Unregistered component {identifier}")
    return component


def _walk_sources(harness):
    for node in harness["nodes"]:
        yield from node.get("bindings", {}).values()
    for edge in harness.get("edges", []):
        yield from edge.get("bindings", {}).values()
        if edge.get("condition"):
            yield edge["condition"]["source"]
    yield from harness["outputs"].values()
    for outputs in harness.get("task_outputs", {}).values():
        yield from outputs.values()


def validate_harness(harness, registry):
    """Check the full graph before invoking any agent or tool.

    External values are checked against component contracts at activation time.
    Static producer types and constant bindings are checked here as well.
    """
    _mapping(harness, "Harness")
    nodes = _unique(harness.get("nodes"), "node")
    if not nodes:
        raise ValueError("Harness has no nodes")
    edges = _unique(harness.get("edges", []), "edge")
    entry = harness.get("entry")
    if not isinstance(entry, list) or not entry or len(set(entry)) != len(entry):
        raise ValueError("Harness requires distinct entry nodes")
    if any(node not in nodes for node in entry):
        raise ValueError("Harness entry references a missing node")
    outputs = _mapping(harness.get("outputs"), "Harness outputs")
    if not outputs:
        raise ValueError("Harness requires final output bindings")
    components = {}
    for node_id, node in nodes.items():
        if node.get("kind") not in {"Exec", "Choice"}:
            raise ValueError(f"Unknown node kind at {node_id}")
        _mapping(node.get("bindings", {}), f"Bindings for {node_id}")
        tasks = node.get("tasks", [])
        if not isinstance(tasks, list) or any(not isinstance(t, str) for t in tasks):
            raise ValueError(f"Invalid task assignments at {node_id}")
        if node["kind"] == "Choice":
            if tasks:
                raise ValueError("Choice nodes cannot carry task assignments")
            if node.get("component"):
                raise ValueError("Choice nodes cannot invoke a component")
            continue
        component_id = _identifier(node.get("component"), f"Component for {node_id}")
        component = _registry_component(registry, component_id)
        components[node_id] = component
        associations = node.get("associations", [])
        if not isinstance(associations, list) or component_id not in associations:
            raise ValueError(f"Selected component is not associated with {node_id}")
        for associated_id in associations:
            _registry_component(registry, associated_id)
        operation = node.get("operation", component.get("operation"))
        allowed = component.get("operations", [component.get("operation")])
        if operation not in allowed:
            raise ValueError(f"Operation {operation} is not registered for {component_id}")

    incoming = {node_id: [] for node_id in nodes}
    outgoing = {node_id: [] for node_id in nodes}
    for edge_id, edge in edges.items():
        if edge.get("source") not in nodes or edge.get("target") not in nodes:
            raise ValueError(f"Dangling edge {edge_id}")
        kind = edge.get("type")
        if kind not in _FORWARD | {"Fb"}:
            raise ValueError(f"Invalid edge type at {edge_id}")
        if edge["source"] == edge["target"] and kind != "Fb":
            raise ValueError("Only feedback edges may be self loops")
        if kind == "Alt" and nodes[edge["source"]]["kind"] != "Choice":
            raise ValueError("Alternative transitions require a Choice source")
        priority = edge.get("priority", 0)
        if isinstance(priority, bool) or not isinstance(priority, (int, float)) or not math.isfinite(priority):
            raise ValueError(f"Invalid routing priority at {edge_id}")
        if "max_traversals" in edge:
            count = edge["max_traversals"]
            if isinstance(count, bool) or not isinstance(count, int) or count < 0:
                raise ValueError(f"Invalid feedback bound at {edge_id}")
        _mapping(edge.get("bindings", {}), f"Edge bindings at {edge_id}")
        condition = edge.get("condition")
        if condition is not None:
            _mapping(condition, f"Condition at {edge_id}")
            if condition.get("op") not in _OPS or "source" not in condition:
                raise ValueError(f"Invalid typed condition at {edge_id}")
            if condition["op"] not in {"truthy", "falsy"} and "value" not in condition:
                raise ValueError(f"Condition at {edge_id} requires a comparison value")
        outgoing[edge["source"]].append(edge)
        if kind != "Fb":
            incoming[edge["target"]].append(edge)
    order = topological_order(nodes, [(e["source"], e["target"]) for e in edges.values() if e["type"] != "Fb"])
    roots = {node_id for node_id in nodes if not incoming[node_id]}
    if roots != set(entry):
        raise ValueError("Entry nodes must be exactly the roots of the forward graph")
    for node_id in nodes:
        normal = [edge for edge in outgoing[node_id] if edge["type"] != "Fb"]
        if any(edge["type"] == "Alt" for edge in normal) and any(edge["type"] != "Alt" for edge in normal):
            raise ValueError(f"Alternative and unconditional routing cannot be mixed at {node_id}")

    task_outputs = _mapping(harness.get("task_outputs", {}), "Task output aliases")
    for task_id, fields in task_outputs.items():
        _identifier(task_id, "Task output identifier")
        _mapping(fields, "Task output bindings")
    for source in _walk_sources(harness):
        validate_source(source)
        if "external" in source:
            _identifier(source["external"], "External source field")
        if "node" in source:
            source_id = source["node"]
            if source_id not in components:
                raise ValueError(f"Binding references missing execution node {source_id}")
            field_names = {field["name"] for field in components[source_id].get("outputs", [])}
            if source["field"] not in field_names:
                raise ValueError(f"Binding references missing output {source_id}.{source['field']}")

    def check_alias(source, visited=None):
        if "task" not in source:
            return
        key = (source["task"], source["field"])
        visited = set(visited or ())
        if key in visited:
            raise ValueError("Cyclic task output alias")
        visited.add(key)
        alias = task_outputs.get(key[0], {}).get(key[1])
        if alias is not None:
            check_alias(alias, visited)
        elif not any(key[0] in node.get("tasks", []) and key[1] in {f["name"] for f in components[node_id].get("outputs", [])}
                     for node_id, node in nodes.items() if node_id in components):
            raise ValueError(f"Unknown task output {key[0]}.{key[1]}")

    for source in _walk_sources(harness):
        check_alias(source)

    # Edge-provided bindings are accepted for a required input, but must have one
    # unambiguous active producer when its node becomes ready.
    for node_id, component in components.items():
        declared = dict(nodes[node_id].get("bindings", {}))
        for edge in edges.values():
            if edge["target"] == node_id:
                declared.update(edge.get("bindings", {}))
        for field in component.get("inputs", []):
            name = field["name"]
            if name not in declared:
                if field.get("required", True):
                    raise ValueError(f"Missing required binding {node_id}.{name}")
                continue
            source = declared[name]
            if "value" in source:
                validate_values([field], {name: source["value"]})
            elif "node" in source:
                produced = next(f for f in components[source["node"]].get("outputs", []) if f["name"] == source["field"])
                if not assignable(produced.get("type", "any"), field.get("type", "any")):
                    raise ValueError(f"Incompatible producer type for {node_id}.{name}")

    # Task obligations and waiting relations remain fixed after synthesis.
    graph = harness.get("task_graph")
    if graph:
        tasks = {t["id"]: t for t in graph.get("tasks", []) if t.get("selected", True)}
        assignments = {task_id: [] for task_id in tasks}
        for node_id, node in nodes.items():
            for task_id in node.get("tasks", []):
                if task_id not in tasks:
                    raise ValueError(f"Unknown assigned task {task_id}")
                assignments[task_id].append(node_id)
        if any(not assigned for assigned in assignments.values()):
            raise ValueError("Harness does not cover every selected task")
        reach = {node_id: set() for node_id in nodes}
        for node_id in reversed(order):
            for edge in outgoing[node_id]:
                if edge["type"] != "Fb":
                    reach[node_id].add(edge["target"])
                    reach[node_id].update(reach[edge["target"]])
        for dependency in graph.get("dependencies", []):
            source, target = dependency["source"], dependency["target"]
            if source not in assignments or target not in assignments:
                raise ValueError("Task dependency references an unselected task")
            # Every operation discharging the prerequisite task must finish
            # before any operation of its successor task becomes eligible.
            if not all(b in reach[a] for a in assignments[source] for b in assignments[target]):
                raise ValueError(f"Harness lost waiting relation {source} -> {target}")
    return harness


class HarnessRuntime:
    """Execute one independently constructed application for one problem.

    Deadlines are checked before and after each bounded registry call. HTTP
    transports and isolated tool workers enforce their own call timeouts.
    Custom in-process handlers must cooperate with deadline_monotonic; Python
    cannot forcibly stop a running user-supplied thread.
    """

    def __init__(self, registry, *, provider=None, limits=None):
        self.registry = registry
        self.provider = provider
        self.limits = dict(limits or {})
        if "execution" in self.limits:
            execution = self.limits.pop("execution")
            if not isinstance(execution, dict):
                raise ValueError("Execution budget must be an object")
            self.limits.update(execution)
        for key in ("feedback_per_edge", "feedback_global", "external_calls_in_flight", "service_retries"):
            if key in self.limits:
                value = self.limits[key]
                if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                    raise ValueError(f"Invalid execution limit {key}")
        if self.limits.get("external_calls_in_flight", 4) == 0:
            raise ValueError("external_calls_in_flight must be positive")

    def execute(self, harness, inputs, seed=11):
        """Return actual outputs, chronological events, and measured usage.

        Invalid graphs return a failed result before any component invocation.
        No predicted answer or reference record is generated on failure.
        """
        budget = Budget(self.limits)
        events = []
        started = time.monotonic()
        run_id = hashlib.sha256(f"{harness.get('id', '')}:{seed}:{time.time_ns()}".encode()).hexdigest()[:24] if isinstance(harness, dict) else None
        state = _Execution(self.registry, self.provider, budget, self.limits, events, run_id, seed, started)
        try:
            validate_harness(harness, self.registry)
            if not isinstance(inputs, dict):
                raise ValueError("Execution inputs must be an object")
            output = state.run(deepcopy(harness), deepcopy(inputs))
            budget.check()
            state.event("execution_completed", output_fields=sorted(output))
            return {"output": output, "status": "success", "events": events, "usage": budget.snapshot(), "run_id": run_id}
        except Exception as error:
            state.event("execution_failed", error=f"{type(error).__name__}: {error}")
            return {"output": {}, "status": "failed", "events": events, "usage": budget.snapshot(), "run_id": run_id, "error": f"{type(error).__name__}: {error}"}


class _Execution:
    def __init__(self, registry, provider, budget, limits, events, run_id, seed, started):
        self.registry, self.budget, self.limits = registry, budget, limits
        self.provider = BudgetedProvider(provider, budget) if provider is not None else None
        self.events, self.run_id, self.seed, self.started = events, run_id, seed, started
        self.feedback_counts = {}
        self.feedback_total = 0
        self.feedback_lock = threading.Lock()
        self.ready_sequence = 0

    def event(self, outcome, **fields):
        record = {
            "run_id": self.run_id, "event_id": len(self.events),
            "event_outcome": outcome, "elapsed_seconds": time.monotonic() - self.started,
            "ready_queue_sequence": self.ready_sequence,
            "global_feedback_count": self.feedback_total,
            "global_feedback_limit": self.limits.get("feedback_global", 16),
            **fields,
        }
        self.events.append(record)
        return record

    def source(self, spec, seen=None):
        if "value" in spec:
            return deepcopy(spec["value"]), {"constant": True}
        if "external" in spec:
            field = spec["external"]
            if field not in self.inputs:
                raise MissingValue(f"Missing external input {field}")
            return deepcopy(self.inputs[field]), {"external": field, "version": 0}
        if "task" in spec:
            task_id, field = spec["task"], spec["field"]
            key = (task_id, field)
            seen = set(seen or ())
            if key in seen:
                raise ExecutionError("Cyclic task output alias")
            seen.add(key)
            alias = self.harness.get("task_outputs", {}).get(task_id, {}).get(field)
            if alias is not None:
                return self.source(alias, seen)
            candidates = [node_id for node_id, node in self.nodes.items() if task_id in node.get("tasks", []) and node_id in self.records and field in self.records[node_id]["output"]]
            if len(candidates) != 1:
                raise MissingValue(f"Task output {task_id}.{field} has no unique current producer")
            return self.source({"node": candidates[0], "field": field}, seen)
        node_id, field = spec["node"], spec["field"]
        if self.status[node_id] != "complete" or node_id not in self.records:
            raise MissingValue(f"Node {node_id} has no current completion")
        record = self.records[node_id]
        if field not in record["output"]:
            raise MissingValue(f"Node output {node_id}.{field} is absent")
        return deepcopy(record["output"][field]), {"node": node_id, "field": field, "version": record["version"], "activation_id": record["activation_id"], "generation": record["generation"]}

    def condition(self, condition):
        if condition is None:
            return True
        try:
            value, _ = self.source(condition["source"])
        except MissingValue:
            return False
        expected = condition.get("value")
        operator = condition["op"]
        if operator == "truthy":
            return bool(value)
        if operator == "falsy":
            return not bool(value)
        if operator in {"eq", "ne"}:
            # bool is not an integer in the declared interface type system.
            same_type = type(value) is type(expected) or (
                isinstance(value, (int, float)) and not isinstance(value, bool)
                and isinstance(expected, (int, float)) and not isinstance(expected, bool)
            )
            equals = same_type and value == expected
            return equals if operator == "eq" else not equals
        if isinstance(value, bool) or isinstance(expected, bool):
            return False
        if not ((isinstance(value, (int, float)) and isinstance(expected, (int, float))) or (isinstance(value, str) and isinstance(expected, str))):
            return False
        return {"lt": lambda: value < expected, "le": lambda: value <= expected,
                "gt": lambda: value > expected, "ge": lambda: value >= expected}[operator]()

    def ready(self):
        # Resolve inactive branches before checking the next join. Each edge is
        # resolved once in its current generation, including skipped branches.
        changed = True
        while changed:
            changed = False
            for node_id in self.order:
                if self.status[node_id] != "pending" or node_id in self.forced_entries:
                    continue
                incoming = self.incoming[node_id]
                if incoming and all(self.tokens[e["id"]] is False for e in incoming):
                    self.status[node_id] = "skipped"
                    self.event("node_skipped", node_id=node_id, generation=self.generation[node_id])
                    for edge in self.outgoing[node_id]:
                        if edge["type"] != "Fb":
                            self.tokens[edge["id"]] = False
                    changed = True
        result = []
        for node_id in self.order:
            if self.status[node_id] != "pending":
                continue
            incoming = self.incoming[node_id]
            if node_id in self.forced_entries or (incoming and all(self.tokens[e["id"]] is not None for e in incoming) and any(self.tokens[e["id"]] for e in incoming)):
                result.append(node_id)
        return sorted(result)

    def prepare(self, node_id):
        node = self.nodes[node_id]
        bindings = dict(node.get("bindings", {}))
        incoming_bindings = {}
        for edge in self.incoming[node_id]:
            if self.tokens[edge["id"]]:
                for name, source in edge.get("bindings", {}).items():
                    if name in incoming_bindings and incoming_bindings[name] != source:
                        raise ExecutionError(f"Conflicting active producers for {node_id}.{name}")
                    incoming_bindings[name] = source
        bindings.update(incoming_bindings)
        bindings.update(self.overrides.get(node_id, {}))
        arguments, versions = {}, {}
        component = _registry_component(self.registry, node["component"]) if node["kind"] == "Exec" else None
        fields = {f["name"]: f for f in component.get("inputs", [])} if component else {}
        for name, source in bindings.items():
            try:
                arguments[name], versions[name] = self.source(source)
            except MissingValue:
                if name in fields and not fields[name].get("required", True):
                    continue
                raise
        if component:
            validate_values(component.get("inputs", []), arguments)
        self.activation_counts[node_id] += 1
        activation = f"{node_id}:{self.activation_counts[node_id]}"
        activation_seed = int(hashlib.sha256(f"{self.seed}:{activation}".encode()).hexdigest()[:8], 16)
        predecessor_records = [self.token_records[edge["id"]] for edge in self.incoming[node_id] if self.tokens[edge["id"]] and edge["id"] in self.token_records]
        scopes = sorted({scope for record in predecessor_records for scope in record["fork_invocation_ids"]}
                        | set(self.forced_scopes.get(node_id, [])))
        self.ready_sequence += 1
        self.event("activation_started", node_id=node_id, activation_id=activation,
                   fork_invocation_id=scopes[-1] if scopes else None,
                   fork_invocation_ids=scopes,
                   predecessor_completions=deepcopy(predecessor_records),
                   input_versions=versions, generation=self.generation[node_id],
                   selected_component_id=node.get("component"),
                   component_selection_policy_id="fixed-validated-component-v1")
        return {"arguments": arguments, "versions": versions, "activation": activation,
                "seed": activation_seed, "generation": self.generation[node_id], "fork_invocation_ids": scopes}

    def invoke(self, node_id, prepared):
        node = self.nodes[node_id]
        self.budget.check()
        if node["kind"] == "Choice":
            return {}
        context = {
            "provider": self.provider, "budget": self.budget,
            "seed": prepared["seed"], "phase": "execution",
            "task_goal": node.get("config", {}).get("task_goal", node.get("config", {}).get("goal", node.get("goal", ""))),
            "domain_rules": deepcopy(self.harness.get("profiles", {}).get("domain", {}).get("rules", [])),
            "operation": node.get("operation"), "node_config": deepcopy(node.get("config", {})),
            "activation_id": prepared["activation"],
            "deadline_monotonic": self.started + self.limits.get("seconds", float("inf")),
        }
        # Service-level retries are performed by providers. Re-executing an
        # operation here could repeat a successful state-changing tool call.
        result = self.registry.invoke(node["component"], prepared["arguments"], context)
        component = _registry_component(self.registry, node["component"])
        validate_values(component.get("outputs", []), result)
        self.budget.check()
        return result

    def _dependencies(self, node_id):
        sources = []
        for source in self.nodes[node_id].get("bindings", {}).values():
            if "node" in source:
                sources.append(source["node"])
        for source in self.overrides.get(node_id, {}).values():
            if "node" in source:
                sources.append(source["node"])
        return sources

    def invalidate(self, target):
        affected = {target}
        changed = True
        while changed:
            changed = False
            for node_id in self.order:
                if node_id in affected:
                    continue
                if any(edge["source"] in affected for edge in self.incoming[node_id]) or any(source in affected for source in self._dependencies(node_id)):
                    affected.add(node_id)
                    changed = True
        for node_id in sorted(affected):
            old = self.records.pop(node_id, None)
            self.generation[node_id] += 1
            self.status[node_id] = "pending"
            self.forced_entries.discard(node_id)
            self.overrides.pop(node_id, None)
            self.forced_scopes.pop(node_id, None)
            if old:
                self.event("completion_invalidated", node_id=node_id, activation_id=old["activation_id"], generation=self.generation[node_id])
            for edge in self.outgoing[node_id]:
                if edge["type"] != "Fb":
                    self.tokens[edge["id"]] = None
                    self.token_records.pop(edge["id"], None)
        self.forced_entries.add(target)
        return affected

    def feedback(self, edge):
        edge_id = edge["id"]
        edge_limit = edge.get("max_traversals", self.limits.get("feedback_per_edge", 3))
        # A graph can lower a shared budget, never enlarge it.
        edge_limit = min(edge_limit, self.limits.get("feedback_per_edge", 3))
        global_limit = self.limits.get("feedback_global", 16)
        with self.feedback_lock:
            count = self.feedback_counts.get(edge_id, 0)
            if count >= edge_limit or self.feedback_total >= global_limit:
                self.event("feedback_exhausted", feedback_edge_id=edge_id,
                           edge_feedback_count=count, edge_feedback_limit=edge_limit,
                           transition_type="Fb")
                return False
            # Resolve transfer values before invalidating their producer. A
            # constant snapshot is now the input of the new activation.
            transferred = {name: {"value": self.source(source)[0]} for name, source in edge.get("bindings", {}).items()}
            scopes = list(self.records[edge["source"]].get("fork_invocation_ids", []))
            self.feedback_counts[edge_id] = count + 1
            self.feedback_total += 1
            affected = self.invalidate(edge["target"])
            self.overrides.setdefault(edge["target"], {}).update(transferred)
            # Retain outer invocations, replacing every fork inside the region
            # being rerun with the new fork activation created on dispatch.
            self.forced_scopes[edge["target"]] = [scope for scope in scopes if scope.rsplit(":", 2)[0] not in affected]
            self.event("feedback_traversed", feedback_edge_id=edge_id,
                       edge_feedback_count=count + 1, edge_feedback_limit=edge_limit,
                       transition_type="Fb", source=edge["source"], target=edge["target"],
                       invalidated_nodes=sorted(affected))
            return True

    def dispatch(self, node_id):
        edges = sorted(self.outgoing[node_id], key=lambda edge: (-edge.get("priority", 0), edge["id"]))
        for edge in edges:
            if edge["type"] == "Fb" and self.condition(edge.get("condition")):
                if self.feedback(edge):
                    return
        normal = [edge for edge in edges if edge["type"] != "Fb"]
        selected = None
        if normal and normal[0]["type"] == "Alt":
            eligible = []
            for edge in normal:
                if not self.condition(edge.get("condition")):
                    continue
                try:
                    # Required transferred fields must be present before this
                    # route is eligible; absence never becomes a null value.
                    for source in edge.get("bindings", {}).values():
                        self.source(source)
                    target = self.nodes[edge["target"]]
                    if target["kind"] == "Exec":
                        component = _registry_component(self.registry, target["component"])
                        bindings = {**target.get("bindings", {}), **edge.get("bindings", {})}
                        values = {}
                        for field in component.get("inputs", []):
                            name = field["name"]
                            if field.get("required", True):
                                if name not in bindings:
                                    raise MissingValue(f"Missing route binding {name}")
                                values[name] = self.source(bindings[name])[0]
                        validate_values([field for field in component.get("inputs", []) if field.get("required", True)], values)
                except MissingValue:
                    continue
                except ValueError:
                    continue
                eligible.append(edge)
            if not eligible:
                raise ExecutionError(f"Choice {node_id} has no eligible successor")
            selected = eligible[0]["id"]
            self.event("choice_selected", node_id=node_id, edge_id=selected,
                       eligible_edge_ids=[edge["id"] for edge in eligible], transition_type="Alt")
        for edge in normal:
            active = edge["id"] == selected if selected is not None else self.condition(edge.get("condition"))
            self.tokens[edge["id"]] = bool(active)
            if active:
                completion = self.records[node_id]
                scopes = set(completion.get("fork_invocation_ids", []))
                if edge["type"] == "Par" and len([out for out in normal if out["type"] == "Par"]) > 1:
                    scopes.add(f"{completion['activation_id']}:fork")
                self.token_records[edge["id"]] = {"node": node_id, "activation_id": completion["activation_id"],
                                                   "generation": completion["generation"],
                                                   "fork_invocation_ids": sorted(scopes), "edge_id": edge["id"]}
                transferred = self.overrides.setdefault(edge["target"], {})
                for name, source in edge.get("bindings", {}).items():
                    if name in transferred and transferred[name] != source:
                        raise ExecutionError(f"Conflicting active producers for {edge['target']}.{name}")
                    transferred[name] = source
            self.event("transition_activated" if active else "transition_inactive",
                       edge_id=edge["id"], source=node_id, target=edge["target"],
                       transition_type=edge["type"], generation=self.generation[node_id])

    def run(self, harness, inputs):
        self.harness, self.inputs = harness, inputs
        self.nodes = {n["id"]: n for n in harness["nodes"]}
        self.incoming = {node_id: [] for node_id in self.nodes}
        self.outgoing = {node_id: [] for node_id in self.nodes}
        self.tokens = {}
        self.token_records, self.forced_scopes = {}, {}
        for edge in harness.get("edges", []):
            self.outgoing[edge["source"]].append(edge)
            if edge["type"] != "Fb":
                self.incoming[edge["target"]].append(edge)
                self.tokens[edge["id"]] = None
        self.order = topological_order(self.nodes, [(e["source"], e["target"]) for e in harness.get("edges", []) if e["type"] != "Fb"])
        self.status = {node_id: "pending" for node_id in self.nodes}
        self.generation = {node_id: 0 for node_id in self.nodes}
        self.activation_counts = {node_id: 0 for node_id in self.nodes}
        self.records, self.overrides = {}, {}
        self.forced_entries = set(harness["entry"])
        self.event("execution_started", harness_id=harness.get("id"),
                   problem_id=harness.get("problem_id"), seed=self.seed,
                   start_utc=datetime.now(timezone.utc).isoformat())
        workers = self.limits.get("external_calls_in_flight", 4)
        with ThreadPoolExecutor(max_workers=workers, thread_name_prefix="openmas") as executor:
            while True:
                self.budget.check()
                frontier = self.ready()
                if not frontier:
                    break
                prepared = {node_id: self.prepare(node_id) for node_id in frontier}
                futures = {node_id: executor.submit(self.invoke, node_id, prepared[node_id]) for node_id in frontier}
                errors = []
                # All frontier results are committed before transitions so
                # routing sees a deterministic, complete global state.
                for node_id in frontier:
                    activation = prepared[node_id]
                    try:
                        output = futures[node_id].result()
                    except Exception as error:
                        self.event("activation_failed", node_id=node_id,
                                   activation_id=activation["activation"], error=f"{type(error).__name__}: {error}")
                        errors.append(error)
                        continue
                    self.status[node_id] = "complete"
                    self.forced_entries.discard(node_id)
                    self.records[node_id] = {"output": deepcopy(output), "version": self.activation_counts[node_id],
                                             "activation_id": activation["activation"],
                                             "generation": self.generation[node_id], "input_versions": activation["versions"],
                                             "fork_invocation_ids": activation["fork_invocation_ids"]}
                    self.event("activation_completed", node_id=node_id,
                               activation_id=activation["activation"], input_versions=activation["versions"],
                               generation=self.generation[node_id], output=deepcopy(output))
                if errors:
                    raise errors[0]
                for node_id in frontier:
                    # A feedback traversal committed by an earlier node may
                    # have invalidated this node's just-completed activation.
                    if self.status[node_id] == "complete":
                        self.dispatch(node_id)
        unresolved = [node_id for node_id in self.nodes if self.status[node_id] == "pending"]
        if unresolved:
            raise ExecutionError(f"No ready node; unresolved control dependencies: {', '.join(sorted(unresolved))}")
        graph = harness.get("task_graph", {})
        for task in graph.get("tasks", []):
            if not task.get("selected", True):
                continue
            task_id = task["id"]
            if not any(task_id in self.nodes[node_id].get("tasks", []) for node_id in self.records):
                raise ExecutionError(f"Selected task {task_id} did not complete on the active route")
            values = {}
            for field in task.get("outputs", []):
                try:
                    values[field["name"]] = self.source({"task": task_id, "field": field["name"]})[0]
                except MissingValue:
                    if field.get("required", True):
                        raise
            validate_values(task.get("outputs", []), values)
        return {name: self.source(source)[0] for name, source in harness["outputs"].items()}
