"""JSON contracts shared by construction and execution."""
from __future__ import annotations

import hashlib
import copy
import json
import math


def digest(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False, separators=(",", ":"), allow_nan=False).encode("utf-8")).hexdigest()


def parse_json(text):
    text = text.strip()
    if text.startswith("```"):
        lines = text.splitlines()
        if lines[-1].strip() != "```":
            raise ValueError("Unclosed JSON fence")
        text = "\n".join(lines[1:-1])
    def unique(pairs):
        result = {}
        for key, value in pairs:
            if key in result:
                raise ValueError(f"Duplicate JSON key {key}")
            result[key] = value
        return result
    return json.loads(text, object_pairs_hook=unique, parse_constant=lambda x: (_ for _ in ()).throw(ValueError(f"Invalid JSON number {x}")))


def value_matches(value, type_name):
    if type_name == "any":
        return True
    if type_name == "number":
        return isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value)
    if type_name == "integer":
        return isinstance(value, int) and not isinstance(value, bool)
    types = {"string": str, "boolean": bool, "object": dict, "array": list, "null": type(None)}
    if type_name not in types:
        raise ValueError(f"Unsupported field type {type_name}")
    return isinstance(value, types[type_name])


def validate_fields(fields):
    names = set()
    for field in fields:
        name = field.get("name")
        if not isinstance(name, str) or not name or name in names:
            raise ValueError("Field names must be unique nonempty strings")
        names.add(name)
        value_matches(None, field.get("type", "any"))
        if not isinstance(field.get("required", True), bool):
            raise ValueError(f"Invalid required flag for {name}")


def validate_values(fields, values):
    if not isinstance(values, dict):
        raise ValueError("Operation values must be an object")
    for field in fields:
        name = field["name"]
        if name not in values:
            if field.get("required", True):
                raise ValueError(f"Missing required field {name}")
        elif not value_matches(values[name], field.get("type", "any")):
            raise ValueError(f"Incorrect type for {name}, expected {field['type']}")


def assignable(source_type, target_type):
    return target_type == "any" or source_type == target_type or (source_type == "integer" and target_type == "number")


def topological_order(ids, edges):
    ids = list(ids)
    if len(ids) != len(set(ids)):
        raise ValueError("Duplicate graph identifiers")
    incoming = {identifier: set() for identifier in ids}
    outgoing = {identifier: set() for identifier in ids}
    for source, target in edges:
        if source not in incoming or target not in incoming or source == target:
            raise ValueError(f"Invalid graph edge {source} -> {target}")
        incoming[target].add(source)
        outgoing[source].add(target)
    ready = sorted(key for key, predecessors in incoming.items() if not predecessors)
    result = []
    while ready:
        identifier = ready.pop(0)
        result.append(identifier)
        for target in sorted(outgoing[identifier]):
            incoming[target].discard(identifier)
            if not incoming[target] and target not in result and target not in ready:
                ready.append(target)
        ready.sort()
    if len(result) != len(ids):
        raise ValueError("Task or forward-control graph contains a cycle")
    return result


def validate_source(source):
    if not isinstance(source, dict):
        raise ValueError("Binding source must be an object")
    kinds = [key for key in ("value", "external", "node", "task") if key in source]
    if len(kinds) != 1:
        raise ValueError("Binding must identify exactly one source")
    if kinds[0] in {"node", "task"} and not isinstance(source.get("field"), str):
        raise ValueError("Produced binding requires a field name")


def public_problem(problem):
    # Allowlist prevents arbitrary source metadata, tests, and reference labels leaking to construction.
    result = {key: copy.deepcopy(problem[key]) for key in ("id", "setting", "domain", "application_type", "input") if key in problem}
    if not isinstance(result.get("id"), str) or not isinstance(result.get("input"), dict):
        raise ValueError("Problem requires string id and object input")
    reserved = {"reference", "gold", "gold_answer", "answer", "solution", "target", "canonical_solution", "test", "test_list", "hidden_tests"}
    def inspect(value):
        if isinstance(value, dict):
            if reserved.intersection(value):
                raise ValueError("Evaluator-only field found in public problem input")
            for child in value.values():
                inspect(child)
        elif isinstance(value, list):
            for child in value:
                inspect(child)
    inspect(result["input"])
    digest(result)
    return result
