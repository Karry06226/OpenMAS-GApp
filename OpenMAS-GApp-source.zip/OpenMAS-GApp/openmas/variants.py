"""Executable local ablations with explicit implementation provenance.

These implementations instantiate changes described in the manuscript. They are
new source implementations, not recovered historical prompts or run artifacts.
In particular, the I/O variant removes semantic field matching while retaining
runtime type and required-input checks, and generated configurations use callable
registry operations rather than introducing unavailable component endpoints.
"""
from __future__ import annotations

import copy
import json
import re

from .construction import GraphHarnessBuilder
from .registry import field
from .validation import assignable, digest, topological_order, validate_source


class _VariantBuilder(GraphHarnessBuilder):
    implementation_id = "local-variant-v1"
    change = ""

    def build(self, problem, seed=11):
        try:
            harness = super().build(problem, seed=seed)
            harness.setdefault("metadata", {}).update(self._provenance())
            self.last_record["harness_digest"] = digest(harness)
            return harness
        finally:
            self.last_record.update(self._provenance())

    def _provenance(self):
        return {
            "implementation": self.implementation_id,
            "variant_change": self.change,
            "implementation_origin": "new_source_implementation_of_manuscript_variant",
            "historical_prompt_or_run_recovered": False,
        }


class NoTaskStructureBuilder(_VariantBuilder):
    """Replace extracted task structures with one whole-problem obligation."""

    implementation_id = "ablation-whole-problem-task-v1"
    change = "no_model_task_extraction_single_whole_problem_task"

    def _json(self, stage, data, instruction):
        if stage != "task_extraction":
            return super()._json(stage, data, instruction)
        problem = data["problem"]
        payload = json.dumps(problem["input"], ensure_ascii=False, sort_keys=True)
        goal = "Solve the complete individual problem using all supplied inputs and preserve its requested answer format."
        self.last_record["task_extraction_bypassed"] = True
        self.last_record["whole_problem_input_digest"] = digest(problem["input"])
        return {
            "requirements": [{"id": "whole_problem", "mandatory": True}],
            "tasks": [{
                "id": "solve", "goal": goal, "selected": True,
                "covers": ["whole_problem"],
                "capabilities": [{"text": "reason analyze solve the complete problem and return a final answer", "weight": 1.0}],
                "inputs": [field("question", description="All inputs for the individual problem, serialized as JSON.")],
                "outputs": [field("answer")],
                "bindings": {"question": {"value": payload}},
            }],
            "dependencies": [],
            "outputs": {"answer": {"task": "solve", "field": "answer"}},
        }


class SequentialBuilder(_VariantBuilder):
    """Keep tasks and selected operations, then impose one execution sequence."""

    implementation_id = "ablation-serialized-selected-operations-v1"
    change = "compiled_selected_operations_with_total_topological_execution_order"

    def __init__(self, registry, provider, config=None):
        config = copy.deepcopy(config or {})
        config["synthesis"] = "compiled"
        super().__init__(registry, provider, config)

    def _compile(self, problem, graph, selected):
        harness = super()._compile(problem, graph, selected)
        # Parent assembly emits topologically sorted tasks and contiguous path
        # operations. Keeping that order also preserves each complete route.
        order = [node["id"] for node in harness["nodes"]]
        positions = {identifier: index for index, identifier in enumerate(order)}
        if any(positions[e["source"]] >= positions[e["target"]] for e in harness["edges"]):
            raise ValueError("Compiled operation order does not preserve task dependencies")
        topological_order(order, [(e["source"], e["target"]) for e in harness["edges"]])
        self.last_record["preserved_dependency_edges"] = copy.deepcopy(harness["edges"])
        self.last_record["serialized_node_order"] = order
        harness["edges"] = [{"id": f"sequence.{index}", "source": source, "target": target, "type": "Seq"}
                            for index, (source, target) in enumerate(zip(order, order[1:]))]
        harness["entry"] = order[:1]
        return harness


class SemanticIOAblationBuilder(_VariantBuilder):
    """Remove construction semantic I/O judgments, keeping type contracts."""

    implementation_id = "ablation-semantic-io-only-v1"
    change = "all_type_assignable_field_pairs_accepted_without_semantic_judgment"

    def _judge(self, relations):
        capabilities = [relation for relation in relations if relation["kind"] != "field"]
        judgments = super()._judge(capabilities) if capabilities else {}
        for relation in relations:
            if relation["kind"] == "field":
                judgments[relation["id"]] = {
                    "id": relation["id"], "accept": True, "score": 1.0,
                    "decision_source": "semantic_io_constraint_removed",
                }
        self.last_record["semantic_field_judgments_bypassed"] = self.last_record.get("semantic_field_judgments_bypassed", 0) + sum(r["kind"] == "field" for r in relations)
        self.last_record["runtime_type_contracts_preserved"] = True
        return judgments


class GeneratedConfigurationBuilder(_VariantBuilder):
    """Replace embedding search and utility selection with proposed configs.

    A model proposes a finite ordered family. Exactly the configured number of
    hard-valid paths is retained in proposal order. Capability/compatibility
    scores are stored as null because this variant does not estimate them.
    """

    implementation_id = "ablation-generated-registered-configurations-v1"
    change = "model_proposes_registered_operation_configs_without_embedding_or_utility_selection"

    def _select(self, task, problem):
        eligible = [component for component in self.registry.components.values()
                    if not component.get("domains") or problem.get("domain") in component["domains"]]
        count = self.selection["retained_path_count"]
        response = self._json(
            "component_configuration",
            {"task": task, "registry": eligible, "required_distinct_paths": count,
             "max_components_per_path": self.selection["path_max_components"],
             "max_paths": self.selection["max_complete_candidates"]},
            "Propose ordered executable configurations directly from the registered operations. "
            "Do not rank by embeddings or calculate utilities. Return {paths:[{components:[component_id],"
            "bindings:[{input_name:{external:task_input_name}|{node:p0,field:output_name}}],"
            "output_bindings:{task_output_name:{node:p0,field:output_name}}}]}. "
            "Only callable registered component IDs are allowed. A path node p0 is its first component, p1 its second. "
            "A binding may use only a declared task input or an earlier path node output. Each path must consume "
            "all required task inputs, provide all required task outputs, and connect every consecutive operation "
            "through a passed field. Keep types and field meanings compatible. Supply distinct paths in preferred order.",
        )
        proposed = response.get("paths") if isinstance(response, dict) else None
        if not isinstance(proposed, list) or not count <= len(proposed) <= self.selection["max_complete_candidates"]:
            raise ValueError("Generated path family has an invalid cardinality")
        paths = [self._validated_proposal(task, problem, path, index) for index, path in enumerate(proposed)]
        identities = [tuple(path["components"]) for path in paths]
        if len(set(identities)) != len(identities):
            raise ValueError("Generated configuration paths must be distinct")
        selected = paths[:count]
        self.last_record["path_families"][task["id"]] = {
            "generated_path_ids": [p["id"] for p in paths],
            "hard_feasible_path_ids": [p["id"] for p in paths],
            "selected_path_ids": [p["id"] for p in selected],
            "fixed_selected_count": count, "paths": paths,
            "selection_strategy": "model_proposal_order_after_hard_contract_checks",
            "capability_and_interface_scores_available": False,
            "cost_min": None, "cost_max": None,
        }
        return selected

    def _validated_proposal(self, task, problem, proposal, index):
        if not isinstance(proposal, dict):
            raise ValueError("Generated path must be an object")
        component_ids = proposal.get("components")
        bindings = proposal.get("bindings")
        outputs = proposal.get("output_bindings")
        if not isinstance(component_ids, list) or not 1 <= len(component_ids) <= self.selection["path_max_components"]:
            raise ValueError("Generated path length is outside its bound")
        if any(not isinstance(identifier, str) for identifier in component_ids) or len(set(component_ids)) != len(component_ids):
            raise ValueError("Generated paths require distinct registered component identifiers")
        if not isinstance(bindings, list) or len(bindings) != len(component_ids) or not all(isinstance(b, dict) for b in bindings):
            raise ValueError("Generated path bindings do not match its operations")
        if not isinstance(outputs, dict):
            raise ValueError("Generated path requires task output bindings")
        components = [self.registry.get(identifier) for identifier in component_ids]
        if any(component.get("domains") and problem.get("domain") not in component["domains"] for component in components):
            raise ValueError("Generated component is outside the problem domain")
        task_inputs = {spec["name"]: spec for spec in task.get("inputs", [])}
        consumed = set()

        def produced_spec(source, before):
            validate_source(source)
            if "external" in source:
                name = source["external"]
                if name not in task_inputs or name not in task.get("bindings", {}):
                    raise ValueError("Generated configuration uses an undeclared task input")
                consumed.add(name)
                return task_inputs[name], None
            if "node" not in source or not isinstance(source["node"], str) or not re.fullmatch(r"p\d+", source["node"]):
                raise ValueError("Generated path requires task-input or path-node bindings")
            producer = int(source["node"][1:])
            if not 0 <= producer < before:
                raise ValueError("Generated path binding has no earlier producer")
            fields = {spec["name"]: spec for spec in components[producer].get("outputs", [])}
            if source["field"] not in fields:
                raise ValueError("Generated path binding uses an undeclared output field")
            return fields[source["field"]], producer

        for position, (component, values) in enumerate(zip(components, bindings)):
            specs = {spec["name"]: spec for spec in component.get("inputs", [])}
            if not set(values) <= set(specs):
                raise ValueError("Generated configuration introduces an undeclared component input")
            used_producers = set()
            for name, spec in specs.items():
                if name not in values:
                    if spec.get("required", True):
                        raise ValueError("Generated configuration lacks a mandatory component input")
                    continue
                source_spec, producer = produced_spec(values[name], position)
                if not assignable(source_spec.get("type", "any"), spec.get("type", "any")):
                    raise ValueError("Generated component input type is incompatible")
                used_producers.add(producer)
            if position and position - 1 not in used_producers:
                raise ValueError("Generated path has a disconnected consecutive operation")
        if any(spec.get("required", True) and name not in consumed for name, spec in task_inputs.items()):
            raise ValueError("Generated configuration dropped a mandatory task input")
        task_outputs = {spec["name"]: spec for spec in task["outputs"]}
        if not set(outputs) <= set(task_outputs):
            raise ValueError("Generated configuration introduces an undeclared task output")
        for name, spec in task_outputs.items():
            if name not in outputs:
                if spec.get("required", True):
                    raise ValueError("Generated configuration dropped a mandatory task output")
                continue
            if "node" not in outputs[name]:
                raise ValueError("Generated task output must come from an operation")
            source_spec, _ = produced_spec(outputs[name], len(components))
            if not assignable(source_spec.get("type", "any"), spec.get("type", "any")):
                raise ValueError("Generated task output type is incompatible")
        transfer_cost = self.selection.get("planning_cost", {}).get("per_KiB_transfer", .01)
        cost = sum(component.get("cost", 1) for component in components) + transfer_cost * sum(len(json.dumps(b).encode()) / 1024 for b in bindings[1:])
        return {
            "id": f"{task['id']}:generated:{index}", "components": copy.deepcopy(component_ids),
            "bindings": copy.deepcopy(bindings), "output_bindings": copy.deepcopy(outputs),
            "coverage": None, "compatibility": None, "edge_scores": [], "utility": None,
            "cost": cost, "score_status": "not_computed_in_generated_configuration_variant",
        }


VARIANT_BUILDERS = {
    "ablation_no_task_structure": NoTaskStructureBuilder,
    "ablation_sequential": SequentialBuilder,
    "representation_sequence": SequentialBuilder,
    "ablation_no_semantic_io": SemanticIOAblationBuilder,
    "ablation_generated_components": GeneratedConfigurationBuilder,
}
