"""Build a standalone source archive with no datasets, keys, or run outputs."""
from pathlib import Path
import argparse
import hashlib
import json
from zipfile import ZipFile, ZIP_DEFLATED


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--output", default="dist/OpenMAS-GApp-source.zip")
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    output = (root / args.output).resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    files = [root / name for name in ("README.md", "pyproject.toml", ".gitignore", "IMPLEMENTATION_CONTRACT.md")]
    for name in ("openmas", "configs", "examples", "tests", "docs", "scripts"):
        files.extend(path for path in (root / name).rglob("*")
                     if path.is_file() and "__pycache__" not in path.parts
                     and path.suffix not in {".pyc", ".pyo"}
                     and ".local." not in path.name and not path.name.startswith(".env"))
    with ZipFile(output, "w", ZIP_DEFLATED) as archive:
        for path in sorted(set(files)):
            archive.write(path, "OpenMAS-GApp/" + path.relative_to(root).as_posix())
    print(json.dumps({"path": str(output), "files": len(set(files)), "sha256": hashlib.sha256(output.read_bytes()).hexdigest()}, indent=2))


if __name__ == "__main__":
    main()
