"""Install one wheel into a fresh temporary directory and run outside the repo."""
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def main():
    wheel = Path(sys.argv[1]).resolve(strict=True)
    with tempfile.TemporaryDirectory(prefix="openmas-install-check-") as directory:
        root = Path(directory)
        target = root / "installed"
        subprocess.run([sys.executable, "-m", "pip", "install", "--no-deps", "--target", str(target), str(wheel)], check=True)
        environment = dict(os.environ, PYTHONPATH=str(target))
        check = (
            "from openmas.experiments import load_config; "
            "from openmas.registry import default_registry; "
            "from openmas.protocol import load_source_versions; "
            "assert load_config()['models']['candidate_backbone']; "
            "assert len(default_registry({'size':7}).components)==7; "
            "assert load_source_versions(); print('Installed configuration and registry verified')"
        )
        subprocess.run([sys.executable, "-c", check], cwd=root, env=environment, check=True)
        subprocess.run([sys.executable, "-m", "openmas", "demo", "--output-dir", str(root / "demo")],
                       cwd=root, env=environment, check=True)
        result = json.loads((root / "demo" / "report.json").read_text(encoding="utf-8"))
        assert result["root_count"] == 10 and result["is_fixture"] is True
        print("Installed wheel passed outside-repository smoke test")


if __name__ == "__main__":
    main()
