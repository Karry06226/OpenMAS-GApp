import copy
import json
import unittest

from openmas.budgets import Budget, BudgetExceeded
from openmas.construction import GraphHarnessBuilder, validate_task_graph
from openmas.providers import BudgetedProvider
from openmas.registry import Registry, calculate_expression, default_registry, field
from openmas.validation import public_problem
from openmas.runtime import HarnessRuntime


def task_graph():
    return {"requirements": [{"id": "r", "mandatory": True}], "tasks": [{"id": "solve", "goal": "solve problem", "covers": ["r"], "capabilities": [{"text": "solve problem", "weight": 1}], "inputs": [field("question")], "outputs": [field("answer")], "bindings": {"question": {"external": "question"}}}], "dependencies": [], "outputs": {"answer": {"task": "solve", "field": "answer"}}}


class StructuredTestProvider:
    is_fixture = True

    def __init__(self, graph=None, reject=None):
        self.graph = graph or task_graph()
        self.reject = reject
        self.seen = []

    def embed(self, texts):
        return [[1.0, 0.0] for _ in texts]

    def complete(self, messages, **kwargs):
        self.seen.append(copy.deepcopy(messages))
        data = json.loads(messages[1]["content"])
        if "task_extraction" in messages[0]["content"]:
            result = self.graph
        elif "relations" in data:
            result = {"judgments": [{"id": r["id"], "accept": r.get("component") != self.reject if r["kind"] == "capability" else r["source"]["name"] == r["target"]["name"], "score": 1.0} for r in data["relations"]]}
        else:
            raise AssertionError("Unexpected test model operation")
        return {"text": json.dumps(result), "usage": {"prompt_tokens": 1, "completion_tokens": 1}, "model": "test-structured"}


def registry():
    return Registry([{"id": name, "kind": "agent", "operation": "solve", "capability": name, "inputs": [field("question")], "outputs": [field("answer")], "cost": cost} for name, cost in (("cheap", 1), ("expensive", 10), ("middle", 5))])


class ConstructionTests(unittest.TestCase):
    def setUp(self):
        self.problem = {"id": "sample", "setting": "test", "domain": "general", "application_type": "reasoning", "input": {"question": "What is two plus two?"}, "reference": "SECRET_LABEL", "metadata": {"hidden_tests": "SECRET_TESTS"}}

    def test_build_per_problem_and_no_reference_leakage(self):
        provider = StructuredTestProvider()
        builder = GraphHarnessBuilder(registry(), provider, {"synthesis": "compiled"})
        harness = builder.build(self.problem)
        family = builder.last_record["path_families"]["solve"]
        self.assertEqual(len(family["selected_path_ids"]), 2)
        self.assertEqual(family["cost_min"], 1)
        self.assertEqual(family["cost_max"], 10)
        self.assertEqual(harness["nodes"][0]["component"], "cheap")
        self.assertNotIn("SECRET", json.dumps(provider.seen))
        self.assertNotIn("SECRET", json.dumps(harness))
        self.assertEqual(harness["nodes"][0]["bindings"]["question"], {"external": "question"})

    def test_cost_extrema_frozen_before_thresholds(self):
        builder = GraphHarnessBuilder(registry(), StructuredTestProvider(reject="expensive"), {"synthesis": "compiled"})
        builder.build(self.problem)
        family = builder.last_record["path_families"]["solve"]
        self.assertEqual(family["cost_max"], 10)
        self.assertNotIn("solve:expensive", family["admissible_path_ids"])
        middle = next(p for p in family["paths"] if p["components"] == ["middle"])
        self.assertAlmostEqual(middle["normalized_cost"], 4/9)

    def test_insufficient_paths_fails(self):
        one = Registry([registry().get("cheap")])
        builder = GraphHarnessBuilder(one, StructuredTestProvider(), {"synthesis": "compiled"})
        with self.assertRaisesRegex(ValueError, "Fewer than 2"):
            builder.build(self.problem)
        self.assertEqual(builder.last_record["status"], "failed")

    def test_missing_coverage_rejected(self):
        graph = task_graph()
        graph["tasks"][0]["covers"] = []
        with self.assertRaisesRegex(ValueError, "mandatory requirement"):
            validate_task_graph(graph, public_problem(self.problem))

    def test_data_binding_adds_waiting_relation(self):
        graph = task_graph()
        followup = copy.deepcopy(graph["tasks"][0])
        followup["id"] = "review"
        followup["bindings"]["question"] = {"task": "solve", "field": "answer"}
        graph["tasks"].append(followup)
        result = validate_task_graph(graph, public_problem(self.problem))
        self.assertEqual(result["dependencies"], [{"source": "solve", "target": "review", "kinds": ["data"]}])
        graph["tasks"][0]["bindings"]["question"] = {"task": "review", "field": "answer"}
        with self.assertRaisesRegex(ValueError, "cycle"):
            validate_task_graph(graph, public_problem(self.problem))

    def test_registry_detail_changes_descriptions_only(self):
        a = default_registry({"size": 7, "description_detail": "brief"})
        b = default_registry({"size": 7, "description_detail": "detailed"})
        for components in (a.components, b.components):
            for component in components.values():
                for category in ("inputs", "outputs"):
                    for spec in component[category]:
                        spec.pop("description")
        self.assertEqual(a.components, b.components)

    def test_full_model_synthesis_and_runtime_pipeline(self):
        class SynthProvider(StructuredTestProvider):
            def complete(inner, messages, **kwargs):
                if "harness_synthesis" not in messages[0]["content"]:
                    return super(SynthProvider, inner).complete(messages, **kwargs)
                value = {"id": "fixture-model-harness", "problem_id": "sample", "nodes": [{"id": "n", "kind": "Exec", "component": "cheap", "associations": ["cheap"], "operation": "solve", "tasks": ["solve"], "bindings": {"question": {"external": "question"}}}], "edges": [], "entry": ["n"], "outputs": {"answer": {"node": "n", "field": "answer"}}, "task_outputs": {"solve": {"answer": {"node": "n", "field": "answer"}}}}
                return {"text": json.dumps(value), "usage": {"prompt_tokens": 2, "completion_tokens": 2}, "model": "test-structured"}
        reg = registry()
        reg.handlers["cheap"] = lambda values, context: {"answer": str(calculate_expression("2+2"))}
        builder = GraphHarnessBuilder(reg, SynthProvider())
        harness = builder.build(self.problem)
        result = HarnessRuntime(reg).execute(harness, self.problem["input"])
        self.assertEqual(result["status"], "success")
        self.assertEqual(result["output"]["answer"], "4")
        self.assertGreater(builder.last_record["usage"]["model_calls"], 0)

    def test_synthesis_cannot_change_validated_bindings_or_output(self):
        builder = GraphHarnessBuilder(registry(), StructuredTestProvider(), {"synthesis": "compiled"})
        harness = builder.build(self.problem)
        selected = harness["profiles"]["component"]
        changed = copy.deepcopy(harness)
        changed["nodes"][0]["bindings"]["question"] = {"value": "different question"}
        with self.assertRaisesRegex(ValueError, "unvalidated|mandatory"):
            builder._validate_assembly(changed, harness["task_graph"], selected)
        changed = copy.deepcopy(harness)
        changed["outputs"]["answer"] = {"value": "pretend output"}
        with self.assertRaisesRegex(ValueError, "final output"):
            builder._validate_assembly(changed, harness["task_graph"], selected)

    def test_nested_label_input_is_rejected(self):
        self.problem["input"]["nested"] = {"hidden_tests": ["private"]}
        with self.assertRaisesRegex(ValueError, "Evaluator-only"):
            public_problem(self.problem)


class BudgetToolTests(unittest.TestCase):
    def test_call_reservation_and_incurred_tokens(self):
        budget = Budget({"model_calls": 1, "model_tokens": 3})
        budget.consume(model_calls=1)
        with self.assertRaises(BudgetExceeded):
            budget.consume(model_calls=1)
        self.assertEqual(budget.snapshot()["model_calls"], 1)
        with self.assertRaises(BudgetExceeded):
            budget.consume(model_tokens=4)
        self.assertEqual(budget.snapshot()["model_tokens"], 4)

    def test_late_returned_tokens_are_still_recorded(self):
        budget = Budget({"seconds": 1})
        budget.started -= 2
        with self.assertRaises(BudgetExceeded):
            budget.consume(model_tokens=7)
        self.assertEqual(budget.snapshot()["model_tokens"], 7)
        with self.assertRaises(BudgetExceeded):
            budget.consume(model_calls=1)
        self.assertEqual(budget.snapshot()["model_calls"], 0)

    def test_arithmetic_rejects_code(self):
        self.assertEqual(calculate_expression("2 * (3 + 4)"), 14)
        for code in ("__import__('os').getcwd()", "True+1", "2**10000", "[1][0]"):
            with self.assertRaises(ValueError):
                calculate_expression(code)

    def test_boolean_not_accepted_as_integer(self):
        reg = Registry([{"id": "tool", "kind": "tool", "operation": "x", "inputs": [field("x", "integer")], "outputs": []}])
        with self.assertRaises(ValueError):
            reg.validate_inputs("tool", {"x": True})


if __name__ == "__main__":
    unittest.main()
