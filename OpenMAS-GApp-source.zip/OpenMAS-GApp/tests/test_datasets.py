from copy import deepcopy
import json
from pathlib import Path
import tempfile
import unittest

from openmas.datasets import (build_bbh_candidate_pool, freeze_manifest, load_problems,
                              public_problem, select_cohort, validate_manifest)
from openmas.protocol import scoring_for, seeds_for, suite_catalogue


class DatasetTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.root = Path(self.tmp.name)

    def tearDown(self):
        self.tmp.cleanup()

    def write(self, name, value):
        path = self.root / name
        path.write_text(json.dumps(value), encoding="utf-8")
        return path

    def test_counts_and_active_ablation_scope(self):
        catalogue = suite_catalogue()
        self.assertEqual(len(catalogue), 20)
        self.assertEqual(len({entry["dataset"] for entry in catalogue}), 19)
        self.assertEqual(seeds_for("BBH-Mixed", "Q3"), [11, 22, 33])
        self.assertEqual(len(seeds_for("BBH-Mixed", "Q2")), 5)
        self.assertEqual(len(seeds_for("BBH-Mixed", "Q6")), 5)
        self.assertEqual(scoring_for("BBH-Mixed", "Q2")["scorer"], "group_macro_match")
        self.assertEqual(scoring_for("BBH-Mixed", "Q3")["scorer"], "bbh_exact_match")
        self.assertEqual(seeds_for("BBH-Boolean", "ablation"), [11, 22, 33])
        self.assertEqual(scoring_for("BBH-Mixed")["scorer"], "group_macro_match")

    def test_gsm_label_solution_isolation_and_manifest(self):
        path = self.write("gsm.json", [{"question": "2+3?", "answer": "2+3=5 #### 5"}])
        cohort = load_problems(path, "GSM8K")
        public = public_problem(cohort[0])
        self.assertEqual(public["input"], {"question": "2+3?"})
        self.assertNotIn("reference", public)
        self.assertNotIn("metadata", public)
        manifest = freeze_manifest(cohort, split="test", scorer_id="numeric_answer_accuracy")
        validate_manifest(manifest, cohort)
        tampered = deepcopy(cohort)
        tampered[0]["reference"] = "6"
        with self.assertRaisesRegex(ValueError, "does not match"):
            validate_manifest(manifest, tampered)
        changed = deepcopy(manifest)
        changed["split"] = "dev"
        with self.assertRaisesRegex(ValueError, "digest"):
            validate_manifest(changed, cohort)

    def test_sciq_choice_position_is_not_always_gold_first(self):
        records = [{"id": str(i), "question": "q", "correct_answer": "yes", "distractor1": "no", "distractor2": "maybe", "distractor3": "never"} for i in range(20)]
        cohort = load_problems(self.write("sciq.json", records), "SciQ")
        self.assertGreater(len({record["reference"] for record in cohort}), 1)
        for record in cohort:
            self.assertEqual(record["input"]["choices"][record["reference"]], "yes")

    def test_scibench_duplicate_original_ids_preserved(self):
        rows = [{"problemid": "same", "problem_text": "q", "answer_number": "1", "solution": "private"} for _ in range(2)]
        cohort = load_problems(self.write("atkins.json", rows), "SciBench")
        self.assertEqual(len({p["id"] for p in cohort}), 2)
        self.assertEqual(cohort[0]["metadata"]["original_id"], "same")
        self.assertNotIn("solution", cohort[0]["input"])

    def test_bbh_mixed_requires_order_and_pool_is_not_evaluation(self):
        with self.assertRaisesRegex(ValueError, "explicitly supplied"):
            build_bbh_candidate_pool(self.root, "BBH-Mixed")
        self.write("boolean_expressions.json", {"examples": [{"input": f"Q{i}", "target": "True"} for i in range(110)]})
        pool = build_bbh_candidate_pool(self.root, "BBH-Boolean")
        self.assertEqual(len(pool), 100)
        self.assertEqual(pool[0]["metadata"]["cohort_role"], "candidate_pool")
        chosen = select_cohort(pool, [record["id"] for record in pool[:10]])
        self.assertEqual(len(chosen), 10)
        self.assertEqual(chosen[0]["metadata"]["cohort_role"], "evaluation")
        self.assertEqual(pool[0]["metadata"]["cohort_role"], "candidate_pool")

    def test_code_tests_and_references_stay_private(self):
        path = self.write("he.json", [{"task_id": "HumanEval/0", "prompt": "def f():", "entry_point": "f", "test": "assert f()==42", "canonical_solution": "return 42"}])
        problem = load_problems(path, "HumanEval")[0]
        public = public_problem(problem)
        self.assertNotIn("test", public["input"])
        self.assertNotIn("canonical_solution", public["input"])
        self.assertEqual(problem["reference"]["test"], "assert f()==42")

    def test_drop_nested_passages(self):
        path = self.write("drop.json", {"passage-a": {"passage": "Text", "qa_pairs": [{"query_id": "q1", "question": "What?", "answer": {"number": "2", "spans": [], "date": {}}}]}})
        cohort = load_problems(path, "DROP")
        self.assertEqual(cohort[0]["id"], "q1")
        self.assertEqual(cohort[0]["input"]["context"], "Text")
        self.assertEqual(cohort[0]["reference"]["answers"], ["2"])

    def test_source_adapters_all_settings(self):
        samples = {
            "MMLU": {"question": "q", "choices": ["x", "y"], "answer": 0},
            "MMLU-Pro": {"question": "q", "options": ["x", "y"], "answer_index": 0},
            "ARC": {"id": "arc", "question": "q", "choices": {"label": ["A", "B"], "text": ["x", "y"]}, "answerKey": "A"},
            "MedQA": {"question": "q", "options": {"A": "x", "B": "y"}, "answer_idx": "A"},
            "SciQ": {"question": "q", "correct_answer": "x", "distractor1": "y", "distractor2": "z", "distractor3": "w"},
            "StrategyQA": {"question": "q", "answer": True, "facts": ["private annotated reason"]},
            "PubMedQA": {"QUESTION": "q", "CONTEXTS": ["public abstract"], "final_decision": "yes", "LONG_ANSWER": "private reason"},
            "GSM8K": {"question": "q", "answer": "work #### 5"},
            "MATH-500": {"problem": "q", "answer": "5", "solution": "private reason"},
            "HotpotQA": {"question": "q", "context": [["Title", ["Sentence"]]], "answer": "x", "supporting_facts": [["Title", 0]]},
            "MuSiQue": {"question": "q", "paragraphs": [{"idx": 0, "title": "Title", "paragraph_text": "Text", "is_supporting": True}], "answer": "x"},
            "DROP": {"question": "q", "passage": "Text", "answer": {"number": "1"}},
            "HumanEval": {"task_id": "HumanEval/0", "prompt": "def f():", "test": "private test", "canonical_solution": "private solution", "entry_point": "f"},
            "MBPP": {"task_id": 11, "text": "q", "code": "private solution", "test_list": ["private test"], "example_tests": ["public example"]},
            "FinQA": {"id": "fin", "qa": {"question": "q", "answer": "5", "program": "private program"}, "table": [["x", 5]]},
            "FinanceBench": {"question": "q", "answer": "x", "evidence": [{"evidence_text": "private grading excerpt"}], "doc_name": "report"},
            "SciBench": {"problem_text": "q", "answer_number": "5", "unit": "10^{-3} J", "solution": "private reason"},
            "CaseHOLD": {"example_id": "original", "citing_prompt": "q", "endings": ["x", "y", "z", "w", "v"], "label": 0},
            "BBH-Boolean": {"input": "q", "target": "True", "task_name": "boolean_expressions"},
            "BBH-Mixed": {"input": "q", "target": "A", "task_name": "logical_deduction_three_objects"},
        }
        self.assertEqual(set(samples), {entry["setting"] for entry in suite_catalogue()})
        for setting, sample in samples.items():
            with self.subTest(setting=setting):
                record = load_problems(self.write(f"{setting}.json", [sample]), setting)[0]
                serialized_public = json.dumps(public_problem(record))
                self.assertNotIn("private", serialized_public)
                self.assertEqual(record["setting"], setting)
                if setting == "CaseHOLD":
                    self.assertEqual(record["id"], "original")

    def test_normalized_duplicate_ids_and_public_fields_rejected(self):
        record = dict(id="a", input={"question": "q"}, reference="r")
        with self.assertRaisesRegex(ValueError, "Duplicate"):
            load_problems(self.write("bad.json", [record, record]), "GSM8K")
        record["input"]["canonical_solution"] = "private"
        with self.assertRaisesRegex(ValueError, "Evaluator-only"):
            load_problems(self.write("leak.json", [record]), "GSM8K")
        record["input"] = {"question": "q", "documents": [{"text": "public", "hidden_tests": "private"}]}
        with self.assertRaisesRegex(ValueError, "Evaluator-only"):
            load_problems(self.write("nested_leak.json", [record]), "GSM8K")


if __name__ == "__main__":
    unittest.main()
