import copy
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

from openmas.experiments import (ExternalBuilder, freeze_cohorts, validate_cohorts,
                                run_experiment, run_suite, load_config)
from openmas.registry import default_registry


PROBLEM = {"id": "p1", "setting": "GSM8K", "domain": "general",
           "application_type": "mathematical_reasoning", "input": {"question": "What is 2 + 3?"},
           "reference": 5, "metadata": {"hidden_tests": "DO NOT SEND"}}


class ExperimentTests(unittest.TestCase):
    def test_suite_manifest_is_content_sensitive(self):
        other = copy.deepcopy(PROBLEM)
        other.update(id="p2", setting="StrategyQA", reference="yes")
        cohort = [PROBLEM, other]
        manifest = freeze_cohorts(cohort)
        validate_cohorts(manifest, cohort)
        changed = copy.deepcopy(cohort)
        changed[1]["reference"] = "no"
        with self.assertRaises(ValueError):
            validate_cohorts(manifest, changed)

    def test_outer_runs_construct_independently_and_keep_failure_slots(self):
        config = load_config()
        config["provider"] = {"kind": "fixture", "responses": []}
        with tempfile.TemporaryDirectory() as directory:
            report = run_experiment([PROBLEM], config, directory, methods=["direct"], seeds=[11, 22])
            self.assertEqual(report["root_count"], 2)
            self.assertEqual(report["failure_count"], 2)
            self.assertEqual(report["settings"]["GSM8K"]["direct"]["mean"], 0)
            summaries = json.loads((Path(directory) / "repeat_summaries.json").read_text())
            for summary in summaries:
                predictions = json.loads((Path(directory) / summary["prediction_file"]).read_text())
                self.assertEqual(set(predictions), {"p1"})
                self.assertEqual(predictions["p1"]["status"], "failed")

    def test_direct_fixture_does_not_read_reference(self):
        config = load_config()
        config["provider"] = {"kind": "fixture", "responses": [{"answer": "5"}]}
        changed = copy.deepcopy(PROBLEM)
        changed["reference"] = 999
        with tempfile.TemporaryDirectory() as directory:
            result = run_experiment([changed], config, directory, methods=["direct"], seeds=[11])
            self.assertEqual(result["failure_count"], 0)
            self.assertEqual(result["settings"]["GSM8K"]["direct"]["mean"], 0)
            self.assertIsNone(result["settings"]["GSM8K"]["direct"]["sample_sd"])
            harnesses = list((Path(directory) / "runs").glob("*/harness.json"))
            self.assertNotIn("DO NOT SEND", harnesses[0].read_text())
            with self.assertRaises(ValueError):
                run_experiment([changed], config, directory, methods=["direct"])

    def test_external_builder_reference_isolation(self):
        worker = "import json,sys; q=json.load(sys.stdin); assert 'reference' not in q['problem']; assert 'metadata' not in q['problem']; print(json.dumps({'harness':{'id':'h','nodes':[]}}))"
        builder = ExternalBuilder(default_registry(), {"command": [sys.executable, "-c", worker],
                                                       "implementation_id": "test-only"})
        self.assertEqual(builder.build(PROBLEM)["id"], "h")
        self.assertIsNone(builder.last_record["usage"])

    def test_conditions_share_cohort_seeds_and_preserve_independent_runs(self):
        config = load_config()
        config["provider"] = {"kind": "fixture", "responses": [{"answer": "5"}]}
        specification = {"comparison_id": "Q7", "seeds": [11, 22], "methods": ["direct"],
                         "conditions": [{"id": "clean"}, {"id": "metadata", "overrides": {
                             "intervention": {"family": "P2", "intensity": "low"}}}]}
        with tempfile.TemporaryDirectory() as directory:
            report = run_suite([PROBLEM], specification, directory, base_config=config)
            self.assertEqual(report["deltas"]["metadata"]["GSM8K"]["direct"]["paired_run_deltas"], [0, 0])
            records = list(Path(directory).glob("condition-*/runs/*/record.json"))
            self.assertEqual(len(records), 4)
            run_ids = {json.loads(p.read_text())["run_id"] for p in records}
            self.assertEqual(len(run_ids), 4)
            self.assertEqual(len(list(Path(directory).glob("condition-*/runs/*/intervention.json"))), 2)

    def test_paired_conditions_reject_changed_scoring_contract(self):
        specification = {"conditions": [{"id": "clean"}, {"id": "changed", "overrides": {
            "scorers": {"GSM8K": {"scorer": "answer_f1"}}}}]}
        with tempfile.TemporaryDirectory() as directory:
            with self.assertRaisesRegex(ValueError, "same scoring contracts"):
                run_suite([PROBLEM], specification, directory)
            self.assertEqual(list(Path(directory).iterdir()), [])


if __name__ == "__main__":
    unittest.main()
