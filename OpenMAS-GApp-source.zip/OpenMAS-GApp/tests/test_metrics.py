import math
import unittest

from openmas.metrics import (aggregate_settings, answer_f1, numeric_value,
                             scibench_numeric_match, score_predictions, summarize_runs)


def problem(identifier, reference, **metadata):
    return dict(id=identifier, reference=reference, metadata=metadata)


class MetricTests(unittest.TestCase):
    def test_complete_cohort_and_abstention(self):
        cohort = [problem("a", "A"), problem("b", "B")]
        with self.assertRaisesRegex(ValueError, "Incomplete"):
            score_predictions(cohort, {"a": "A"}, scorer="accuracy")
        with self.assertRaisesRegex(ValueError, "Incomplete"):
            score_predictions(cohort, {"a": "A", "b": "B", "extra": "X"})
        result = score_predictions(cohort, {"a": "A", "b": {"status": "failed", "output": {"answer": "B"}}}, scorer="accuracy")
        self.assertEqual(result["score"], 0.5)
        self.assertEqual(result["count"], 2)

    def test_macro_f1_is_whole_run_metric(self):
        cohort = [problem("a", "0"), problem("b", "0"), problem("c", "1")]
        result = score_predictions(cohort, {"a": "0", "b": "1", "c": None}, scorer="macro_f1", labels=["0", "1"])
        self.assertAlmostEqual(result["score"], 1 / 3)
        self.assertEqual(result["per_problem"], {"a": None, "b": None, "c": None})
        self.assertEqual(result["class_scores"]["1"], 0)
        with self.assertRaises(ValueError):
            score_predictions(cohort, {"a": "0", "b": "1", "c": "1"}, scorer="macro_f1")

    def test_answer_f1_multiset_and_alias(self):
        self.assertAlmostEqual(answer_f1("cat cat", "cat"), 2 / 3)
        self.assertEqual(answer_f1("yes indeed", "yes", special_answers=True), 0)
        result = score_predictions([problem("a", {"answers": ["NY", "New York"]})], {"a": "the new york"}, scorer="answer_f1")
        self.assertEqual(result["score"], 1)

    def test_choice_parser_does_not_guess_from_narrative(self):
        cohort = [problem("a", "A")]
        self.assertEqual(score_predictions(cohort, {"a": "The answer is (A)."}, scorer="accuracy", answer_parser="choice")["score"], 1)
        self.assertEqual(score_predictions(cohort, {"a": "A then B, maybe A"}, scorer="accuracy", answer_parser="choice")["score"], 0)

    def test_numeric_exact_and_scibench_symmetric_tolerance(self):
        self.assertEqual(numeric_value("work 8+2=10 #### 10"), 10)
        self.assertEqual(numeric_value(r"$1.5 \times 10^{3}$"), 1500)
        self.assertIsNone(numeric_value("I saw 4 birds and 2 cats"))
        self.assertIsNone(numeric_value("NaN"))
        self.assertEqual(numeric_value(r"\frac{1}{2}"), 0.5)
        cohort = [problem("a", "100")]
        self.assertEqual(score_predictions(cohort, {"a": 105.2}, scorer="numeric_equivalence_accuracy")["score"], 1)
        self.assertEqual(score_predictions(cohort, {"a": 105.3}, scorer="numeric_equivalence_accuracy")["score"], 0)
        self.assertEqual(score_predictions([problem("a", 5)], {"a": 5.0}, scorer="numeric_answer_accuracy")["score"], 1)

    def test_bbh_nested_group_file_macro(self):
        cohort = [problem("a", "(A)", group="g1", task_name="f1"),
                  problem("b", "(A)", group="g1", task_name="f1"),
                  problem("c", "(B)", group="g1", task_name="f2"),
                  problem("d", "yes", group="g2", task_name="f3")]
        result = score_predictions(cohort, {"a": "A", "b": "A", "c": "A", "d": "no"}, scorer="group_macro_match")
        self.assertEqual(result["score"], 0.25)
        with self.assertRaisesRegex(ValueError, "metadata.group"):
            score_predictions([problem("x", "A")], {"x": "A"}, scorer="group_macro_match")

    def test_scibench_original_unit_scientific_scale(self):
        reference = {"answer": "4.2", "unit": "$10^{-3}$ J"}
        self.assertEqual(scibench_numeric_match(r"Work. \boxed{4.2 \times 10^{-3}}", reference), 1)
        self.assertEqual(scibench_numeric_match("0.0042 J", reference), 1)
        self.assertEqual(scibench_numeric_match("4.2", reference), 0)
        self.assertEqual(scibench_numeric_match("I think 0.0042", reference), 0)

    def test_official_evaluator_is_required_and_normalized(self):
        cohort = [problem("a", {"answer": "x"})]
        with self.assertRaisesRegex(ValueError, "requires a source-specific"):
            score_predictions(cohort, {"a": "x"}, scorer="drop_f1")
        seen = []
        def evaluator(prediction, reference, record):
            seen.append((prediction, reference, record["id"]))
            return 0.6
        self.assertEqual(score_predictions(cohort, {"a": "x"}, scorer="drop_f1", official_evaluator=evaluator)["score"], 0.6)
        self.assertEqual(seen, [("x", {"answer": "x"}, "a")])
        with self.assertRaises(ValueError):
            score_predictions(cohort, {"a": "x"}, scorer="drop_f1", official_evaluator=lambda *args: 100)

    def test_summary_sd_and_cross_entry_equal_weights(self):
        result = summarize_runs([0.2, 0.4, 0.6])
        self.assertAlmostEqual(result["mean"], 40)
        self.assertAlmostEqual(result["sample_sd"], 20)
        with self.assertRaises(ValueError):
            summarize_runs([1])
        cross = aggregate_settings({"small": [0.0, 0.2], "large": [1.0, 0.8]}, settings=["small", "large"])
        self.assertEqual(cross["mean"], 50)
        self.assertEqual(cross["sample_sd"], 0)
        with self.assertRaises(ValueError):
            aggregate_settings({"x": [1, 1]}, settings=["x", "x"])


if __name__ == "__main__":
    unittest.main()
