import copy
import unittest

from openmas.perturbations import apply_perturbation, description_variant
from openmas.registry import default_registry


class PerturbationTests(unittest.TestCase):
    def setUp(self):
        self.problem = {"id": "p1", "setting": "GSM8K", "input": {"question": "Compute the total and then report it."}, "reference": 5}
        self.components = list(default_registry().components.values())

    def test_failure_masks_are_nested_and_enforced(self):
        low = apply_perturbation(self.problem, self.components, family="P4", intensity="low", seed=11,
                                relevant_resource_ids=["g.reason"], feasible_alternative_exists=True)
        high = apply_perturbation(self.problem, self.components, family="P4", intensity="high", seed=11,
                                 relevant_resource_ids=["g.reason"], feasible_alternative_exists=True)
        self.assertTrue(set(low[2]["changed_component_ids"]).issubset(high[2]["changed_component_ids"]))
        self.assertEqual(len(low[2]["changed_component_ids"]), 2)
        self.assertEqual(len(high[2]["changed_component_ids"]), 6)
        for component in high[1]:
            if component["id"] in high[2]["changed_component_ids"]:
                self.assertTrue(component["config"]["unavailable"])
        self.assertNotIn("config", next(c for c in self.components if c["id"] == "g.reason"))

    def test_metadata_swaps_preserve_runtime_contract_and_low_edits(self):
        low = apply_perturbation(self.problem, self.components, family="P2", intensity="low", seed=22)
        high = apply_perturbation(self.problem, self.components, family="P2", intensity="high", seed=22)
        original = {c["id"]: c for c in self.components}
        high_by_id = {c["id"]: c for c in high[1]}
        for component in low[1]:
            if component["id"] in low[2]["changed_component_ids"]:
                self.assertEqual(component["capability"], high_by_id[component["id"]]["capability"])
        for component in high[1]:
            for key in ("id", "operation", "inputs", "outputs"):
                self.assertEqual(component[key], original[component["id"]][key])

    def test_ambiguity_needs_real_review_decisions(self):
        with self.assertRaises(ValueError):
            apply_perturbation(self.problem, self.components, family="P1", intensity="low",
                               edits=[{"original": "total", "replacement": "result"}])
        edit = {"original": "total", "replacement": "result", "reviewer_decisions": [
            {"reviewer_id": "r1", "target_unchanged": True}, {"reviewer_id": "r2", "target_unchanged": True}]}
        problem, _, record = apply_perturbation(self.problem, self.components, family="P1", intensity="low", edits=[edit])
        self.assertEqual(problem["input"]["question"], "Compute the result and then report it.")
        self.assertNotEqual(record["original_input_digest"], record["modified_input_digest"])
        with self.assertRaises(ValueError):
            apply_perturbation(problem, self.components, family="P2", intensity="low")

    def test_description_detail_changes_only_prose(self):
        descriptions = {"t.calculate": {"inputs": {"expression": "Short arithmetic expression."}}}
        changed = description_variant(self.components, descriptions)
        original = copy.deepcopy(self.components)
        for components in (original, changed):
            for c in components:
                for f in c.get("inputs", []) + c.get("outputs", []):
                    f.pop("description", None)
        self.assertEqual(original, changed)


if __name__ == "__main__":
    unittest.main()
