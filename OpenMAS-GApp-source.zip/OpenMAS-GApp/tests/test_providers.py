import json
import os
import threading
import unittest
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from unittest.mock import patch

from openmas.budgets import Budget
from openmas.providers import BudgetedProvider, HTTPProvider, ProviderError


class Handler(BaseHTTPRequestHandler):
    requests = []

    def do_POST(self):
        payload = json.loads(self.rfile.read(int(self.headers['Content-Length'])))
        type(self).requests.append((self.path, payload, self.headers.get('Authorization')))
        if self.path.endswith('/embeddings'):
            response = {"data": [{"index": 0, "embedding": [1.0, 0.0]}], "usage": {"prompt_tokens": 2}}
        else:
            response = {"id": "local-request", "model": "local-deployment", "choices": [{"message": {"content": '{"answer":"4"}'}}], "usage": {"prompt_tokens": 7, "completion_tokens": 4}}
        data = json.dumps(response).encode()
        self.send_response(200)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        pass


class ProviderTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(('127.0.0.1', 0), Handler)
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.thread.join()

    def test_http_chat_embeddings_and_separate_accounting(self):
        url = f'http://127.0.0.1:{self.server.server_port}'
        config = {"base_url": url, "model": "deployed-id", "api_key_env": "OPENMAS_TEST_KEY", "embedding": {"base_url": url, "api_key_env": "OPENMAS_TEST_KEY", "model": "embed-test"}}
        with patch.dict(os.environ, {"OPENMAS_TEST_KEY": "local-test-placeholder"}):
            provider = HTTPProvider(config)
            budget = Budget({"model_calls": 2, "model_tokens": 100})
            client = BudgetedProvider(provider, budget)
            result = client.complete([{"role": "user", "content": "2+2"}], phase="construction", seed=11)
            embeddings = client.embed(["test"])
        self.assertEqual(result["model"], "local-deployment")
        self.assertEqual(embeddings, [[1.0, 0.0]])
        self.assertEqual(budget.snapshot()["model_tokens"], 11)
        self.assertEqual(budget.snapshot()["model_calls"], 1)
        self.assertNotIn("seed", Handler.requests[-2][1])
        self.assertNotIn("local-test-placeholder", json.dumps(provider.events))

    def test_missing_key_is_error(self):
        provider = HTTPProvider({"model": "x", "api_key_env": "OPENMAS_KEY_NOT_CONFIGURED"})
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(ProviderError, 'Missing API key'):
                provider.complete([{"role": "user", "content": "test"}])

    def test_no_automatic_api_model_alias(self):
        with patch.dict(os.environ, {}, clear=True):
            with self.assertRaisesRegex(ValueError, 'actual deployed model'):
                HTTPProvider({})


if __name__ == '__main__':
    unittest.main()
