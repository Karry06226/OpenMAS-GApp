"""Runtime tests use local deterministic operations, never benchmark scores."""
from copy import deepcopy
import threading
import unittest

from openmas.runtime import HarnessRuntime, validate_harness


def field(name, kind="integer", required=True):
    return {"name": name, "type": kind, "required": required}


class LocalRegistry:
    def __init__(self):
        self.components, self.handlers, self.calls = {}, {}, []
        self.lock = threading.Lock()

    def add(self, name, inputs, outputs, handler):
        self.components[name] = {"id": name, "kind": "tool", "operation": name,
                                 "inputs": inputs, "outputs": outputs}
        self.handlers[name] = handler
        return self

    def get(self, identifier):
        return self.components[identifier]

    def invoke(self, identifier, inputs, context):
        context["budget"].consume(tool_calls=1)
        with self.lock:
            self.calls.append((identifier, deepcopy(inputs)))
        return self.handlers[identifier](inputs)


def node(identifier, component="increment", bindings=None, **extra):
    return {"id": identifier, "kind": "Exec", "component": component,
            "associations": [component], "operation": component,
            "bindings": bindings if bindings is not None else {"x": {"external": "x"}},
            "tasks": [], **extra}


def edge(identifier, source, target, kind="Seq", **extra):
    return {"id": identifier, "source": source, "target": target, "type": kind, **extra}


def harness(nodes, edges=None, entry=None, answer=None, **extra):
    return {"id": "local-test", "problem_id": "local-test-1", "nodes": nodes,
            "edges": edges or [], "entry": entry or [nodes[0]["id"]],
            "outputs": {"answer": answer or {"node": nodes[-1]["id"], "field": "y"}}, **extra}


class RuntimeTests(unittest.TestCase):
    def setUp(self):
        self.registry = LocalRegistry().add("increment", [field("x")], [field("y")], lambda x: {"y": x["x"] + 1})

    def run_graph(self, graph, inputs=None, limits=None):
        return HarnessRuntime(self.registry, limits=limits).execute(graph, {"x": 1} if inputs is None else inputs)

    def test_sequential_source_versions(self):
        graph = harness([node("a"), node("b", bindings={"x": {"node": "a", "field": "y"}})], [edge("ab", "a", "b")])
        result = self.run_graph(graph)
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"], {"answer": 3})
        completions = [e for e in result["events"] if e["event_outcome"] == "activation_completed"]
        self.assertEqual(completions[-1]["input_versions"]["x"]["activation_id"], "a:1")
        self.assertEqual(result["usage"]["tool_calls"], 2)

    def test_parallel_frontier_and_join(self):
        barrier = threading.Barrier(2)

        def worker(values):
            barrier.wait(timeout=2)
            return {"y": values["x"] + 1}

        self.registry.add("worker", [field("x")], [field("y")], worker)
        self.registry.add("join", [field("left"), field("right")], [field("y")], lambda v: {"y": v["left"] + v["right"]})
        nodes = [node("fork"), node("left", "worker"), node("right", "worker"),
                 node("join", "join", {"left": {"node": "left", "field": "y"}, "right": {"node": "right", "field": "y"}})]
        edges = [edge("fl", "fork", "left", "Par"), edge("fr", "fork", "right", "Par"),
                 edge("lj", "left", "join", "Par"), edge("rj", "right", "join", "Par")]
        result = self.run_graph(harness(nodes, edges), limits={"external_calls_in_flight": 2})
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 4)
        self.assertEqual([name for name, _ in self.registry.calls].count("join"), 1)

    def test_choice_ties_and_inactive_branch_join(self):
        self.registry.add("combine", [], [field("y")], lambda _: {"y": 19})
        nodes = [{"id": "choice", "kind": "Choice", "tasks": [], "bindings": {}}, node("a"), node("b"), node("join", "combine", {})]
        edges = [edge("route-z", "choice", "b", "Alt", priority=1), edge("route-a", "choice", "a", "Alt", priority=1),
                 edge("aj", "a", "join"), edge("bj", "b", "join")]
        result = self.run_graph(harness(nodes, edges))
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 19)
        chosen = next(e for e in result["events"] if e["event_outcome"] == "choice_selected")
        self.assertEqual(chosen["edge_id"], "route-a")
        self.assertEqual(len(self.registry.calls), 2)
        self.assertTrue(any(e["event_outcome"] == "node_skipped" and e["node_id"] == "b" for e in result["events"]))

    def test_choice_rejects_missing_transferred_source(self):
        self.registry.add("optional", [], [field("y", required=False)], lambda _: {})
        nodes = [node("source", "optional", {}), {"id": "choice", "kind": "Choice", "bindings": {}, "tasks": []}, node("a"), node("b")]
        edges = [edge("sc", "source", "choice"), edge("a", "choice", "a", "Alt", priority=2, bindings={"x": {"node": "source", "field": "y"}}), edge("b", "choice", "b", "Alt", priority=1)]
        result = self.run_graph(harness(nodes, edges, answer={"node": "b", "field": "y"}))
        self.assertEqual(result["status"], "success", result)
        chosen = next(e for e in result["events"] if e["event_outcome"] == "choice_selected")
        self.assertEqual(chosen["edge_id"], "b")

    def test_null_is_a_value_and_missing_is_not(self):
        self.registry.add("nullable", [field("x", "any")], [field("y", "any")], lambda v: {"y": v["x"]})
        graph = harness([node("a", "nullable")])
        self.assertEqual(self.run_graph(graph, {"x": None})["output"], {"answer": None})
        missing = self.run_graph(graph, {})
        self.assertEqual(missing["status"], "failed")
        self.assertIn("Missing external input", missing["error"])
        self.assertEqual(len(self.registry.calls), 1)

    def feedback_graph(self):
        self.registry.add("review", [field("x")], [field("y"), field("accept", "boolean")], lambda v: {"y": v["x"], "accept": v["x"] >= 4})
        nodes = [node("work"), node("review", "review", {"x": {"node": "work", "field": "y"}}), node("finish", bindings={"x": {"node": "review", "field": "y"}})]
        edges = [edge("wr", "work", "review"), edge("retry", "review", "work", "Fb", max_traversals=8,
                condition={"source": {"node": "review", "field": "accept"}, "op": "falsy"},
                bindings={"x": {"node": "review", "field": "y"}}), edge("rf", "review", "finish")]
        return harness(nodes, edges)

    def test_feedback_consumes_persistent_counters_and_invalidates(self):
        result = self.run_graph(self.feedback_graph())
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 5)
        traversals = [e for e in result["events"] if e["event_outcome"] == "feedback_traversed"]
        self.assertEqual([e["edge_feedback_count"] for e in traversals], [1, 2])
        self.assertEqual([e["global_feedback_count"] for e in traversals], [1, 2])
        self.assertEqual(len([e for e in result["events"] if e["event_outcome"] == "completion_invalidated"]), 4)
        self.assertEqual(result["usage"]["tool_calls"], 7)

    def test_feedback_global_budget_forces_exit(self):
        result = self.run_graph(self.feedback_graph(), limits={"feedback_global": 1})
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 4)
        self.assertTrue(any(e["event_outcome"] == "feedback_exhausted" for e in result["events"]))
        self.assertEqual(result["usage"]["tool_calls"], 5)

    def test_graph_cannot_enlarge_per_edge_budget(self):
        result = self.run_graph(self.feedback_graph(), limits={"feedback_per_edge": 0})
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 3)
        self.assertFalse(any(e["event_outcome"] == "feedback_traversed" for e in result["events"]))

    def test_parallel_join_reexecutes_all_current_branches_after_feedback(self):
        self.registry.add("sum", [field("left"), field("right")], [field("y")], lambda v: {"y": v["left"] + v["right"]})
        nodes = [node("fork"), node("left", bindings={"x": {"node": "fork", "field": "y"}}),
                 node("right", bindings={"x": {"node": "fork", "field": "y"}}),
                 node("join", "sum", {"left": {"node": "left", "field": "y"}, "right": {"node": "right", "field": "y"}})]
        edges = [edge("fl", "fork", "left", "Par"), edge("fr", "fork", "right", "Par"), edge("lj", "left", "join", "Par"), edge("rj", "right", "join", "Par"),
                 edge("retry", "join", "fork", "Fb", max_traversals=1, bindings={"x": {"node": "join", "field": "y"}})]
        result = self.run_graph(harness(nodes, edges))
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 16)
        joins = [e for e in result["events"] if e["event_outcome"] == "activation_completed" and e["node_id"] == "join"]
        self.assertEqual(len(joins), 2)
        self.assertEqual(joins[-1]["input_versions"]["left"]["generation"], 1)
        self.assertEqual(joins[-1]["input_versions"]["right"]["generation"], 1)

    def test_feedback_keeps_unaffected_branch_completion(self):
        self.registry.add("sum", [field("left"), field("right")], [field("y")], lambda v: {"y": v["left"] + v["right"]})
        nodes = [node("left"), node("right"), node("join", "sum", {"left": {"node": "left", "field": "y"}, "right": {"node": "right", "field": "y"}})]
        edges = [edge("lj", "left", "join"), edge("rj", "right", "join"), edge("retry", "join", "left", "Fb", max_traversals=1, bindings={"x": {"node": "join", "field": "y"}})]
        result = self.run_graph(harness(nodes, edges, entry=["left", "right"]))
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 7)
        right = [e for e in result["events"] if e["event_outcome"] == "activation_completed" and e["node_id"] == "right"]
        self.assertEqual(len(right), 1)

    def test_nested_execution_budget_and_no_post_budget_invocations(self):
        graph = harness([node("a"), node("b", bindings={"x": {"node": "a", "field": "y"}})], [edge("ab", "a", "b")])
        result = self.run_graph(graph, limits={"execution": {"tool_calls": 1}})
        self.assertEqual(result["status"], "failed")
        self.assertEqual(len(self.registry.calls), 1)
        self.assertEqual(result["usage"]["tool_calls"], 1)

    def test_wrong_output_contract_fails(self):
        self.registry.add("bad", [], [field("y")], lambda _: {"y": "wrong"})
        result = self.run_graph(harness([node("a", "bad", {})]))
        self.assertEqual(result["status"], "failed")
        self.assertIn("Incorrect type", result["error"])

    def test_task_aliases_and_waiting_relation(self):
        a, b = node("a", tasks=["ta"]), node("b", bindings={"x": {"task": "ta", "field": "result"}}, tasks=["tb"])
        graph = harness([a, b], [edge("ab", "a", "b")], task_outputs={"ta": {"result": {"node": "a", "field": "y"}}}, task_graph={"tasks": [{"id": "ta"}, {"id": "tb"}], "dependencies": [{"source": "ta", "target": "tb"}]})
        self.assertEqual(self.run_graph(graph)["output"]["answer"], 3)
        broken = deepcopy(graph)
        broken["edges"] = []
        broken["entry"] = ["a", "b"]
        with self.assertRaisesRegex(ValueError, "waiting relation"):
            validate_harness(broken, self.registry)

    def test_prerequisite_requires_all_source_task_operations(self):
        nodes = [node("a1", tasks=["ta"]),
                 node("a2", bindings={"x": {"node": "a1", "field": "y"}}, tasks=["ta"]),
                 node("b", bindings={"x": {"node": "a1", "field": "y"}}, tasks=["tb"])]
        graph = harness(nodes, [edge("a1a2", "a1", "a2"), edge("a1b", "a1", "b")],
                        task_graph={"tasks": [{"id": "ta"}, {"id": "tb"}],
                                    "dependencies": [{"source": "ta", "target": "tb", "kinds": ["prerequisite"]}]})
        with self.assertRaisesRegex(ValueError, "waiting relation"):
            validate_harness(graph, self.registry)
        self.assertEqual(self.registry.calls, [])

    def test_invalid_graphs_rejected_before_calls(self):
        valid = harness([node("a")])
        mutations = [
            lambda h: h["nodes"].append(deepcopy(h["nodes"][0])),
            lambda h: h["nodes"][0].update(associations=[]),
            lambda h: h["nodes"][0].update(bindings={}),
            lambda h: h["nodes"][0].update(operation="unknown"),
            lambda h: h["edges"].append(edge("bad", "a", "missing")),
            lambda h: h["edges"].append(edge("self", "a", "a")),
            lambda h: h["outputs"].update(answer={"node": "missing", "field": "y"}),
            lambda h: h["nodes"][0].update(bindings={"x": {"value": "incorrect"}}),
        ]
        for mutate in mutations:
            with self.subTest(mutate=mutate):
                graph = deepcopy(valid)
                mutate(graph)
                result = self.run_graph(graph)
                self.assertEqual(result["status"], "failed")
                self.assertEqual(self.registry.calls, [])

    def test_choice_requires_typed_conditions(self):
        graph = harness([{"id": "c", "kind": "Choice", "tasks": []}, node("a")],
                        [edge("ca", "c", "a", "Alt", condition={"source": {"external": "x"}, "op": "eval", "value": "__import__('os')"})])
        result = self.run_graph(graph)
        self.assertEqual(result["status"], "failed")
        self.assertEqual(self.registry.calls, [])

    def test_real_registry_calculator_integration(self):
        from openmas.registry import default_registry

        graph = harness([node("calculate", "t.calculate", {"expression": {"external": "expression"}})], answer={"node": "calculate", "field": "result"})
        graph["nodes"][0]["operation"] = "calculate"
        result = HarnessRuntime(default_registry()).execute(graph, {"expression": "(2 + 3) * 4"})
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 20)
        self.assertEqual(result["usage"]["tool_calls"], 1)

    def test_choice_eligibility_includes_target_required_bindings(self):
        nodes = [{"id": "choice", "kind": "Choice", "tasks": []},
                 node("missing", bindings={"x": {"external": "absent"}}), node("available")]
        edges = [edge("prefer", "choice", "missing", "Alt", priority=10),
                 edge("fallback", "choice", "available", "Alt", priority=1)]
        result = self.run_graph(harness(nodes, edges))
        self.assertEqual(result["status"], "success", result)
        selected = next(e for e in result["events"] if e["event_outcome"] == "choice_selected")
        self.assertEqual(selected["edge_id"], "fallback")

    def test_skipped_selected_task_obligation_fails(self):
        nodes = [{"id": "choice", "kind": "Choice", "tasks": []},
                 node("a", tasks=["ta"]), node("b", tasks=["tb"])]
        edges = [edge("a", "choice", "a", "Alt", priority=2), edge("b", "choice", "b", "Alt", priority=1)]
        result = self.run_graph(harness(nodes, edges, answer={"node": "a", "field": "y"},
                                      task_graph={"tasks": [{"id": "ta"}, {"id": "tb"}]}))
        self.assertEqual(result["status"], "failed")
        self.assertIn("Selected task tb did not complete", result["error"])

    def test_cyclic_task_alias_rejected_before_invocation(self):
        graph = harness([node("a")], answer={"task": "t", "field": "answer"},
                        task_outputs={"t": {"answer": {"task": "t", "field": "answer"}}})
        result = self.run_graph(graph)
        self.assertEqual(result["status"], "failed")
        self.assertIn("Cyclic task output alias", result["error"])
        self.assertEqual(self.registry.calls, [])

    def test_forward_edge_can_pass_declared_target_input(self):
        graph = harness([node("a"), node("b")],
                        [edge("ab", "a", "b", bindings={"x": {"node": "a", "field": "y"}})])
        result = self.run_graph(graph)
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["output"]["answer"], 3)

    def test_real_agent_receives_goal_rules_and_measured_usage(self):
        from openmas.registry import default_registry
        import json

        class RecordingProvider:
            def complete(self, messages, **kwargs):
                self.payload = json.loads(messages[-1]["content"])
                return {"text": '{"answer":"documented answer"}',
                        "usage": {"prompt_tokens": 5, "completion_tokens": 2}, "model": "local-test"}

        provider = RecordingProvider()
        graph = harness([node("reason", "g.reason", {"question": {"external": "question"}}, config={"task_goal": "Compare the two candidates"})],
                        answer={"node": "reason", "field": "answer"}, profiles={"domain": {"rules": ["Keep the requested answer format"]}})
        graph["nodes"][0]["operation"] = "reason"
        result = HarnessRuntime(default_registry(), provider=provider).execute(graph, {"question": "Which candidate?"})
        self.assertEqual(result["status"], "success", result)
        self.assertEqual(result["usage"]["model_calls"], 1)
        self.assertEqual(result["usage"]["model_tokens"], 7)
        self.assertEqual(provider.payload["goal"], "Compare the two candidates")
        self.assertEqual(provider.payload["domain_rules"], ["Keep the requested answer format"])


if __name__ == "__main__":
    unittest.main()
