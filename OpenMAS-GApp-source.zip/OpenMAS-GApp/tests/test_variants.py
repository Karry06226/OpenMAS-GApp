"""Behavioral tests for newly implemented local method variants."""
from copy import deepcopy
import json
import unittest

from openmas.construction import GraphHarnessBuilder
from openmas.registry import Registry, field
from openmas.runtime import HarnessRuntime
from openmas.variants import (GeneratedConfigurationBuilder, NoTaskStructureBuilder,
                              SemanticIOAblationBuilder, SequentialBuilder,
                              VARIANT_BUILDERS)


def task(identifier="solve", input_name="question", output_name="answer", bindings=None):
    return {"id": identifier, "goal": "solve the complete problem", "covers": ["r"],
            "capabilities": [{"text": "solve", "weight": 1.0}],
            "inputs": [field(input_name)], "outputs": [field(output_name)],
            "bindings": bindings or {input_name: {"external": "question"}}}


def graph(tasks=None):
    tasks = tasks or [task()]
    return {"requirements": [{"id": "r", "mandatory": True}], "tasks": tasks,
            "dependencies": [], "outputs": {"answer": {"task": tasks[-1]["id"], "field": tasks[-1]["outputs"][0]["name"]}}}


def registry(output_type="string"):
    entries = [{"id": identifier, "kind": "agent", "operation": "solve", "capability": "solve",
                "inputs": [field("question")], "outputs": [field("answer", output_type)], "cost": cost}
               for identifier, cost in (("a", 1.0), ("b", 2.0))]
    return Registry(entries, handlers={identifier: lambda values, context: {"answer": "computed locally"} for identifier in ("a", "b")})


class VariantProvider:
    is_fixture = True

    def __init__(self, tasks=None, proposals=None):
        self.graph = graph(tasks)
        self.proposals = proposals
        self.stages, self.requests = [], []
        self.embedding_calls = 0

    def embed(self, texts):
        self.embedding_calls += 1
        return [[1., 0.] for _ in texts]

    def complete(self, messages, **kwargs):
        self.stages.append(messages[0]["content"])
        self.requests.append(deepcopy(messages))
        data = json.loads(messages[1]["content"])
        if "task_extraction" in messages[0]["content"]:
            result = self.graph
        elif "component_configuration" in messages[0]["content"]:
            result = {"paths": self.proposals or [
                {"components": [identifier], "bindings": [{"question": {"external": "question"}}],
                 "output_bindings": {"answer": {"node": "p0", "field": "answer"}}}
                for identifier in ("a", "b")
            ]}
        elif "relations" in data:
            result = {"judgments": [{"id": relation["id"],
                                     "accept": relation["kind"] == "capability" or relation["source"]["name"] == relation["target"]["name"],
                                     "score": 1.0}
                                    for relation in data["relations"]]}
        else:
            raise AssertionError("Unexpected model call in local variant test")
        return {"text": json.dumps(result), "usage": {"prompt_tokens": 1, "completion_tokens": 1}, "model": "fixture-variants"}


class VariantTests(unittest.TestCase):
    def setUp(self):
        self.problem = {"id": "one", "setting": "test", "domain": "general", "application_type": "qa",
                        "input": {"question": "A complete question", "choices": ["a", "b"], "context": "a passage"},
                        "reference": "PRIVATE_REFERENCE", "metadata": {"hidden_tests": "PRIVATE_TESTS"}}
        self.config = {"synthesis": "compiled"}

    def test_no_task_structure_keeps_entire_public_input_without_model_extraction(self):
        provider = VariantProvider()
        builder = NoTaskStructureBuilder(registry(), provider, self.config)
        harness = builder.build(self.problem)
        self.assertEqual(len(harness["task_graph"]["tasks"]), 1)
        self.assertFalse(any("task_extraction" in stage for stage in provider.stages))
        value = harness["nodes"][0]["bindings"]["question"]["value"]
        self.assertEqual(json.loads(value), self.problem["input"])
        self.assertNotIn("PRIVATE", json.dumps(provider.requests))
        self.assertTrue(builder.last_record["task_extraction_bypassed"])
        self.assertFalse(harness["metadata"]["historical_prompt_or_run_recovered"])
        result = HarnessRuntime(builder.registry).execute(harness, self.problem["input"])
        self.assertEqual(result["status"], "success", result)

    def test_sequence_serializes_independent_tasks_and_preserves_bindings(self):
        tasks = [task("first"), task("second")]
        base = GraphHarnessBuilder(registry(), VariantProvider(tasks), self.config).build(self.problem)
        builder = SequentialBuilder(registry(), VariantProvider(tasks), {"synthesis": "model"})
        ordered = builder.build(self.problem)
        self.assertEqual(len(base["entry"]), 2)
        self.assertEqual(len(ordered["entry"]), 1)
        self.assertEqual(len(ordered["edges"]), len(ordered["nodes"]) - 1)
        self.assertEqual([n["bindings"] for n in base["nodes"]], [n["bindings"] for n in ordered["nodes"]])
        self.assertTrue(all(e["type"] == "Seq" for e in ordered["edges"]))
        self.assertEqual(ordered["metadata"]["implementation"], "ablation-serialized-selected-operations-v1")
        result = HarnessRuntime(builder.registry).execute(ordered, self.problem["input"])
        self.assertEqual(result["status"], "success", result)

    def test_semantic_io_ablation_admits_type_compatible_renamed_fields(self):
        renamed = [task(input_name="prompt", output_name="response", bindings={"prompt": {"external": "question"}})]
        with self.assertRaisesRegex(ValueError, "No hard-feasible"):
            GraphHarnessBuilder(registry(), VariantProvider(renamed), self.config).build(self.problem)
        builder = SemanticIOAblationBuilder(registry(), VariantProvider(renamed), self.config)
        harness = builder.build(self.problem)
        self.assertGreater(builder.last_record["semantic_field_judgments_bypassed"], 0)
        self.assertTrue(builder.last_record["runtime_type_contracts_preserved"])
        self.assertEqual(HarnessRuntime(builder.registry).execute(harness, self.problem["input"])["status"], "success")

    def test_semantic_io_ablation_still_rejects_wrong_output_type(self):
        builder = SemanticIOAblationBuilder(registry("integer"), VariantProvider(), self.config)
        with self.assertRaisesRegex(ValueError, "No hard-feasible"):
            builder.build(self.problem)

    def test_generated_configs_bypass_embeddings_and_utility_scores(self):
        provider = VariantProvider()
        builder = GeneratedConfigurationBuilder(registry(), provider, self.config)
        harness = builder.build(self.problem)
        self.assertEqual(provider.embedding_calls, 0)
        self.assertFalse(any("semantic_judgment" in stage for stage in provider.stages))
        family = builder.last_record["path_families"]["solve"]
        self.assertEqual(len(family["selected_path_ids"]), 2)
        self.assertIsNone(family["paths"][0]["coverage"])
        self.assertIsNone(family["paths"][0]["utility"])
        self.assertEqual(HarnessRuntime(builder.registry).execute(harness, self.problem["input"])["status"], "success")
        self.assertNotIn("PRIVATE", json.dumps(provider.requests))

    def test_generated_configs_reject_unknown_and_forward_producers(self):
        good = {"components": ["a"], "bindings": [{"question": {"external": "question"}}],
                "output_bindings": {"answer": {"node": "p0", "field": "answer"}}}
        for mutate in (
            lambda path: path.update(components=["unknown"]),
            lambda path: path["bindings"][0].update(question={"node": "p0", "field": "answer"}),
            lambda path: path.update(output_bindings={"answer": {"external": "question"}}),
            lambda path: path["bindings"][0].update(question={"external": "undeclared"}),
        ):
            with self.subTest(mutate=mutate):
                bad = deepcopy(good)
                mutate(bad)
                provider = VariantProvider(proposals=[bad, good])
                builder = GeneratedConfigurationBuilder(registry(), provider, self.config)
                with self.assertRaises(ValueError):
                    builder.build(self.problem)
                self.assertEqual(builder.last_record["status"], "failed")
                self.assertFalse(builder.last_record["historical_prompt_or_run_recovered"])

    def test_generated_configs_reject_duplicate_or_too_few_paths(self):
        path = {"components": ["a"], "bindings": [{"question": {"external": "question"}}],
                "output_bindings": {"answer": {"node": "p0", "field": "answer"}}}
        for paths in ([path], [path, deepcopy(path)]):
            with self.assertRaises(ValueError):
                GeneratedConfigurationBuilder(registry(), VariantProvider(proposals=paths), self.config).build(self.problem)

    def test_named_variants_have_explicit_registered_implementations(self):
        self.assertIs(VARIANT_BUILDERS["representation_sequence"], SequentialBuilder)
        self.assertEqual(len(set(VARIANT_BUILDERS.values())), 4)


if __name__ == "__main__":
    unittest.main()
